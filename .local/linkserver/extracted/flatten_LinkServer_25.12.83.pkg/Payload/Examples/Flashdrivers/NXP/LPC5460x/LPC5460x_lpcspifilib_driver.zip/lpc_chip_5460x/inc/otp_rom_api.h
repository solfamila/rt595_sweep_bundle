/*
 * @brief LPC5460x OTP ROM API
 *
 * @note
 * Copyright 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __OTP_ROM_API_H_
#define __OTP_ROM_API_H_


typedef struct _OTPD_API {
	ErrorCode_t (*otpInit)(void);
	ErrorCode_t (*otpEnableBankWriteMask)(uint32_t bankMask);
	ErrorCode_t (*otpDisableBankWriteMask)(uint32_t bankMask);
	ErrorCode_t (*otpEnableBankWriteLock)(uint32_t bankIndex, uint32_t regEnableMask, uint32_t regDisableMask,
										  uint32_t lockWrite);
	ErrorCode_t (*otpEnableBankReadLock)(uint32_t bankIndex, uint32_t regEnableMask, uint32_t regDisableMask,
										 uint32_t lockWrite);
	ErrorCode_t (*otpProgramReg)(uint32_t bankIndex, uint32_t regIndex, uint32_t value);
	ErrorCode_t (*otpProgramBank)(uint32_t bankIndex, uint32_t valueArray[4]);
	ErrorCode_t (*otpEnableUniqueKeyWriteLock)(uint32_t regEnable, uint32_t lockWrite);
	ErrorCode_t (*otpProgramUniqueKey)(uint32_t valueArray[3]);
	ErrorCode_t (*otpSetupShuffler)(uint32_t dirIn, uint32_t shuffleEn);
	ErrorCode_t (*otpProgramUserKey)(uint32_t programEn);
	uint32_t    (*rngRead)(void);
	uint32_t    (*otpGetDriverVersion)(void);
} ROM_OTP_API_T;

#endif /* __OTP_ROM_API_H_ */

