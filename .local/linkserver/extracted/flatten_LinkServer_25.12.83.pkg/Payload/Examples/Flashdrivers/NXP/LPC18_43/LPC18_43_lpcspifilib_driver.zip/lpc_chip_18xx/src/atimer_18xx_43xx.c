/*
 * @brief LPC18xx/43xx Alarm Timer driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Initialize Alarm Timer */
void Chip_ATIMER_Init(LPC_ATIMER_T *pATIMER, uint32_t PresetValue)
{
	Chip_ATIMER_UpdatePresetValue(pATIMER, PresetValue);
	Chip_ATIMER_ClearIntStatus(pATIMER);
}

/* Close ATIMER device */
void Chip_ATIMER_DeInit(LPC_ATIMER_T *pATIMER)
{
	Chip_ATIMER_ClearIntStatus(pATIMER);
	Chip_ATIMER_IntDisable(pATIMER);
}

