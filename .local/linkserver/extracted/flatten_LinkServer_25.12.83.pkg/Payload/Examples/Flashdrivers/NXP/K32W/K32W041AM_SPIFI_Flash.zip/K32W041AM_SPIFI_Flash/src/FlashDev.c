//*****************************************************************************
// FlashDev.c
// MCUXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2014-2015, 2017-2020, 2021, 2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "lpcx_flash_driver.h"
#include "Eeprom.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice = {
		FLASH_DRV_VERS,              // Driver Version, do not modify!
		"K32W041AM QSPI Flash "__DATE__" "__TIME__,
		EXTSPI,                      // Device Type
		0x10000000,					// Device Start Address
		gEepromParams_TotalSize_c,	// Device Size
		0x100,                       // Programming Page Size
		0,                           // Reserved, must be 0
		0xFF,                        // Initial Content of Erased Memory
		1000,                        // Program Page Timeout
		3000,                        // Erase Sector Timeout
		// Specify Size and Address of Sectors
		{ { gEepromParams_SectorSize_c, 0 },                     // Sector sizes
				{ SECTOR_END } } };
