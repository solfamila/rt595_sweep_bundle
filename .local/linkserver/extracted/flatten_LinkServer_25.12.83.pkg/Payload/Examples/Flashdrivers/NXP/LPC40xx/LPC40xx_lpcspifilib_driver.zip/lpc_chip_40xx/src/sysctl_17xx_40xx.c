/*
 * @brief	LPC17xx/40xx System and Control driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/
/* Returns and clears the current sleep mode entry flags */
uint32_t Chip_SYSCTL_GetClrSleepFlags(uint32_t flags) {
	uint32_t savedFlags = LPC_SYSCTL->PCON;

	LPC_SYSCTL->PCON = flags;

	return savedFlags & (SYSCTL_PD_SMFLAG | SYSCTL_PD_DSFLAG |
						 SYSCTL_PD_PDFLAG | SYSCTL_PD_DPDFLAG);
}

#if !defined(CHIP_LPC175X_6X)
/* Resets a peripheral */
void Chip_SYSCTL_PeriphReset(CHIP_SYSCTL_RESET_T periph)
{
	uint32_t bitIndex, regIndex = (uint32_t) periph;

	/* Get register array index and clock index into the register */
	bitIndex = (regIndex % 32);
	regIndex = regIndex / 32;

	/* Reset peripheral */
	LPC_SYSCTL->RSTCON[regIndex] = (1 << bitIndex);
	LPC_SYSCTL->RSTCON[regIndex] &= ~(1 << bitIndex);
}

#endif /*!defined(CHIP_LPC175X_6X)*/
