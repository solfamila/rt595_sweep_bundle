// Copyright 2012 Code Red Technologies Limited
// Copyright 2019 NXP
/***********************************************************************
 * Code Red Technologies Flash driver                                  *
 *                                                                     */
/***********************************************************************/
/*                                                                     */
/*  FlashDev.C:  Device Description for SST39VF3201B (16-bit Bus)      */
/*               connected to CS0 of LPC1800 on the Hitex board v2     */
/*                                                                     */
/***********************************************************************/

#include "crt_flash_if.h"


FLASHDEV_SECTION struct FlashDevice const FlashDevice = {
   FLASH_DRV_VERS,             // Driver Version, do not modify!

   "SST39VF3201B (4MB) Hitex_LPC1850A_4350A " __DATE__" "__TIME__, // Device Name

   EXT16BIT,                   // Device Type
   0x1C000000,                 // Device Start Address
   0x00400000,                 // Device Size in Bytes (4MB)
   1024,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory

   100,                        // Program Page Timeout 100 mSec
   1000,                       // Erase Sector Timeout 1000 mSec

// Specify the sector sizes and the relative start address of the first sector

   {{0x001000, 0x000000},         // Sector Size 4kB (1024 Sectors)
   {SECTOR_END }}


};
