//*****************************************************************************
// FlashPrg.c
//
// MCUXpresso IDE flash driver - Flash Programming Functions
//
// i.MX RT600 (rev B0) FlexSPI SFDP based drivers
//
//*****************************************************************************
//
// Copyright 2020-2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************


#include <stdint.h>
// For memcmp used in Verify()
#include <string.h>

#include "bl_api.h"

#include "lpcx_flash_driver.h"

#include "FlashConfig.h"


Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;


#define MEM_WriteU32(addr, value)  (*((volatile uint32_t *)(addr)) = value)

flexspi_nor_config_t flashConfig;
serial_nor_config_option_t configOption;

// ************************************
// Flash driver functions
// ************************************

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  1 - Failed
 */


uint32_t Init (void)
{
	status_t status;
	uint32_t v;
	uint32_t gpio_port, gpio_pin;

	configOption.option0.U = CONFIG_OPTION0;
	configOption.option1.U = CONFIG_OPTION1;

	memset((void *)&flashConfig, 0U, sizeof(flexspi_nor_config_t));

	// Disable cache
	MEM_WriteU32(0x40033800, 0);
	MEM_WriteU32(0x4003301C, 0);
	// PMC->MEMSEQCTRL = 0x1U;
	MEM_WriteU32(0x40135030, 0x1U);
	// Power FFRO
	MEM_WriteU32(0x40002630, 0x10000U);
	/* Flexspi SRAM APD/PPD */
	MEM_WriteU32(0x40002634, 0xCU);
	// Power SRAM
	MEM_WriteU32(0x40002638, 0xFFFFFFFF);
	MEM_WriteU32(0x4000263C, 0xFFFFFFFF);

	// PMC CTRL APPLYCFG
	*((volatile uint32_t *)0x4013500C) = *((volatile uint32_t *)0x4013500C) | 1;
	// WAIT PMC update done
	do {
		v = *((volatile uint32_t *)0x40135004) & 1;
	} while (v);

	/* MAINCLKSELA */
	MEM_WriteU32(0x40001430, 0x3U);
	/* MAINCLKSELB */
	MEM_WriteU32(0x40001434, 0x0U);

	flexspi_nor_set_clock_source(kFlexSpiClockSrc_FFRO_Clk);
	//CLKCTL0->PSCCTL0_SET = CLKCTL0_PSCCTL0_SET_FLEXSPI0_OTFAD_MASK;
	MEM_WriteU32(0x40001040, 0x10000U);
	//RSTCTL0->PRSTCTL0_CLR = RSTCTL0_PRSTCTL0_CLR_FLEXSPI0_OTFAD_MASK;
	MEM_WriteU32(0x40000070, 0x10000U);

	// ****************
	// Reset external flash via GPIO
	// RT6xx User manual - Section 41.5.1.1 - FlexSPI Flash reset
	// ****************

	// The problem with the external flash reset is that the actual pin
	// that is being used is board-specific: EVK boards use PIO2_12,
	// but custom boards can use anything!
	// Tackle this by decoding the port/pin info from OTP data.
	// This is the mechanism used to tell BootROM this info anyway.
	// The pre-connect script is writing the shadow register with
	// this info for the cases when the fuses are not yet programmed
	// And since the script is user-visible, it can be easily modified
	// for custom boards without needing to change the driver
	// If the info cannot be decoded from OTP, default to the most recent EVK

	// OTP BOOT_CFG[1] = (RESET_PIN_EN << 14) | (3b'PORT << 15) | (5b'PIN_NUM << 18)
	uint32_t OTP_BOOT_CFG_1 = *((volatile uint32_t*) 0x40130184);
	if ((OTP_BOOT_CFG_1 >> 14) & 1) // RESET_PIN_EN ?
	{
		gpio_port = ((OTP_BOOT_CFG_1 >> 15) & 0x7);
		gpio_pin = ((OTP_BOOT_CFG_1 >> 18) & 0x1F);
	}
	else // Default to PIO2_12 on EVK Rev E
	{
		gpio_port = 2;
		gpio_pin = 12;
	}

	//IOPCTL->PIO[gpio_port][gpio_pin] = 0x130;
	MEM_WriteU32(0x40004000 + (gpio_port << 7) + (gpio_pin << 2), 0x130U);
	//CLKCTL1->PSCCTL1_SET = CLKCTL1_PSCCTL1_SET_HSGPIO<gpio_port>_CLK_MASK;
	MEM_WriteU32(0x40021044, 1 << gpio_port);
	//RSTCTL1->PRSTCTL1_CLR = RSTCTL1_PRSTCTL1_HSGPIO<gpio_port>_MASK;
	MEM_WriteU32(0x40020074, 1 << gpio_port);
	// GPIO->DIR[gpio_port] = 1 << gpio_pin;
	MEM_WriteU32(0x40102000 + (gpio_port << 2), 1 << gpio_pin);
	// GPIO->CLR[gpio_port] = 1 << gpio_pin;
	MEM_WriteU32(0x40102280 + (gpio_port << 2), 1 << gpio_pin);
	// Delay 400us to reset external flash
	for (uint32_t i = 0; i < 60000; i++)
		__asm volatile ("nop");
	// GPIO->SET[gpio_port] = 1 << gpio_pin;
	MEM_WriteU32(0x40102200 + (gpio_port << 2), 1 << gpio_pin);
	// Clear FLASH status store register
	MEM_WriteU32(0x40002380, 0x0U);

	// ****************

	status = flexspi_nor_auto_config(0, &flashConfig, &configOption);
	if (status) {
		return (status);
	}

	// **********************************
	// Now updated the FlashDevice table using the settings for the
	// detected SPIFI device. These new values will be read back by
	// the debugger upon return from Init()
	// **********************************

	// Update FlashDevice device size
#if defined (FLEXSPI_PORTB)
	FlashDevice.szDev = flashConfig.memConfig.sflashB1Size;
#else
	FlashDevice.szDev = flashConfig.memConfig.sflashA1Size;
#endif

	// Update FlashDevice sector size - currently hard wired
	// Note: SPIFI devices are assumed to only support a single size
	//FlashDevice.sectors[0].szSector = config.sectorSize;
	FlashDevice.sectors[0].szSector = flashConfig.blockSize;

	// Update FlashDevice page size
	// Note that this is not the true page size from the detected SPIFI device, but
	// is actually the size of a single buffer of data that the debugger will send
	// down to the flash driver. This will normally be 16KB (limited by the available
	// RAM on the device) but cannot be larger than a single sector.

	if (FlashDevice.sectors[0].szSector < 16 * 1024)
		FlashDevice.szPage = FlashDevice.sectors[0].szSector;
	else
		FlashDevice.szPage = 16 * 1024; // use 16KB pseudo pages for now

	// Now use the flash driver mailbox to transfer info on the
	// updated device back to the host debugger.

#ifdef NDEBUG
	// Address of flash driver mailbox created by linker script
	// Note that this is skipped for debug builds of the driver
	extern unsigned int _b_mailbox;
	unsigned int *MAILBOX_PTR = &_b_mailbox;
	// Use mailbox 'status' word to pass address of message block
	*(MAILBOX_PTR+4) = (uint32_t)&Mailbox_Init_DynInfo;
#endif
	// Address of FlashDevice structure within driver
	Mailbox_Init_DynInfo.dyn_dev = &FlashDevice;

	// Pointer to string containing name of identified device

	// Ideally this should be the JEDEC ID, but no obvious way to get this
	Mailbox_Init_DynInfo.devname = "JEDEC_FlexSPI_Device";


	// Unused - partID information
	Mailbox_Init_DynInfo.partid_bytes = 0;
	Mailbox_Init_DynInfo.partid = 0;

	// **********************************

	return 0; // Finished without Errors
}

uint32_t UnInit(void) {

	return 0;                                  // Finished without Errors
}


#if !defined(DONT_PROVIDE_ERASECHIP)
/*  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseChip(void) {

	status_t status = 0;
	status =  flexspi_nor_flash_erase_all(0, &flashConfig);
	return (status);
}

#endif


uint32_t EraseSectors(uint32_t adr, uint32_t numsecs) {

	status_t status = 0;

#if defined (USE_SECURE_FLASHADDR)
	// Mask out bit 28 when calling ROM flash routines for programming in
	// secure flash address range
	adr &= ~(1UL << 28);
#endif

#if defined (ERASE_IN_ONE)
	// Make single call to erase all of the required sectors (blocks).
	// Simpler, but actually appears to be slower than erasing by block
	status =  flexspi_nor_flash_erase(0, &flashConfig, adr - TRUE_FLASH_BASE_ADDR, (numsecs * flashConfig.blockSize));
#else
	adr -= TRUE_FLASH_BASE_ADDR;
	while (numsecs) {
		status = flexspi_nor_flash_erase_block(0, &flashConfig, adr);
		if (status) {
			break;
		}
		numsecs--;
		adr += flashConfig.blockSize;
	}
#endif
	return status;
}



/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf) {

	status_t status = 0;
	uint32_t page = 0;

#if defined (USE_SECURE_FLASHADDR)
	// Mask out bit 28 when calling ROM flash routines for programming in
	// secure flash address range
	adr &= ~(1UL << 28);
#endif

	while (sz) {


		//   status =  flexspi_nor_flash_page_program(0, &flashConfig, adr - FLASH_BASE_ADDR, (uint32_t *)buf);
		status =  flexspi_nor_flash_page_program(0, &flashConfig, adr - TRUE_FLASH_BASE_ADDR, (void *)(buf + (page * flashConfig.pageSize)));

		if (status) {
			return (status);
		}

		sz = sz - flashConfig.pageSize;		// Decrease remaining size by page
		adr = adr + flashConfig.pageSize;		// Update adr base by page
		page ++;							// Next page
	}
	return (status);

}

#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t adr, uint32_t sz, uint8_t *buf) {

	uint32_t status = 0;

#if defined (USE_SECURE_FLASHADDR)
	// Mask out bit 28 when calling ROM flash routines for programming in
	// secure flash address range
	adr &= ~(1UL << 28);
#endif

	status = memcmp((void *) adr, buf, sz);

	return (status);
}
#if defined (USE_SMALL_MEMCMP)
int memcmp(const void *a, const void *b, size_t n)
{	const unsigned char *ac = (const unsigned char *)a,
	*bc = (const unsigned char *)b;
while (n-- > 0)
{	unsigned char c1,c2; /* unsigned cmp seems more intuitive */
if ((c1 = *ac++) != (c2 = *bc++)) return c1 - c2;
}
return 0;
}
#endif // USE_SMALL_MEMCMP
#endif // DONT_PROVIDE_VERIFY
