/*
 * Copyright 2018-2020, 2022, 2025 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 *
 */
#include "bl_api.h"
#include "FlashConfig.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#if defined (MIMXRT1170_SFDP_QSPI) || defined (MIMXRT1170_FlexSPI2_A_SFDP_QSPI) || defined (MIMXRT1170_SFDP_MXIC_OPI) || defined (MIMXRT1170_SFDP_MICRON_OPI)
// ************************************
// Used to check silicon version - as ROM API base address is
// difference between A0 and B0. Thus we need to check which
// base address to call into
// ************************************
extern uint32_t versionMajor;

/* ROM API Tree address */
#define ROM_API_TREE_REV_A (0x0020001CU)
#define ROM_API_TREE_REV_B (0x0021001CU)
#define IS_REV_A (versionMajor <= 0xA)
#define ROM_API_TREE (IS_REV_A ? ROM_API_TREE_REV_A : ROM_API_TREE_REV_B)
#elif defined (MIMXRT1160_SFDP_QSPI) || defined (MIMXRT1160_FlexSPI2_A_SFDP_QSPI) || defined (MIMXRT1160_SFDP_MXIC_OPI)
// RT1160 rev A is same as RT1170 rev B - so force version to 0xB
#define ROM_API_TREE       (0x0021001CU)
#elif defined(MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S) || defined(MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S) || \
        defined(MIMXRT1180_SFDP_FlexSPI1_A_QSPI) || defined(MIMXRT1180_SFDP_FlexSPI1_B_QSPI) || \
      defined(MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI_S) || \
        defined(MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI) || \
	  defined(MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI_S) || \
		defined(MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI) || \
      defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI_S) || \
        defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI) || defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI) || \
      defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI_S) || \
        defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI) || \
      defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S) || \
        defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI) || \
	  defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S) || \
		defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI)
#define ROM_API_TREE       (0x1000001CU)
#endif

#define g_bootloaderTree (*(bootloader_api_entry_t **)(ROM_API_TREE))

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

/*******************************************************************************
 * Codes
 ******************************************************************************/

void bl_api_init(void)
{
}

/*******************************************************************************
 * FlexSPI NOR driver
 ******************************************************************************/
status_t flexspi_nor_flash_init(uint32_t instance, flexspi_nor_config_t *config)
{
    return g_bootloaderTree->flexSpiNorDriver->init(instance, config);
}

status_t flexspi_nor_flash_page_program(uint32_t instance,
                                        flexspi_nor_config_t *config,
                                        uint32_t dstAddr,
                                        const uint32_t *src)
{
    return g_bootloaderTree->flexSpiNorDriver->page_program(instance, config, dstAddr, src);
}

status_t flexspi_nor_flash_erase_all(uint32_t instance, flexspi_nor_config_t *config)
{
    return g_bootloaderTree->flexSpiNorDriver->erase_all(instance, config);
}

status_t flexspi_nor_get_config(uint32_t instance, flexspi_nor_config_t *config, serial_nor_config_option_t *option)
{
    return g_bootloaderTree->flexSpiNorDriver->get_config(instance, config, option);
}

status_t flexspi_nor_flash_erase(uint32_t instance, flexspi_nor_config_t *config, uint32_t start, uint32_t length)
{
    return g_bootloaderTree->flexSpiNorDriver->erase(instance, config, start, length);
}

status_t flexspi_nor_flash_read(
    uint32_t instance, flexspi_nor_config_t *config, uint32_t *dst, uint32_t start, uint32_t bytes)
{
    return g_bootloaderTree->flexSpiNorDriver->read(instance, config, dst, start, bytes);
}

status_t flexspi_update_lut(uint32_t instance, uint32_t seqIndex, const uint32_t *lutBase, uint32_t numberOfSeq)
{
    return g_bootloaderTree->flexSpiNorDriver->update_lut(instance, seqIndex, lutBase, numberOfSeq);
}

status_t flexspi_command_xfer(uint32_t instance, flexspi_xfer_t *xfer)
{
    return g_bootloaderTree->flexSpiNorDriver->xfer(instance, xfer);
}

void flexspi_clear_cache(uint32_t instance)
{
    g_bootloaderTree->flexSpiNorDriver->clear_cache(instance);
}

status_t flexspi_update_clock_source(uint32_t instance, uint32_t source)
{
    return g_bootloaderTree->flexSpiNorDriver->set_clock_source(instance, source);
}

// ph added as not originally present

void flexspi_config_clock(uint32_t instance, uint32_t freqOption, uint32_t sampleClkMode)
{
    g_bootloaderTree->flexSpiNorDriver->config_clock(instance, freqOption, sampleClkMode);
}

status_t flexspi_nor_flash_erase_block(uint32_t instance, flexspi_nor_config_t *config, uint32_t address)
{
    return g_bootloaderTree->flexSpiNorDriver->erase_block(instance, config, address);
}

status_t flexspi_nor_flash_erase_sector(uint32_t instance, flexspi_nor_config_t *config, uint32_t address)
{
    return g_bootloaderTree->flexSpiNorDriver->erase_sector(instance, config, address);
}

void runBootloader(run_bootloader_ctx_t *ctx)
{
    g_bootloaderTree->runBootloader(ctx);
}


