/*
 * @brief LPC17xx/40xx WWDT chip driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Initialize the Watchdog timer */
void Chip_WWDT_Init(LPC_WWDT_T *pWWDT)
{
	/* Disable watchdog */
	pWWDT->MOD       = 0;
	pWWDT->TC        = 0xFF;
#if defined(WATCHDOG_WINDOW_SUPPORT)
	pWWDT->WARNINT   = 0xFFFF;
	pWWDT->WINDOW    = 0xFFFFFF;
#endif
}

/* Clear WWDT interrupt status flags */
void Chip_WWDT_ClearStatusFlag(LPC_WWDT_T *pWWDT, uint32_t status)
{
	if (status & WWDT_WDMOD_WDTOF) {
		pWWDT->MOD &= (~WWDT_WDMOD_WDTOF) & WWDT_WDMOD_BITMASK;
	}

	if (status & WWDT_WDMOD_WDINT) {
		pWWDT->MOD |= WWDT_WDMOD_WDINT;
	}
}
