/*
 * @brief LPC18xx/43xx Power Management Controller driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Set to sleep mode */
void Chip_PMC_Sleep(void)
{
	/* Sleep Mode*/
	__WFI();
}

/* Set power state */
void Chip_PMC_Set_PwrState(CHIP_PMC_PWR_STATE_T PwrState)
{

	/* Set Deep sleep mode bit in System Control register of M4 core */
	SCB->SCR = 0x4;

	/* Set power state in PMC */
	LPC_PMC->PD0_SLEEP0_MODE = (uint32_t) PwrState;

	__WFI();
}

