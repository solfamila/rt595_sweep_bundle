/*
 * @brief LPC542xx Ethernet driver
 *
 * @note
 * Copyright 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __ENET_546XX_H_
#define __ENET_546XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup ENET_542XX CHIP: LPC542xx Ethernet driver
 * @ingroup CHIP_542XX_Drivers
 * @{
 */

 
typedef struct {
	__IO uint32_t     MTL_TXQx_OP_MODE;
	__IO uint32_t     MTL_TXQx_UNDRFLW;
	__IO uint32_t     MTL_TXQx_DBG;
	__IO uint32_t     RESERVED0;
	__IO uint32_t     MTL_TXQx_ETS_CTRL;
	__IO uint32_t     MTL_TXQx_ETS_STAT;
	__IO uint32_t     MTL_TXQx_QNTM_WGHT;
	__IO uint32_t     MTL_TXQx_SNDSLP_CRDT;
	__IO uint32_t     MTL_TXQx_HI_CRDT;
	__IO uint32_t     MTL_TXQx_LO_CRDT;
	__IO uint32_t     RESERVED1;
	__IO uint32_t     MTL_TXQx_INTCTRL_STAT;
	__IO uint32_t     MTL_RXQx_OP_MODE;
	__IO uint32_t     MTL_RXQx_MISSPKT_OVRFLW_CNT;
	__IO uint32_t     MTL_RXQx_DBG;
	__IO uint32_t     MTL_RXQx_CTRL;
} MTL_QUEUEx_Type;

typedef struct {
	__IO uint32_t	DMA_CHx_CTRL;
	__IO uint32_t	DMA_CHx_TX_CTRL;
	__IO uint32_t	DMA_CHx_RX_CTRL;
	__IO uint32_t	RESERVED0[2];
	__IO uint32_t	DMA_CHx_TXDESC_LIST_ADDR;
	__IO uint32_t	RESERVED1;
	__IO uint32_t	DMA_CHx_RXDESC_LIST_ADDR;
	__IO uint32_t	DMA_CHx_TXDESC_TAIL_PTR;
	__IO uint32_t	RESERVED2;
	__IO uint32_t	DMA_CHx_RXDESC_TAIL_PTR;
	__IO uint32_t	DMA_CHx_TXDESC_RING_LENGTH;
	__IO uint32_t	DMA_CHx_RXDESC_RING_LENGTH;
	__IO uint32_t	DMA_CHx_INT_EN;
	__IO uint32_t	DMA_CHx_RX_INT_WDTIMER;
	__IO uint32_t	DMA_CHx_SLOT_FUNC_CTRL_STAT;
	__IO uint32_t	RESERVED3;
	__IO uint32_t	DMA_CHx_CUR_APP_TXDESC;
	__IO uint32_t	RESERVED4;
	__IO uint32_t	DMA_CHx_CUR_APP_RXDESC;
	__IO uint32_t	RESERVED5;
	__IO uint32_t	DMA_CHx_CUR_APP_TXBUF;
	__IO uint32_t	RESERVED6;
	__IO uint32_t	DMA_CHx_CUR_APP_RXBUF;
	__IO uint32_t	DMA_CHx_STAT;
	__IO uint32_t	RESERVED7[7];
} DMA_CHx_Type;

/**
 * @brief 10/100 MII & RMII Ethernet with timestamping register block structure
 */
typedef struct {							/*!< ETHERNET Structure */
	__IO uint32_t	MAC_CFG;			    /*!< MAC configuration register */
	__IO uint32_t	MAC_EXT_CFG;
	__IO uint32_t	MAC_PKT_FILTER;
	__IO uint32_t	MAC_WD_TIMEROUT;
	__IO uint32_t	RESERVED0[16];    //Hash
	__IO uint32_t	RESERVED1[8];    //VLAN
	__IO uint32_t	MAC_TX_FLOW_CTRL_Q[2];
	__IO uint32_t	RESERVED2[6];
	__IO uint32_t	MAC_RX_FLOW_CTRL;
	__IO uint32_t	RESERVED3;
	__IO uint32_t	MAC_TXQ_PRIO_MAP;
	__IO uint32_t	RESERVED4;
	__IO uint32_t	MAC_RXQ_CTRL[2];
	__IO uint32_t	RESERVED5[2];
	__IO uint32_t	MAC_INTR_STAT;
	__IO uint32_t	MAC_INTR_EN;
	__IO uint32_t	MAC_RXTX_STAT;
	__IO uint32_t   RESERVED6[2];    //PMT
	__IO uint32_t   RESERVED7[3];    //Remote Wakeup
	__IO uint32_t   MAC_LPI_CTRL_STAT;
	__IO uint32_t   MAC_LPI_TIMER_CTRL;
	__IO uint32_t   RESERVED8[2];
	__IO uint32_t   RESERVED9[7];    //RGMII, SMII, TBI, RTBI
	__IO uint32_t   RESERVED10[5];
	__IO uint32_t   MAC_VERSION;
	__IO uint32_t   MAC_DBG;
	__IO uint32_t   RESERVED11;
	__IO uint32_t   MAC_HW_FEAT[3];
	__IO uint32_t   RESERVED12[54];
	__IO uint32_t   MAC_MDIO_ADDR;
	__IO uint32_t   MAC_MDIO_DATA;
	__IO uint32_t   RESERVED13[62];  //MDIO, GPIO
	__IO uint32_t   MAC_ADDR_LOWHIGH[128][2];   //0=High, 1=Low
	__IO uint32_t   RESERVED14[128];  //MMC
	__IO uint32_t   RESERVED15[128];  //Layer3/4 Filtering
	__IO uint32_t   MAC_TIMESTAMP_CTRL;
	__IO uint32_t   MAC_SUB_SCND_INCR;
	__IO uint32_t   MAC_SYS_TIME_SCND;
	__IO uint32_t   MAC_SYS_TIME_NSCND;
	__IO uint32_t   MAC_SYS_TIME_SCND_UPD;
	__IO uint32_t   MAC_SYS_TIME_NSCND_UPD;
	__IO uint32_t   MAC_SYS_TIMESTMP_ADDEND;
	__IO uint32_t   MAC_SYS_TIME_HWORD_SCND;
	__IO uint32_t   MAC_SYS_TIMESTMP_STAT;
	__IO uint32_t	RESERVED16[55];


	//MTL Register MAP 0xC00-0xFFC
	__IO uint32_t	MTL_OP_MODE;
	__IO uint32_t   RESERVED17;
	__IO uint32_t   MTL_DBG_CTRL;
	__IO uint32_t   MTL_DBG_STAT;
	__IO uint32_t   MTL_FIFO_DBG_DATA;
	__IO uint32_t   RESERVED18[3];
	__IO uint32_t   MTL_INTR_STAT;
	__IO uint32_t   RESERVED19[3];
	__IO uint32_t   MTL_RXQ_DMA_MAP;
	__IO uint32_t   RESERVED20;
	__IO uint32_t   RESERVED21[50];
	MTL_QUEUEx_Type MTL_QUEUEx[2];
	__IO uint32_t	RESERVED22[96]; //MTL Queue[2-7]
	__IO uint32_t	RESERVED23[64];

	//DMA Register MAP 0x1000-0x14FC
	__IO uint32_t	DMA_MODE;
	__IO uint32_t	DMA_SYSBUS_MODE;
	__IO uint32_t	DMA_INTR_STAT;
	__IO uint32_t	DMA_DBG_STAT;
	__IO uint32_t	RESERVED24[2]; //DBG_STAT1/2
	__IO uint32_t	RESERVED25[58];
	DMA_CHx_Type	DMA_CHANNEL[2];
	__IO uint32_t	RESERVED26[192];

} LPC_ENET_T;

/*
 * @brief MAC_CONFIG register bit defines
 */
#define MAC_CFG_RE     		 (1 << 0)				/*!< Receiver enable */
#define MAC_CFG_TE			 (1 << 1)				/*!< Transmitter Enable */
#define MAC_CFG_PRELEN(n)	 (((n) & 0x03) << 2)	/*!< Transmitter Enable */
#define MAC_CFG_DC     		 (1 << 4)				/*!< Deferral Check */
#define MAC_CFG_BL(n)  		 (((n) & 0x03) << 5)	/*!< Back-Off Limit */
#define MAC_CFG_DR     		 (1 << 8)				/*!< Disable Retry */
#define MAC_CFG_DCRS   		 (1 << 9)				/*!< Disable carrier sense during transmission */
#define MAC_CFG_DO     		 (1 << 10)				/*!< Disable Receive Own */
#define MAC_CFG_ECRSFD   	 (1 << 11)				/*!< Enable Carrier Sense before Tx */
#define MAC_CFG_LM     		 (1 << 12)				/*!< Loopback Mode */
#define MAC_CFG_DM     		 (1 << 13)				/*!< Duplex Mode, 1 = full, 0 = half */
#define MAC_CFG_FES    		 (1 << 14)				/*!< Speed, 1 = 100Mbps, 0 = 10Mbos */
#define MAC_CFG_PS     		 (1 << 15)				/*!< Port select, must always be 1 */
#define MAC_CFG_JE     		 (1 << 16)				/*!< Jumbo Frame Enable */
#define MAC_CFG_JD     		 (1 << 17)				/*!< Jabber Disable */
#define MAC_CFG_WD     		 (1 << 19)				/*!< Watchdog Disable */
#define MAC_CFG_ACS    		 (1 << 20)				/*!< Automatic Pad/CRC Stripping */
#define MAC_CFG_CST			 (1 << 21)				/*!< CRC Stripping for Type packets */
#define MAC_CFG_S2KP		 (1 << 22)				/*!< 802.3as support for 2K packets */
#define MAC_CFG_GPSLCE		 (1 << 23)				/*!< Giant Packet Size Limit Control Enable */
#define MAC_CFG_IPG(n) 		 (((n) & 0x07) << 24)	/*!< Inter-packet gap, 40..96, n incs by 8 */
#define MAC_CFG_IPC    		 (1 << 27)				/*!< Checksum Offload */


/*
 * @brief MAC_PACKET_FILTER register bit defines
 */
#define MAC_PF_PR      (1 << 0)				/*!< Promiscuous Mode */
#define MAC_PF_HUC     (1 << 1)				/*!< Hash Unicast */
#define MAC_PF_HMC     (1 << 2)				/*!< Hash Multicast */
#define MAC_PF_DAIF    (1 << 3)				/*!< DA Inverse Filtering */
#define MAC_PF_PM      (1 << 4)				/*!< Pass All Multicast */
#define MAC_PF_DBF     (1 << 5)				/*!< Disable Broadcast Frames */
#define MAC_PF_PCF(n)  (((n) & 0x03) << 6)	/*!< Pass Control Frames, n = see user manual */
#define MAC_PF_SAIF    (1 << 8)				/*!< SA Inverse Filtering */
#define MAC_PF_SAF     (1 << 9)				/*!< Source Address Filter Enable */
#define MAC_PF_RA      (1UL << 31)			/*!< Receive all */

/*
 * @brief MAC_MII_ADDR register bit defines
 */
#define MAC_MIIA_RD		(3)
#define MAC_MIIA_WR		(1)

#define MAC_MIIA_GB    	(1 << 0)		/*!< MII busy */
#define MAC_MIIA_C45E  	(1 << 1)		/*!< Clause 45 enable */
#define MAC_MIIA_GOC(n)	((n) << 2)		/*!< Operation Command */
#define MAC_MIIA_SKAP  	(1 << 4)		/*!< Skip Address Packet */
#define MAC_MIIA_CR(n)  ((n) << 8)		/*!< CSR clock range, n = see manual */
#define MAC_MIIA_GR(n)  ((n) << 16)		/*!< MII register. n = 0..31 */
#define MAC_MIIA_PA(n)  ((n) << 21)		/*!< Physical layer address, n = 0..31 */

/*
 * @brief MAC_MII_DATA register bit defines
 */
#define MAC_MIID_GDMSK (0xFFFF)		/*!< MII data mask */

/**
 * @brief MAC_TX_FLOW_CONTROL register bit defines
 */
#define MAC_TXFC_FCB     (1 << 0)				/*!< Flow Control Busy/Backpressure Activate */
#define MAC_TXFC_TFE     (1 << 1)				/*!< Transmit Flow Control Enable */
#define MAC_TXFC_PLT(n)  (((n) & 0x07) << 4)	/*!< Pause Low Threshold, n = see manual */
#define MAC_TXFC_DZPQ    (1 << 7)				/*!< Disable Zero-Quanta Pause */
#define MAC_TXFC_PT(n)   ((n) << 16)			/*!< Pause time */


/**
 * @brief MAC_RX_FLOW_CONTROL register bit defines
 */
#define MAC_RXFC_RFE     (1 << 0)				/*!< Receive Flow Control Enable */
#define MAC_RXFC_UP      (1 << 1)				/*!< Unicast Pause Frame Detect */
#define MAC_RXFC_PFCE    (1 << 8)				/*!< Priority base control flow enable */

/**
 * @brief MAC_TX_PRIORITY_MAP register bit defines
 */
#define MAC_TXPR_PST0(n)	(((n) & 0xff) << 0)				/*!< TX Priority Map for Queue0 */
#define MAC_TXPR_PST1(n)	(((n) & 0xff) << 8)				/*!< TX Priority Map for Queue1 */

/*
 * @brief MAC_VLAN_TAG register bit defines
 */
#define MAC_VT_VL(n)   ((n) << 0)	/*!< VLAN Tag Identifier for Receive Frames */
#define MAC_VT_ETC     (1 << 7)		/*!< Enable 12-Bit VLAN Tag Comparison */

/*
 * @brief MAC_PMT_CTRL_STAT register bit defines
 */
#define MAC_PMT_PD     (1 << 0)		/*!< Power-down */
#define MAC_PMT_MPE    (1 << 1)		/*!< Magic packet enable */
#define MAC_PMT_WFE    (1 << 2)		/*!< Wake-up frame enable */
#define MAC_PMT_MPR    (1 << 5)		/*!< Magic Packet Received */
#define MAC_PMT_WFR    (1 << 6)		/*!< Wake-up Frame Received */
#define MAC_PMT_GU     (1 << 9)		/*!< Global Unicast */
#define MAC_PMT_WFFRPR (1UL << 31)	/*!< Wake-up Frame Filter Register Pointer Reset */

/*
 * @brief MAC_INTR_MASK register bit defines
 */
#define MAC_IM_PMT     (1 << 3)		/*!< PMT Interrupt Mask */

/*
 * @brief MAC_ADDR0_HIGH register bit defines
 */
#define MAC_ADRH_EN    	(1UL << 31)				/*!< Always 1 when writing register */
#define MAC_ADRH_DCS(n)	(((n) & 0x07) << 16)	/*!< DMA channel selection for the MAC address */

/*
 * @brief MAC_TIMESTAMP register bit defines
 */
#define MAC_TS_TSENA   (1 << 0)		/*!< Time Stamp Enable */
#define MAC_TS_TSCFUP  (1 << 1)		/*!< Time Stamp Fine or Coarse Update */
#define MAC_TS_TSINIT  (1 << 2)		/*!< Time Stamp Initialize */
#define MAC_TS_TSUPDT  (1 << 3)		/*!< Time Stamp Update */
#define MAC_TS_TSTRIG  (1 << 4)		/*!< Time Stamp Interrupt Trigger Enable */
#define MAC_TS_TSADDR  (1 << 5)		/*!< Addend Reg Update */
#define MAC_TS_TSENAL  (1 << 8)		/*!< Enable Time Stamp for All Frames */
#define MAC_TS_TSCTRL  (1 << 9)		/*!< Time Stamp Digital or Binary rollover control */
#define MAC_TS_TSVER2  (1 << 10)	/*!< Enable PTP packet snooping for version 2 format */
#define MAC_TS_TSIPENA (1 << 11)	/*!< Enable Time Stamp Snapshot for PTP over Ethernet frames */
#define MAC_TS_TSIPV6E (1 << 12)	/*!< Enable Time Stamp Snapshot for IPv6 frames */
#define MAC_TS_TSIPV4E (1 << 13)	/*!< Enable Time Stamp Snapshot for IPv4 frames */
#define MAC_TS_TSEVNT  (1 << 14)	/*!< Enable Time Stamp Snapshot for Event Messages */
#define MAC_TS_TSMSTR  (1 << 15)	/*!< Enable Snapshot for Messages Relevant to Master */
#define MAC_TS_TSCLKT(n) ((n) << 16)	/*!< Select the type of clock node, n = see menual */
#define MAC_TS_TSENMA  (1 << 18)	/*!< Enable MAC address for PTP frame filtering */

/*
 * @brief DMA_OP_MODE register bit defines
 */
#define DMA_OPM_SWR     (1 << 0)		/*!< Software reset */
#define DMA_OPM_DA      (1 << 1)		/*!< DMA arbitration scheme, 1 = TX has priority over TX */
#define DMA_OPM_TAA(n)  ((n) << 2)	/*!< Descriptor skip length, n = see manual */
#define DMA_OPM_TXPR    (1 << 11)	/*!< Transmit DMA has higher priority than receive DMA */
#define DMA_OPM_PR(n)   ((n) << 12)	/*!< Rx-to-Tx priority ratio, n = see manual */

/*
 * @brief DMA_SYS_MODE register bit defines
 */
#define DMA_SM_FB      (1 << 0)	/*!< Fixed burst */
#define DMA_SM_AAL     (1 << 12)	/*!< Address-aligned beats */
#define DMA_SM_MB      (1 << 14)	/*!< Mixed burst */
#define DMA_SM_RB      (1 << 15)	/*!< Rebuild INCRx Burst */

/*
 * @brief DMA_INT_STAT register bit defines
 */
#define DMA_INTSTAT_DC0		(1 << 0)	/*!< DMA Channel 0 Status */
#define DMA_INTSTAT_DC1		(1 << 1)	/*!< DMA Channel 1 Status */
#define DMA_INTSTAT_MTL		(1 << 16)	/*!< MTL Interrupt Status */
#define DMA_INTSTAT_MAC		(1 << 17)	/*!< MAC Interrupt Status */

/*
 * @brief DMA_CHx_CONTROL register bit defines
 */
#define DMA_CTL_PBL8X   (1 << 16)				/*!< 8 x PBL mode */
#define DMA_CTL_DSL(n)	(((n) & 0x07) << 18)	/*!< Descriptor Skip Length */

/*
 * @brief DMA_CHx_TX_CONTROL register bit defines
 */
#define DMA_TXCTL_ST   		(1 << 0)				/*!< Start/Stop Transmission */
#define DMA_TXCTL_TCW(n)	(((n) & 0x07) << 1)		/*!< Transmit Channel Weight */
#define DMA_TXCTL_PBL(n)	(((n) & 0x3F) << 16)		/*!< Transmit Channel Weight */

/*
 * @brief DMA_CHx_RX_CONTROL register bit defines
 */
#define DMA_RXCTL_SR   		(1 << 0)				/*!< Start/Stop Reception */
#define DMA_RXCTL_SZ(n)		(n << 1)				/*!< Receive Buffer Size */
#define DMA_RXCTL_PBL(n)	(((n) & 0x3F) << 16)	/*!< Programmable burst length */
#define DMA_RXCTL_MAMS(n)	(1 << 27)				/*!< MAC Address Match Status */

/*
 * @brief DMA_INT_EN register bit defines
 */
#define DMA_IE_TIE     (1 << 0)		/*!< Transmit interrupt enable */
#define DMA_IE_TSE     (1 << 1)		/*!< Transmit stopped enable */
#define DMA_IE_TUE     (1 << 2)		/*!< Transmit buffer unavailable enable */
#define DMA_IE_RIE     (1 << 6)		/*!< Receive interrupt enable */
#define DMA_IE_RUE     (1 << 7)		/*!< Receive buffer unavailable enable */
#define DMA_IE_RSE     (1 << 8)		/*!< Received stopped enable */
#define DMA_IE_RWE     (1 << 9)		/*!< Receive watchdog timeout enable */
#define DMA_IE_ETE     (1 << 10)	/*!< Early transmit interrupt enable */
#define DMA_IE_ERE     (1 << 11)	/*!< Early receive interrupt enable */
#define DMA_IE_FBE     (1 << 12)	/*!< Fatal bus error enable */
#define DMA_IE_CDE     (1 << 13)	/*!< Context Descriptor Error Enable */
#define DMA_IE_AIE     (1 << 15)	/*!< Abnormal interrupt summary enable */
#define DMA_IE_NIE     (1 << 16)	/*!< Normal interrupt summary enable */


#define DMA_ST_TI      (1 << 0)		/*!< Transmit interrupt */
#define DMA_ST_TPS     (1 << 1)		/*!< Transmit process stopped */
#define DMA_ST_TU      (1 << 2)		/*!< Transmit buffer unavailable */
#define DMA_ST_RI      (1 << 6)		/*!< Receive interrupt */
#define DMA_ST_RU      (1 << 7)		/*!< Receive buffer unavailable */
#define DMA_ST_RPS     (1 << 8)		/*!< Received process stopped */
#define DMA_ST_RWT     (1 << 9)		/*!< Receive watchdog timeout */
#define DMA_ST_ETI     (1 << 10)	/*!< Early transmit interrupt */
#define DMA_ST_ERI     (1 << 11)	/*!< Early receive interrupt */
#define DMA_ST_FBI     (1 << 12)	/*!< Fatal bus error interrupt */
#define DMA_ST_CDE     (1 << 13)	/*!< Context Descriptor Error */
#define DMA_ST_AIE     (1 << 14)	/*!< Abnormal interrupt summary */
#define DMA_ST_NIS     (1 << 15)	/*!< Normal interrupt summary */
#define DMA_ST_ALL     (0x0FFC7)	/*!< All interrupts */

/*
 * @brief MTL_TXQx_OPMODE register bit defines
 */
#define MTL_QUEUE_ENABLE	  (2)
#define MTL_QUEUE_DISABLE	  (0)

#define MTL_TXQx_MODE_FTQ     (1 << 0)		/*!< Flush Transmit Queue */
#define MTL_TXQx_MODE_TSF     (1 << 1)		/*!< Transmit Store and Forward */
#define MTL_TXQx_MODE_QEN(n)  ((n) << 2)	/*!< Queue enable */
#define MTL_TXQx_MODE_TTC(n)  ((n) << 4)	/*!< Transmit Threshold */
#define MTL_TXQx_MODE_TQS(n)  ((n) << 16)	/*!< Transmit Queue Size */

/*
 * @brief MTL_TXQx_INTSTAT register bit defines
 */
#define MTL_TXQx_IE_TUS     (1 << 0)		/*!< Transmit Underflow Status */
#define MTL_TXQx_IE_ABPS    (1 << 1)		/*!< Average Bits Per Slot Status */
#define MTL_TXQx_IE_TUE	    (1 << 8)		/*!< Transmit Underflow Interrupt Enable */
#define MTL_TXQx_IE_ABPE    (1 << 9)		/*!< Average Bits Per Slot Interrupt Enable */
#define MTL_TXQx_IE_ROS    	(1 << 16)		/*!< Receive Overflow Status  */
#define MTL_TXQx_IE_ROE  	(1 << 24)		/*!< Receive Overflow Interrupt Enable  */

/*
 * @brief MTL_RXQx_OPMODE register bit defines
 */
#define MTL_RXQx_MODE_RTC(n)  ((n) << 0)	/*!< Receive Queue Threshold */
#define MTL_RXQx_MODE_FUP     (1 << 3)		/*!< Forward Undersized Good Packets */
#define MTL_RXQx_MODE_FEP     (1 << 4)		/*!< Forward Error Packets */
#define MTL_RXQx_MODE_RSF  	  (1 << 5)		/*!< Receive Queue Store and Forward */
#define MTL_RXQx_MODE_DTE  	  (1 << 6)		/*!< Disable dropping of TCP/IP error packets */
#define MTL_RXQx_MODE_RQS(n)  ((n) << 20)	/*!< Receive Queue Size */

/*
 * @brief MTL_TXQx_OPMODE register bit defines
 */
#define MTL_RxDMAP_DACH(n)    	(1 << (4 + ((n) << 3)))	/*!< Queue mapped for DMA Channel based of Destination address */
#define MTL_RxDMAP_DMACH(m, n)  (m << ((n) << 3))	/*!< DMA channel mapping for Queue */

/*
 * @brief Common TRAN_DESC_T and TRAN_DESC_ENH_T CTRLSTAT field bit defines
 */

#define TDES_NORM_RD_BS1(n) 	((n) & 0x3fff)
#define TDES_NORM_RD_BS2(n) 	(((n) & 0x3fff) << 16)

#define TDES_NORM_RD_FL(n)		((n) & 0x7fff)
#define TDES_NORM_RD_CIC(n)		(((n) & 0x3) << 16)
#define TDES_NORM_RD_TSE		(1 << 18)
#define TDES_NORM_RD_SLOT(n)	(((n) & 0x0f) << 19)
#define TDES_NORM_RD_SAIC(n)	(((n) & 0x07) << 23)
#define TDES_NORM_RD_CPC(n)	(((n) & 0x03) << 26)
#define TDES_NORM_RD_LD			(1 << 28)
#define TDES_NORM_RD_FD			(1 << 29)
#define TDES_NORM_RD_CTXT		(1 << 30)
#define TDES_NORM_RD_OWN		(1UL << 31)

/*
 * @brief Common REC_DESC_T and REC_DESC_ENH_T STATUS field bit defines
 */

#define RDES_NORM_RD_BUF1V		(1 << 24)
#define RDES_NORM_RD_BUF2V		(1 << 25)
#define RDES_NORM_RD_INTE		(1 << 30)
#define RDES_NORM_RD_OWN		(1UL << 31)

#define RDES_NORM_WR_LENMASK	(0x7fff)
#define RDES_NORM_WR_ES			(1 << 15)
#define RDES_NORM_WR_DE			(1 << 19)
#define RDES_NORM_WR_RE			(1 << 20)
#define RDES_NORM_WR_OE			(1 << 21)
#define RDES_NORM_WR_RS0V		(1 << 25)
#define RDES_NORM_WR_RS1V		(1 << 26)
#define RDES_NORM_WR_RS2V		(1 << 27)
#define RDES_NORM_WR_LD			(1 << 28)
#define RDES_NORM_WR_FD			(1 << 29)
#define RDES_NORM_WR_CTXT		(1 << 30)
#define RDES_NORM_WR_OWN		(1UL << 31)

/*
 * @brief Maximum size of an ethernet buffer
 */
#define EMAC_ETH_MAX_FLEN (1536)

/**
 * @brief Structure of a transmit descriptor (read back format)
 */
typedef struct {
	__IO uint32_t B1ADD;		/*!< Buffer 1 address */
	__IO uint32_t B2ADD;		/*!< Buffer 2 or next descriptor address */
	__IO uint32_t BSIZE;		/*!< Buffer 1/2 byte counts */
	__IO uint32_t CTRLSTAT;		/*!< TDES control and status word */
} ENET_TXDESC_RD_T;

/**
 * @brief Structure of a transmit descriptor (write back format)
 */
typedef struct {
	__IO uint32_t TSLOW;		/*!< Buffer 1 address */
	__IO uint32_t TSHIGH;		/*!< Buffer 2 or next descriptor address */
	__IO uint32_t RSRVD;		/*!< Reserved */
	__IO uint32_t CTRLSTAT;		/*!< TDES control and status word */
} ENET_TXDESC_WR_T;

/**
 * @brief Structure of a receive descriptor (read back)
 */
typedef struct {
	__IO uint32_t B1ADD;		/*!< Buffer 1 address */
	__IO uint32_t RSRVD;		/*!< Reserved */
	__IO uint32_t B2ADD;		/*!< Buffer 2 or next descriptor address */
	__IO uint32_t CTRL;			/*!< Buffer 1/2 byte counts and control */

} ENET_RXDESC_RD_T;

/**
 * @brief Structure of a receive descriptor (write back)
 */
typedef struct {
	__IO uint32_t B1ADD;		/*!< Buffer 1 address */
	__IO uint32_t RSRVD;		/*!< Reserved */
	__IO uint32_t B2ADD;		/*!< Buffer 2 or next descriptor address */
	__IO uint32_t CTRL;			/*!< Buffer 1/2 byte counts and control */

} ENET_RXDESC_WR_T;

/**
 * @brief	Resets the ethernet interface
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 * @note	Resets the ethernet interface. This should be called prior to
 * Chip_ENET_Init with a small delay after this call.
 */
STATIC INLINE void Chip_ENET_Reset(LPC_ENET_T *pENET)
{
	/* This should be called prior to IP_ENET_Init. The MAC controller may
	   not be ready for a call to init right away so a small delay should
	   occur after this call. */
	pENET->DMA_MODE |= DMA_OPM_SWR;
	while(pENET->DMA_MODE & DMA_OPM_SWR);
}

/**
 * @brief	Sets the address of the interface
 * @param	pENET	: The base of ENET peripheral on the chip
 * @param	macAddr	: Pointer to the 6 bytes used for the MAC address
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_SetADDR(LPC_ENET_T *pENET, uint8_t index, uint8_t dmaCh, const uint8_t *macAddr)
{
	/* Save MAC address */
	pENET->MAC_ADDR_LOWHIGH[index][1] = ((uint32_t) macAddr[2] << 24) |
						   ((uint32_t) macAddr[3] << 16) | ((uint32_t) macAddr[4] << 8) |
						   ((uint32_t) macAddr[5]);
	pENET->MAC_ADDR_LOWHIGH[index][0] = ((uint32_t) macAddr[0] << 8) |
							((uint32_t) macAddr[1]) | MAC_ADRH_DCS(dmaCh) | MAC_ADRH_EN;
}

/**
 * @brief	Sets up the PHY link clock divider and PHY address
 * @param	pENET	: The base of ENET peripheral on the chip
 * @param	div		: Divider index, not a divider value, see user manual
 * @param	addr	: PHY address, used with MII read and write
 * @return	Nothing
 */
void Chip_ENET_SetupMII(LPC_ENET_T *pENET, uint32_t div, uint8_t addr);

/**
 * @brief	Starts a PHY write via the MII
 * @param	pENET	: The base of ENET peripheral on the chip
 * @param	reg		: PHY register to write
 * @param	data	: Data to write to PHY register
 * @return	Nothing
 * @note	Start a PHY write operation. Does not block, requires calling
 * IP_ENET_IsMIIBusy to determine when write is complete.
 */
void Chip_ENET_StartMIIWrite(LPC_ENET_T *pENET, uint8_t reg, uint16_t data);

/**
 * @brief	Starts a PHY read via the MII
 * @param	pENET	: The base of ENET peripheral on the chip
 * @param	reg		: PHY register to read
 * @return	Nothing
 * @note	Start a PHY read operation. Does not block, requires calling
 * IP_ENET_IsMIIBusy to determine when read is complete and calling
 * IP_ENET_ReadMIIData to get the data.
 */
void Chip_ENET_StartMIIRead(LPC_ENET_T *pENET, uint8_t reg);

/**
 * @brief	Returns MII link (PHY) busy status
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Returns true if busy, otherwise false
 */
STATIC INLINE bool Chip_ENET_IsMIIBusy(LPC_ENET_T *pENET)
{
	return (pENET->MAC_MDIO_ADDR & MAC_MIIA_GB) ? true : false;
}

/**
 * @brief	Returns the value read from the PHY
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Read value from PHY
 */
STATIC INLINE uint16_t Chip_ENET_ReadMIIData(LPC_ENET_T *pENET)
{
	return pENET->MAC_MDIO_DATA;
}

/**
 * @brief	Enables ethernet transmit
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_TXEnable(LPC_ENET_T *pENET)
{
	pENET->MAC_CFG |= MAC_CFG_TE;
}

/**
 * @brief Disables ethernet transmit
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_TXDisable(LPC_ENET_T *pENET)
{
	pENET->MAC_CFG &= ~MAC_CFG_TE;
}

/**
 * @brief	Enables ethernet transmit
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_StartDMATx(LPC_ENET_T *pENET, uint8_t channel)
{
	pENET->DMA_CHANNEL[channel].DMA_CHx_TX_CTRL |= DMA_TXCTL_ST;
}

/**
 * @brief	Enables ethernet transmit
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_StopDMATx(LPC_ENET_T *pENET, uint8_t channel)
{
	pENET->DMA_CHANNEL[channel].DMA_CHx_TX_CTRL &= ~DMA_TXCTL_ST;
}
/**
 * @brief	Enables ethernet packet reception
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_RXEnable(LPC_ENET_T *pENET)
{
	pENET->MAC_CFG |= MAC_CFG_RE;
}

/**
 * @brief	Disables ethernet packet reception
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_RXDisable(LPC_ENET_T *pENET)
{
	pENET->MAC_CFG &= ~MAC_CFG_RE;
}

/**
 * @brief	Enables ethernet packet reception
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_StartDMARx(LPC_ENET_T *pENET, uint8_t channel)
{
	pENET->DMA_CHANNEL[channel].DMA_CHx_RX_CTRL |= DMA_RXCTL_SR;
}

/**
 * @brief	Enables ethernet packet reception
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_StopDMARx(LPC_ENET_T *pENET, uint8_t channel)
{
	pENET->DMA_CHANNEL[channel].DMA_CHx_RX_CTRL &= ~DMA_RXCTL_SR;
}

/**
 * @brief	Enables ethernet receive queue n
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_EnableRxQueue(LPC_ENET_T *pENET, uint8_t channel)
{
	pENET->MAC_RXQ_CTRL[0] = (pENET->MAC_RXQ_CTRL[0] & ~(3 << (channel << 1))) | (1 << (channel  << 1));
}

/**
 * @brief	Disables ethernet receive queue n
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_DisableRxQueue(LPC_ENET_T *pENET, uint8_t channel)
{
	pENET->MAC_RXQ_CTRL[0] = (pENET->MAC_RXQ_CTRL[0] & ~(3 << (channel << 1)));
}

/**
 * @brief	Enable RMII ethernet operation
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 * @note	This function must be called to enable the internal
 * RMII PHY, and must be called before calling any Ethernet
 * functions.
 */
STATIC INLINE void Chip_ENET_RMIIEnable(LPC_ENET_T *pENET)
{
	*(uint32_t *)(LPC_SYSCON_BASE + 0x450) |= (1 << 2);
}

/**
 * @brief	Enable MII ethernet operation
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 * @note	This function must be called to enable the
 * MII PHY, and must be called before calling any Ethernet
 * functions.
 */
STATIC INLINE void Chip_ENET_MIIEnable(LPC_ENET_T *pENET)
{
	*(uint32_t *)(LPC_SYSCON_BASE + 0x450) &= ~(1 << 2);
}

/**
 * @brief	Sets full or half duplex for the interface
 * @param	pENET	: The base of ENET peripheral on the chip
 * @param	full	: true to selected full duplex, false for half
 * @return	Nothing
 */
void Chip_ENET_SetDuplex(LPC_ENET_T *pENET, bool full);

/**
 * @brief	Sets speed for the interface
 * @param	pENET		: The base of ENET peripheral on the chip
 * @param	speed100	: true to select 100Mbps mode, false for 10Mbps
 * @return	Nothing
 */
void Chip_ENET_SetSpeed(LPC_ENET_T *pENET, bool speed100);

/**
 * @brief	Configures the initial ethernet descriptors
 * @param	pENET		: The base of ENET peripheral on the chip
 * @param	pTXDescs	: Pointer to TX descriptor list
 * @param	pRXDescs	: Pointer to RX descriptor list
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_InitDescriptors(LPC_ENET_T *pENET, uint8_t channel, ENET_TXDESC_RD_T *pTXDescStart, ENET_TXDESC_RD_T *pTXDescEnd,
												ENET_RXDESC_RD_T *pRXDescStart, ENET_RXDESC_RD_T *pRXDescEnd)
{
	/* Setup descriptor list base addresses */
	pENET->DMA_CHANNEL[channel].DMA_CHx_TXDESC_LIST_ADDR = ((uint32_t) pTXDescStart) & ~0x03; /* Address should be word aligned */
	pENET->DMA_CHANNEL[channel].DMA_CHx_TXDESC_TAIL_PTR  = ((uint32_t) pTXDescEnd) & ~0x03; /* Address should be word aligned */
	pENET->DMA_CHANNEL[channel].DMA_CHx_RXDESC_LIST_ADDR = ((uint32_t) pRXDescStart) & ~0x03; /* Address should be word aligned */
	pENET->DMA_CHANNEL[channel].DMA_CHx_RXDESC_TAIL_PTR  = ((uint32_t) pRXDescEnd) & ~0x03; /* Address should be word aligned */
}

/**
 * @brief	Configures the initial ethernet descriptors
 * @param	pENET		: The base of ENET peripheral on the chip
 * @param	pTXDescs	: Pointer to TX descriptor list
 * @param	pRXDescs	: Pointer to RX descriptor list
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_SetDescRingLength(LPC_ENET_T *pENET, uint8_t channel, uint16_t txRingLen, uint16_t rxRingLen)
{
	/* Set Tx and Rx Desc ring length */
	pENET->DMA_CHANNEL[channel].DMA_CHx_TXDESC_RING_LENGTH = ((uint32_t) txRingLen) & 0x3ff;
	pENET->DMA_CHANNEL[channel].DMA_CHx_RXDESC_RING_LENGTH = ((uint32_t) rxRingLen) & 0x3ff;
}

/**
 * @brief	Starts receive polling of RX descriptors
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_SetDescSkipLen(LPC_ENET_T *pENET, uint8_t channel, uint8_t skipLen, bool pblx8 )
{
	pENET->DMA_CHANNEL[channel].DMA_CHx_CTRL = (pENET->DMA_CHANNEL[channel].DMA_CHx_CTRL & ~DMA_CTL_DSL(7)) |  DMA_CTL_DSL(skipLen);
}

/**
 * @brief	Starts receive polling of RX descriptors
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_SetTxBurstLen(LPC_ENET_T *pENET, uint8_t channel, uint8_t pbl, bool pblx8 )
{
	if(pblx8) {
		pENET->DMA_CHANNEL[channel].DMA_CHx_CTRL |= DMA_CTL_PBL8X;
		pENET->DMA_CHANNEL[channel].DMA_CHx_TX_CTRL = (pENET->DMA_CHANNEL[channel].DMA_CHx_TX_CTRL & ~DMA_TXCTL_PBL(0x3f)) | DMA_TXCTL_PBL(pbl);
	}
	else {
		pENET->DMA_CHANNEL[channel].DMA_CHx_CTRL &= ~DMA_CTL_PBL8X;
		pENET->DMA_CHANNEL[channel].DMA_CHx_TX_CTRL = (pENET->DMA_CHANNEL[channel].DMA_CHx_TX_CTRL & ~DMA_TXCTL_PBL(0x3f)) | DMA_TXCTL_PBL(pbl);
	}
}

/**
 * @brief	Starts receive polling of RX descriptors
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE void Chip_ENET_SetRxBurstLen(LPC_ENET_T *pENET, uint8_t channel, uint8_t pbl, bool pblx8 )
{
	if(pblx8) {
		pENET->DMA_CHANNEL[channel].DMA_CHx_CTRL |= DMA_CTL_PBL8X;
		pENET->DMA_CHANNEL[channel].DMA_CHx_RX_CTRL = (pENET->DMA_CHANNEL[channel].DMA_CHx_RX_CTRL & ~DMA_RXCTL_PBL(0x3f)) | DMA_RXCTL_PBL(pbl);
	}
	else {
		pENET->DMA_CHANNEL[channel].DMA_CHx_CTRL &= ~DMA_CTL_PBL8X;
		pENET->DMA_CHANNEL[channel].DMA_CHx_RX_CTRL = (pENET->DMA_CHANNEL[channel].DMA_CHx_RX_CTRL & ~DMA_RXCTL_PBL(0x3f)) | DMA_RXCTL_PBL(pbl);
	}
}

/**
 * @brief	Initialize ethernet interface
 * @param	pENET	: The base of ENET peripheral on the chip
 * @param	phyAddr : Address of the Phy [valid range 0 to 31]
 * @return	Nothing
 * @note	Performs basic initialization of the ethernet interface in a default
 * state. This is enough to place the interface in a usable state, but
 * may require more setup outside this function.
 */
void Chip_ENET_Init(LPC_ENET_T *pENET, uint32_t phyAddr);

/**
 * @brief	De-initialize the ethernet interface
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
void Chip_ENET_DeInit(LPC_ENET_T *pENET);

/**
 * @brief	Starts transmit polling of TX descriptors
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE uint32_t Chip_ENET_IntStatus(LPC_ENET_T *pENET)
{
	/* Start transmit polling */
	return pENET->DMA_INTR_STAT;
}

/**
 * @brief	Starts transmit polling of TX descriptors
 * @param	pENET	: The base of ENET peripheral on the chip
 * @return	Nothing
 */
STATIC INLINE uint32_t Chip_ENET_ChannelStatus(LPC_ENET_T *pENET, uint8_t channel)
{
	/* Start transmit polling */
	return pENET->DMA_CHANNEL[channel].DMA_CHx_STAT;
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __ENET_546XX_H_ */
