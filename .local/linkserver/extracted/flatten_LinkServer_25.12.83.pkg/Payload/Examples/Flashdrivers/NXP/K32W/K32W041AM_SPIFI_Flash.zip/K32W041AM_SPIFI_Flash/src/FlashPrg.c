//*****************************************************************************
// FlashDev.c
// MCUXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2014-2015, 2017-2020, 2021, 2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************
#include "lpcx_flash_driver.h"

#include "fsl_device_registers.h"
#include "Eeprom.h"

#include <stdbool.h>

#include "pin_mux.h"

void BOARD_InitSPIFI(void) {
	uint32_t divisor;

	_BOARD_InitSPIFIPins();
	RESET_SetPeripheralReset(kSPIFI_RST_SHIFT_RSTn);
	/* Enable clock to block and set divider */
	CLOCK_AttachClk(kMAIN_CLK_to_SPIFI);
	divisor = CLOCK_GetSpifiClkFreq() / BOARD_SPIFI_CLK_RATE;
	CLOCK_SetClkDiv(kCLOCK_DivSpifiClk, divisor ? divisor : 1, false);
	RESET_ClearPeripheralReset(kSPIFI_RST_SHIFT_RSTn);
}

void BOARD_SetSpiFi_LowPowerEnter(void) {
	_BOARD_DeInitSPIFIPins();
}


// ************************************
// Flash driver functions
// ************************************

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t Init(void) {
	SYSCON->MEMORYREMAP = 0x0E400002;

	ee_err_t status = EEPROM_Init();
	EEPROM_SetRead();
	return status;
}

/*
 * De-Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t UnInit(void) {
	ee_err_t status = EEPROM_DeInit();
	return status;
}

/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  other - failure code
 */
#if !defined(DONT_PROVIDE_ERASECHIP)
uint32_t EraseChip(void) {
	ee_err_t status = EEPROM_ChipErase();
	while (EEPROM_isBusy());
	return status;
}
#endif // DONT_PROVIDE_ERASECHIP

/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t EraseSectors(uint32_t adr, uint32_t numsecs) {
	int32_t sz = gEepromParams_SectorSize_c * numsecs;

	// This should not happen at least when invoked by IDE, but it could happen when used from cmtool
	if (adr + sz > FlashDevice.DevAdr + FlashDevice.szDev) {
		sz = FlashDevice.DevAdr + FlashDevice.szDev - adr;
	}

	adr -= FlashDevice.DevAdr;
	ee_err_t status = EEPROM_EraseArea(&adr, &sz, false);
	while (EEPROM_isBusy());
	return status;
}

/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf) {
	// This should not happen at least when invoked by IDE, but it could happen when used from cmtool
	if (adr + sz > FlashDevice.DevAdr + FlashDevice.szDev) {
		sz = FlashDevice.DevAdr + FlashDevice.szDev - adr;
	}

	adr -= FlashDevice.DevAdr;
	ee_err_t status = EEPROM_WriteData(sz, adr, buf);
	return status;
}

/*
 *  Verify Flash Contents
 *    Parameter:      adr:  Start Address
 *                    sz:   Size (in bytes)
 *                    buf:  Data
 *    Return Value:   0 - OK, Failed - Address
 */
#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t adr, uint32_t sz, uint8_t *buf) {
	EEPROM_SetRead();
	int status = memcmp(buf, (uint8_t*) adr, sz);
	return status;
}
#endif // DONT_PROVIDE_VERIFY

