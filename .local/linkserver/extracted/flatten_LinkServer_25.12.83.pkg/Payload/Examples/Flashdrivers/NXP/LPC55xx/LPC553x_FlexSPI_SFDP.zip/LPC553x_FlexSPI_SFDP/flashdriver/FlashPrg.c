//*****************************************************************************
// FlashPrg.c
//
// MCUXpresso IDE flash driver - Flash Programming Functions
//
// LPC553x/LPC55S3x FlexSPI SFDP based drivers
//
//*****************************************************************************
//
// Copyright 2021, 2023 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include <stdint.h>
// For memcmp used in Verify()
#include <string.h>

#include "fsl_flexspi_nor_flash.h"
#include "fsl_common.h"
#include "clock_config.h"

#include "lpcx_flash_driver.h"
#include "FlashConfig.h"


Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;

#define MEM_WriteU32(addr, value) (*((volatile uint32_t *)(addr)) = value)

uint32_t SystemCoreClock;

flexspi_nor_config_t flashConfig;
serial_nor_config_option_t configOption;

// ************************************
// Flash driver functions
// ************************************

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  !=0 - Failed
 */
uint32_t Init (void)
{
    status_t status;

    // ****************
    UnInit();

    // ****************
    CLOCK_EnableClock(kCLOCK_Iocon);
    BOARD_BootClockPLL150M();

    // ****************
    // Safe clock configurations
    // - enables clocks (ROM, SRAM, FLASH FLEXSPI, IOCON, GPIO1/2)
    // - automatic clock gating is overridden (Clock gating is disabled)
    #define AHBCLKCTRL0 (*((volatile unsigned long *) 0x50000200))
    #define AHBCLKCTRLSET0 (*((volatile unsigned long *) 0x50000220))
    #define AUTOCLKGATEOVERRIDE (*((volatile unsigned long *) 0x50000E04))
    AHBCLKCTRLSET0 = 0xEDFC;
    AUTOCLKGATEOVERRIDE = 0xC0DE0000 | (0xFF);

    // ****************
    // CACHE64_CTRL0->CCR = 0;
    MEM_WriteU32(0x4002E800, 0);
    // CACHE64_POLSEL0->POLSEL = 0;
    MEM_WriteU32(0x4002E01C, 0);

    // ****************
    configOption.option0.U = CONFIG_OPTION0;
    configOption.option1.U = CONFIG_OPTION1;
    memset((void *)&flashConfig, 0U, sizeof(flexspi_nor_config_t));

    status = FLEXSPI_NorFlash_GetConfig(0, &flashConfig, &configOption);
    if (status) {
        return (status);
    }

    status = FLEXSPI_NorFlash_Init(0, &flashConfig);
    if (status) {
        return (status);
    }

    // **********************************
    // Now updated the FlashDevice table using the settings for the
    // detected SPIFI device. These new values will be read back by
    // the debugger upon return from Init()
    // **********************************
    // NOTE
    // flashConfig.pageSize/sectorSize/blockSize are 0
    // if the jumpers are not properly set for external flash access.
    // Update the FlashDevice info if we get non zero values,
    // to avoid debug issues in internal flash for an app that has
    // external flash memory region present but not used
    // (expected to get failures if external flash is erased/programmed).
    // **********************************
    if (flashConfig.pageSize > 0 &&
        flashConfig.sectorSize > 0 &&
        flashConfig.blockSize > 0) {
        // Update FlashDevice device size
        FlashDevice.szDev = flashConfig.memConfig.sflashA1Size;

       // Update FlashDevice sector size - currently hard wired
       // Note: SPIFI devices are assumed to only support a single size
       //FlashDevice.sectors[0].szSector = config.sectorSize;
       FlashDevice.sectors[0].szSector = flashConfig.blockSize;
    }

    // Update FlashDevice page size
    // Note that this is not the true page size from the detected SPIFI device, but
    // is actually the size of a single buffer of data that the debugger will send
    // down to the flash driver. This will normally be 16KB (limited by the available
    // RAM on the device) but cannot be larger than a single sector.

    if (FlashDevice.sectors[0].szSector < 16 * 1024)
        FlashDevice.szPage = FlashDevice.sectors[0].szSector;
    else
        FlashDevice.szPage = 16 * 1024; // use 16KB pseudo pages for now

    // Now use the flash driver mailbox to transfer info on the
    // updated device back to the host debugger.

#ifdef NDEBUG
    // Address of flash driver mailbox created by linker script
    // Note that this is skipped for debug builds of the driver
    extern unsigned int _b_mailbox;
    unsigned int *MAILBOX_PTR = &_b_mailbox;
    // Use mailbox 'status' word to pass address of message block
    *(MAILBOX_PTR+4) = (uint32_t)&Mailbox_Init_DynInfo;
#endif
    // Address of FlashDevice structure within driver
    Mailbox_Init_DynInfo.dyn_dev = &FlashDevice;

    // Pointer to string containing name of identified device

    // Ideally this should be the JEDEC ID, but no obvious way to get this
    Mailbox_Init_DynInfo.devname = "JEDEC_FlexSPI_Device";

    // Unused - partID information
    Mailbox_Init_DynInfo.partid_bytes = 0;
    Mailbox_Init_DynInfo.partid = 0;

    // **********************************
    return 0; // Finished without Errors
}

uint32_t UnInit(void) {

    // Reset PMC LDO (PMC.LDOPMU,DCDC0,LDOCORE0)
    *(volatile uint32_t*)0x4002001c = 0x0109CF18;
    *(volatile uint32_t*)0x40020010 = 0x010A767E;
    *(volatile uint32_t*)0x40020024 = 0x2801006B;

    /* De-select GDET as source for CHIP_RESET */
    //ITRC0->OUT_SEL[4][0] = 0xAAAAAAAA;
    //ITRC0->OUT_SEL[4][1] = 0xAAAAAAAA;
    *(volatile unsigned int *)0x4000f028 = 0xAAAAAAAA;
    *(volatile unsigned int *)0x4000f02c = 0xAAAAAAAA;
    /* Disable GDET_IRQ (bit 1) in ELS_INT_ENABLE */
    //ELS->ELS_INT_ENABLE &= ~S50_ELS_INT_ENABLE_GDET_INT_EN_MASK;
    *(volatile unsigned int *)0x40030040 &= ~(0x2U);

    return 0; // Finished without Errors
}


#if !defined(DONT_PROVIDE_ERASECHIP)
/*  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseChip(void) {

    status_t status = 0;
    status = FLEXSPI_NorFlash_EraseAll(0, &flashConfig);
    return (status);
}

#endif


uint32_t EraseSectors(uint32_t adr, uint32_t numsecs) {

    status_t status = 0;

#if defined (USE_SECURE_FLASHADDR)
    // Mask out bit 28 when calling ROM flash routines for programming in
    // secure flash address range
    adr &= ~(1UL << 28);
#endif

#if defined (ERASE_IN_ONE)
    // Make single call to erase all of the required sectors (blocks).
    // Simpler, but actually appears to be slower than erasing by block
    status =  FLEXSPI_NorFlash_Erase(0, &flashConfig,
                    adr - TRUE_FLASH_BASE_ADDR,
                    (numsecs * flashConfig.blockSize));
#else
    adr -= TRUE_FLASH_BASE_ADDR;
    while (numsecs) {
        status = FLEXSPI_NorFlash_EraseBlock(0, &flashConfig, adr);
        if (status) {
            break;
        }
        numsecs--;
        adr += flashConfig.blockSize;
    }
#endif
    return status;
}


/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf) {

    status_t status = 0;
    uint32_t page = 0;

#if defined (USE_SECURE_FLASHADDR)
    // Mask out bit 28 when calling ROM flash routines for programming in
    // secure flash address range
    adr &= ~(1UL << 28);
#endif

    while (sz) {

        status =  FLEXSPI_NorFlash_ProgramPage(0, &flashConfig,
                    adr - TRUE_FLASH_BASE_ADDR,
                    (void *)(buf + (page * flashConfig.pageSize)));
        if (status) {
            return (status);
        }

        sz = sz - flashConfig.pageSize;   // Decrease remaining size by page
        adr = adr + flashConfig.pageSize; // Update adr base by page
        page ++;                          // Next page
    }
    return (status);

}


#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t adr, uint32_t sz, uint8_t *buf) {

    uint32_t status = 0;

#if defined (USE_SECURE_FLASHADDR)
    // Mask out bit 28 when calling ROM flash routines for programming in
    // secure flash address range
    adr &= ~(1UL << 28);
#endif

    status = memcmp((void *) adr, buf, sz);

    return (status);
}
#if defined (USE_SMALL_MEMCMP)
int memcmp(const void *a, const void *b, size_t n)
{   const unsigned char *ac = (const unsigned char *)a,
    *bc = (const unsigned char *)b;
    while (n-- > 0)
    {   unsigned char c1,c2; /* unsigned cmp seems more intuitive */
        if ((c1 = *ac++) != (c2 = *bc++)) return c1 - c2;
    }
return 0;
}
#endif // USE_SMALL_MEMCMP
#endif // DONT_PROVIDE_VERIFY
