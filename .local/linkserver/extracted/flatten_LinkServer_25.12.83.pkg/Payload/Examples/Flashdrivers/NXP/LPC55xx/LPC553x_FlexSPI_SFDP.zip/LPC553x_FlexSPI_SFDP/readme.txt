LPC55S36-EVK LinkServer/CMSIS-DAP Flash Drivers
===========================================================

MCUXpresso IDE LinkServer/CMSIS-DAP flash driver example for OSPI
flash device using ROM based FLEXSPI Flash Driver API.


Requirements for Building
=========================

The use of MCUXpresso IDE v11.4.0 or later is required for building
this project.

The project is created for a Generic (Cortex) M33 MCU and so generated
code will be compatible with the LPC55x3x MCUs. This also removes any
requirement for a specific SDK to be installed for use.

The LPCXFlashDriverLib project must also be imported into the flash
driver project's workspace. For correct linkage ensure that both debug
and release variants of this project must be manually pre-built.

Starting with MCUXpresso IDE version 11.1.0 most LinkServer flash drivers
now implement a Verify Same operation (via a flash hashing mechanism) for
any flash sector that are unchanged from previous debug operations.
To make use of this feature, use the Release_SectorHashing variant of the
LPCXFlashDriverLib project, and enable the corresponding opmap bit in the
flash driver's linker script.

Note that by default only Octal Flash is fitted on the LPC55S36-EVK
connected to FlexSPI port A (LPC55S36 FlexSPI supports port A only).

Build Configurations
==================== 
 
There are 3 build configurations within the project:

'Debug'
-------
This build configuration can be used to generate a test version of the
flash driver that can be run within the MCUXPresso IDE debug environment.
This configuration builds the flash driver wrapped by an interface that
mimics the interface used by MCUXpresso IDE when programming a project
executable/binary into flash.

This configuration can be very useful when adding support for a new flash
device, to ensure that basic operation works, before trying out the full
flash driver.

IMPORTANT NOTE (when using an external LPC-Link2/MCU-Link probe):
When this flash driver is run in debug mode, there is an extra step needed:
"Pull ISP on reset (on LPC-Link2)" workspace preference must be unticked in
Preferences -> MCUXpresso IDE -> Debug Options -> LinkServer Options.
This is required to make sure that the IDE doesn't issue a WireIspReset
command to LinkServer during the connection sequence - as this inferferes
with the preconnect mechanism.
Normally the IDE auto-disables the use of WireIspReset on RT parts, but
since this project is a Generic-M33 one (not part-specific), the setting
needs to be manually modified.
Please remember to revert the workspace setting to the default value after
you've finished working with the debug version of the flash driver.

'LPC553x_FlexSPI_A_MXIC_OPI' and ''LPC553x_FlexSPI_A_MXIC_OPI_S'
-------------------------------------------------------------------
These create in a project directory called 'builds' the actual driver
'LPC553x_FlexSPI_A_MXIC_OPI.cfx' and 'LPC553x_FlexSPI_A_MXIC_OPI_S.cfx'
suitable for the Macronix Octal Flash device connected to FlexSPI
port A on the EVK board.

Each build configuration except Debug produces a corresponding cfx driver
image in 'builds' folder. The cfx driver is suitable for being referenced
from the IDE. This can be achieved by copying the cfx file to the application
project, and editing the Memory Configuration to point to the flash driver
to use for the Flash memory block.

Linker Scripts
==============

This project forgoes the use of automatic managed linkerscript generation
due its special requirements for image layout.

Instead a directory containing a linker script per configuration (debug /
release) is supplied. These linker scripts link to use on-chip SRAM.

The linker script used for building release versions of the flash driver
defines a special __opmap_val linker symbol. Its purpose is to inform
the LinkServer about the driver's capabilities, so it is important that
the value matches the driver's implementation.


Driver Performance
==================

In testing this driver can achieve programming speeds of around:

..... 104 KB/sec with MCU-Link on-board probe


Supporting Other Flash Devices
==============================

This example flash driver targets only the OSPI device
present on the EVK board.

The ROM based FLEXSPI Flash Driver API set consists of several separate
APIs to reduce the effort on enabling the external FLASH support.

Adding support for another serial NOR flash device is usually
only a matter of defining the appropriate serial_nor_config_option_t
configuration options and FlexSPI port connection.
For more information consult the LPC55x3x Reference Manual, 
FlexSPI NOR Configuration Option Block.


FlexSPI Flash reset
===================

While the project is structured in such a way to create flash drivers
which are independent of a particular board, note the following area
that may need consideration in case of targeting other boards.

The driver initialization function does not implement a special sequence
to reset the external flash since the EVK does not have a dedicated GPIO pin
for this purpose.
This may need to be updated in case of custom boards, if a GPIO pin is being
used to reset the external flash.
