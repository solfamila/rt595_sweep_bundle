/*
 * @brief LPC17xx/40xx Chip specific SystemInit
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/
#if defined(CHIP_LPC175X_6X)
void Chip_SetupIrcClocking(void)
{
	/* Disconnect the Main PLL if it is connected already */
	if (Chip_Clock_IsMainPLLConnected()) {
		Chip_Clock_DisablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_CONNECT);
	}

	/* Disable the PLL if it is enabled */
	if (Chip_Clock_IsMainPLLEnabled()) {
		Chip_Clock_DisablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);
	}

	Chip_Clock_SetCPUClockDiv(0);
	Chip_Clock_SetMainPLLSource(SYSCTL_PLLCLKSRC_IRC);

	/* FCCO = ((44+1) * 2 * 4MHz) / (0+1) = 360MHz */
	Chip_Clock_SetupPLL(SYSCTL_MAIN_PLL, 44, 0);

	Chip_Clock_EnablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);

	Chip_Clock_SetCPUClockDiv(2);
	while (!Chip_Clock_IsMainPLLLocked()) {} /* Wait for the PLL to Lock */

	Chip_Clock_EnablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_CONNECT);
}

void Chip_SetupXtalClocking(void)
{
	/* Disconnect the Main PLL if it is connected already */
	if (Chip_Clock_IsMainPLLConnected()) {
		Chip_Clock_DisablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_CONNECT);
	}

	/* Disable the PLL if it is enabled */
	if (Chip_Clock_IsMainPLLEnabled()) {
		Chip_Clock_DisablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);
	}

	/* Enable the crystal */
	if (!Chip_Clock_IsCrystalEnabled())
		Chip_Clock_EnableCrystal();
	while(!Chip_Clock_IsCrystalEnabled()) {}

	/* Set PLL0 Source to Crystal Oscillator */
	Chip_Clock_SetCPUClockDiv(0);
	Chip_Clock_SetMainPLLSource(SYSCTL_PLLCLKSRC_MAINOSC);

	/* FCCO = ((15+1) * 2 * 12MHz) / (0+1) = 384MHz */
	Chip_Clock_SetupPLL(SYSCTL_MAIN_PLL, 15, 0);

	Chip_Clock_EnablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);

	/* 384MHz / (3+1) = 96MHz */
	Chip_Clock_SetCPUClockDiv(3);
	while (!Chip_Clock_IsMainPLLLocked()) {} /* Wait for the PLL to Lock */

	Chip_Clock_EnablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_CONNECT);
}
#endif

#if (defined(CHIP_LPC177X_8X) | defined(CHIP_LPC40XX))
/* Clock and PLL initialization based on the internal oscillator */
void Chip_SetupIrcClocking(void)
{
	/* Clock the CPU from SYSCLK, in case if it is clocked by PLL0 */
	Chip_Clock_SetCPUClockSource(SYSCTL_CCLKSRC_SYSCLK);

	/* Disable the PLL if it is enabled */
	if (Chip_Clock_IsMainPLLEnabled()) {
		Chip_Clock_DisablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);
	}

	/* It is safe to switch the PLL Source to IRC */
	Chip_Clock_SetMainPLLSource(SYSCTL_PLLCLKSRC_IRC);

	/* FCCO = 12MHz * (9+1) * 2 * (0+1) = 240MHz */
	/* Fout = FCCO / ((0+1) * 2) = 120MHz */
	Chip_Clock_SetupPLL(SYSCTL_MAIN_PLL, 9, 0);

	Chip_Clock_EnablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);
	Chip_Clock_SetCPUClockDiv(1);
	while (!Chip_Clock_IsMainPLLLocked()) {} /* Wait for the PLL to Lock */
	Chip_Clock_SetCPUClockSource(SYSCTL_CCLKSRC_MAINPLL);

	/* Peripheral clocking will be derived from PLL0 with a divider of 2 (60MHz) */
	Chip_Clock_SetPCLKDiv(2);
}

/* Clock and PLL initialization based on the external oscillator */
void Chip_SetupXtalClocking(void)
{
	/* Enable the crystal */
	if (!Chip_Clock_IsCrystalEnabled())
		Chip_Clock_EnableCrystal();

	while(!Chip_Clock_IsCrystalEnabled()) {}

	/* Clock the CPU from SYSCLK, in case if it is clocked by PLL0 */
	Chip_Clock_SetCPUClockSource(SYSCTL_CCLKSRC_SYSCLK);

	/* Disable the PLL if it is enabled */
	if (Chip_Clock_IsMainPLLEnabled()) {
		Chip_Clock_DisablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);
	}

	/* It is safe to switch the PLL Source to Crystal Oscillator */
	Chip_Clock_SetMainPLLSource(SYSCTL_PLLCLKSRC_MAINOSC);

	/* FCCO = 12MHz * (9+1) * 2 * (0+1) = 240MHz */
	/* Fout = FCCO / ((0+1) * 2) = 120MHz */
	Chip_Clock_SetupPLL(SYSCTL_MAIN_PLL, 9, 0);

	Chip_Clock_EnablePLL(SYSCTL_MAIN_PLL, SYSCTL_PLL_ENABLE);
	Chip_Clock_SetCPUClockDiv(1);

	while (!Chip_Clock_IsMainPLLLocked()) {} /* Wait for the PLL to Lock */
	Chip_Clock_SetCPUClockSource(SYSCTL_CCLKSRC_MAINPLL);

	/* Peripheral clocking will be derived from PLL0 with a divider of 2 (60MHz) */
	Chip_Clock_SetPCLKDiv(2);
}
#endif

/* Set up and initialize hardware prior to call to main */
void Chip_SystemInit(void)
{
	/* Setup Chip clocking */
	Chip_SetupIrcClocking();
}
