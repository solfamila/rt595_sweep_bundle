//*****************************************************************************
// FlashConfig.h
// MCUXpresso IDE Flash driver
// Config file for LPC553x/LPC55S3x FlexSPI SFDP based drivers
//*****************************************************************************
//
// Copyright 2021, 2023-2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#ifndef FLASHCONFIG_H_
#define FLASHCONFIG_H_

#include "fsl_flexspi_nor_flash.h"

extern flexspi_nor_config_t flashConfig;

#if defined (DEBUG)
#define LPC553x_FlexSPI_A_MXIC_OPI
#endif


// LPC55S3x Reference Manual - Chapter: FlexSPI NOR Configuration Option Block

#if defined (LPC553x_FlexSPI_A_MXIC_OPI) || defined (LPC553x_FlexSPI_A_MXIC_OPI_S)

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 4   : device_type (4 = Macronix Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 1   : max_freq
 */
#define CONFIG_OPTION0  0xC0400001

/*
 * 0x0 : Single Flash connected to Port A
 */
#define CONFIG_OPTION1  0x00000000

#endif

// =====================================
// Flash Base Address Information
// =====================================

#define TRUE_FLASH_BASE_ADDR 0x08000000

#if defined (LPC553x_FlexSPI_A_MXIC_OPI_S)
#define USE_SECURE_FLASHADDR
#define FLASH_BASE_ADDR 0x18000000
#else
#define FLASH_BASE_ADDR 0x08000000
#endif

#endif /* FLASHCONFIG_H_ */
