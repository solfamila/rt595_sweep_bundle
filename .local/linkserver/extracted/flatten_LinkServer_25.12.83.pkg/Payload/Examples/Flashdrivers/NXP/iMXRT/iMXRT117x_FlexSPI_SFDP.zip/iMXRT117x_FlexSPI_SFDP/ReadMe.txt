MIMXRT1180-EVK, MIMXRT1170-EVK and MIMXRT1160-EVK LinkServer/CMSIS-DAP Flash Drivers
====================================================================

MCUXpresso IDE LinkServer/CMSIS-DAP flash driver example for QSPI
and OPI flash devices using ROM based FLEXSPI Flash Driver API
suitable for MIMXRT1180-EVK, MIMXRT1170-EVK and MIMRT1160-EVK platforms.


Requirements for Building
=========================

The use of MCUXpresso IDE v11.4.0 or later is required for building
this project.

The project is created for a Generic (Cortex) M4 MCU and so generated
code will be compatible with the iMXRT118x/117x/116x MCUs. This also
removes any requirement for a specific SDK to be installed for use.

The LPCXFlashDriverLib project must also be imported into the flash
driver project's workspace. For correct linkage ensure that both debug
and release variants of this project must be manually pre-built.

Starting with MCUXpresso IDE version 11.1.0 most LinkServer flash drivers
now implement a Verify Same operation (via a flash hashing mechanism) for
any flash sector that are unchanged from previous debug operations.
To make use of this feature, use the Release_SectorHashing variant of the
LPCXFlashDriverLib project, and enable the corresponding opmap bit in the
flash driver's linker script.

Note that by default only QSPI Flash is connected on the MIMXRT1170-EVK
board to FlexSPI port A. In order to enable the OPI Flash, board-level
modifications are needed. This project is configured to produce flash
drivers also for the MXIC OPI devices on board of MIMXRT1170-EVK and
MIMXRT1160-EVK boards.

For RT1170, the driver allows being run on both M7 and M4 cores (to support
the case when the platform is configured for CM4 boot via fuse settings).

The driver disables the I/D-Cache in the initialization code. 

Connect and Reset scripts that manage the secondary core and possibly
FlexRAM are required to ensure driver operation.


Build Configurations
==================== 

There are multiple build configurations within the project:

'Debug'
-------
This build configuration can be used to generate a test version of the
flash driver that can be run within the MCUXPresso IDE debug environment.
This configuration builds the flash driver wrapped by an interface that
mimics the interface used by MCUXpresso IDE when programming a project
executable/binary into flash.

This configuration can be very useful when adding support for a new flash
device, to ensure that basic operation works, before trying out the full
flash driver.

'MIMXRT1170_SFDP_QSPI' and 'MIMXRT1160_SFDP_QSPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1170_SFDP_QSPI.cfx' and 'MIMXRT1160_SFDP_QSPI'
suitable for a SFDP QSPI Flash device connected to FlexSPI1.

'MIMXRT1170_SFDP_MXIC_OPI' and 'MIMXRT1160_SFDP_MXIC_OPI'
-------------------------------------------------------------------
These create in a project directory called 'builds' the actual driver
'MIMXRT1170_SFDP_MXIC_OPI.cfx' and 'MIMXRT1160_SFDP_MXIC_OPI.cfx'
suitable for the Macronix Octal Flash device connected to FlexSPI1 on the
EVK board.

'MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S' and 'MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S.cfx' and
'MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S.cfx' suitable for SFDP QSPI Flash device
connected to FlexSPI1 Port A or B, respectively. These drivers use the secure
flash base address.

'MIMXRT1180_SFDP_FlexSPI1_A_QSPI' and 'MIMXRT1180_SFDP_FlexSPI1_B_QSPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI1_A_QSPI.cfx' and 'MIMXRT1180_SFDP_FlexSPI1_B_QSPI.cfx'
suitable for SFDP QSPI Flash device connected to FlexSPI1 Port A or B,
respectively. These drivers use the non-secure flash base address.

'MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S' and 'MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI_S'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S.cfx' and
'MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S.cfx' suitable for SFDP MXIC OPI Flash
device connected to FlexSPI1 Port A or B, respectively. These drivers use the
secure flash base address.

'MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI' and 'MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI.cfx' and
'MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI.cfx' suitable for SFDP MXIC OPI Flash
device connected to FlexSPI1 Port A or B, respectively. These drivers use the
non-secure flash base address.

'MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S' and 'MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI_S'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S.cfx' and
'MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S.cfx' suitable for SFDP MICRON OPI Flash
device connected to FlexSPI1 Port A or B, respectively. These drivers use the
secure flash base address.

'MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI' and 'MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI.cfx' and
'MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI.cfx' suitable for SFDP MICRON OPI Flash
device connected to FlexSPI1 Port A or B, respectively. These drivers use the
non-secure flash base address.

'MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI_S' and 'MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI_S' and
'MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI_S' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI_S'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI_S.cfx' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI_S.cfx' and
'MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI_S.cfx' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI_S.cfx'
suitable for SFDP QSPI Flash device connected to FlexSPI2 Port A or B, respectively,
using the primary or secondary pin group respectively. These drivers use the secure
flash base address.

'MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI' and 'MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI' and
'MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI.cfx' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI.cfx' and
'MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI.cfx' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI.cfx'
suitable for SFDP QSPI Flash device connected to FlexSPI2 Port A or B, respectively,
using the primary or secondary pin group respectively. These drivers use the non-secure
flash base address.

'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S.cfx' and
'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S.cfx' suitable for SFDP MXIC OPI Flash
device connected to FlexSPI2 Port A+B combined, using the primary and secondary
pin group respectively. These drivers use the secure flash base address.

'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI.cfx' and
'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI.cfx' suitable for SFDP MXIC OPI Flash
device connected to FlexSPI2 Port A+B combined, using the primary and secondary
pin group respectively. These drivers use the non-secure flash base address.

'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S.cfx' and
'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S.cfx' suitable for SFDP MICRON OPI Flash
device connected to FlexSPI2 Port A+B combined, using the primary and secondary
pin group respectively. These drivers use the secure flash base address.

'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI' and 'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI'
---------------------------------------------------------------------
These create in a project directory called 'builds' the driver
'MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI.cfx' and
'MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI.cfx' suitable for SFDP MICRON OPI Flash
device connected to FlexSPI2 Port A+B combined, using the primary and secondary
pin group respectively. These drivers use the non-secure flash base address.

Each build configuration except Debug produces a corresponding cfx driver
image in 'builds' folder. The cfx driver is suitable for being referenced
from the IDE. This can be achieved by copying the cfx file to the application
project, and editing the Memory Configuration to point to the flash driver
to use for the Flash memory block.


Linker Scripts
==============

This project foregoes the use of automatic managed linkerscript generation
due its special requirements for image layout.

Instead a directory containing a linker script per configuration (debug /
release) is supplied. These linker scripts link to use on-chip SRAM and
assume 64KB is available.

The linker script used for building release versions of the flash driver
defines a special __opmap_val linker symbol. Its purpose is to inform
the LinkServer about the driver's capabilities, so it is important that
the value matches the driver's implementation.


Driver Performance
==================

In testing this driver can achieve programming speeds of around:

.....122 KB/s with LPC-Link2 Bridged Firmware 
..... 35 KB/s with OpenSDA DAPlink on board debug probe


Supporting Other Flash Devices
==============================

This example flash driver targets only the QSPI and MXIC OPI devices
present on the EVK board.

The ROM based FLEXSPI Flash Driver API set consists of several separate
APIs to reduce the effort on enabling the external FLASH support.

Adding support for another serial NOR flash device is usually
only a matter of defining the appropriate serial_nor_config_option_t
configuration options and FlexSPI port connection.
For more information consult the i.MX RT1170 Reference Manual, 
FlexSPI NOR Configuration Option Block.


FlexSPI Flash reset
===================

While the project is structured in such a way to create flash drivers
which are independent of a particular board, note the following area
that may need consideration in case of targeting other boards.

The driver initialization function implements a sequence to reset
the external flash via dedicated GPIO pin. The problem with the external
flash reset is that the actual pin that is being used is board-specific.
The RT1160/RT1170 EVK board is using GPIO_AD_03 pin as Flash_RST; RT1180-EVK boards use GPIO_AD_15 pin. This may need
to be updated in case of boards wired differently from the EVK.
