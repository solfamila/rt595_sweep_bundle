// Copyright 2013 Code Red Technologies Limited
// Copyright 2019 NXP
/***********************************************************************
 * Code Red Technologies Flash driver                                  *
 *                                                                     */
/***********************************************************************
 *                                                                     *
 * FlashPrg.C: Flash Programming Functions for S29AL016J (16-bit Bus)  *
 *             for use with Diolan LPC1850 / LPC4350 DB1 boards        *
 *                                                                     *
 ***********************************************************************/



#include "LPC18xx.h"                    /* LPC18xx definitions                */

#include "lpc18xx_cgu.h"
#include "lpc18xx_scu.h"

#define M8(adr)  (*((volatile unsigned char  *) (adr)))
#define M16(adr) (*((volatile unsigned short *) (adr)))
#define M32(adr) (*((volatile unsigned long  *) (adr)))

#define STACK_SIZE   64        // Stack Size


union fsreg {                  // Flash Status Register
  struct b  {
    unsigned int q0:1;
    unsigned int q1:1;
    unsigned int q2:1;
    unsigned int q3:1;
    unsigned int q4:1;
    unsigned int q5:1;
    unsigned int q6:1;
    unsigned int q7:1;
  } b;
  unsigned int v;
} fsr;

unsigned long base_adr;


/*
 * Check if Program/Erase completed
 *    Parameter:      adr:  Block Start Address
 *    Return Value:   0 - OK,  1 - Failed
 */

int Polling (unsigned long adr) {
  unsigned int q6;

  fsr.v = M16(adr);
  q6 = fsr.b.q6;
  do {
    fsr.v = M16(adr);
    if (fsr.b.q6 == q6) return (0);  // Done
    q6 = fsr.b.q6;
  } while (fsr.b.q5 == 0);           // Check for Timeout
  fsr.v = M16(adr);
  q6 = fsr.b.q6;
  fsr.v = M16(adr);
  if (fsr.b.q6 == q6) return (0);    // Done
  M16(adr) = 0xF0;                   // Reset Device
  return (1);                        // Failed
}


/*
 *  Initialize Flash Programming Functions
 *    Parameter:      adr:  Device Base Address
 *                    clk:  Clock Frequency (Hz)
 *                    fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int Init (unsigned long adr, unsigned long clk, unsigned long fnc) {

	if (fnc == 1) {
		__disable_irq();		// Disable interrupts

		base_adr = adr;

#ifdef NDEBUG
#ifdef USE_EXTERNAL_CRYSTAL
		CGU_Init();
#else  // Use 12 MHz IRC
		CGU_EnableEntity(CGU_CLKSRC_IRC, ENABLE);
		CGU_EntityConnect(CGU_CLKSRC_IRC,CGU_BASE_M3);
		/* Update Clock Frequency */
		CGU_UpdateClock();
#endif
#endif

		// Set all EMC related pins to the correct function

	    // Disable the EMC before changing pin configurations
		*(uint32_t *)0x40005000 = 0x0000000;      // Disable

	    // Data bus pins D[15:0]
		scu_pinmux(1,7,MD_PLN_FAST,FUNC3); // D0
		scu_pinmux(1,8,MD_PLN_FAST,FUNC3); // D1
		scu_pinmux(1,9,MD_PLN_FAST,FUNC3); // D2
		scu_pinmux(1,10,MD_PLN_FAST,FUNC3);// D3
		scu_pinmux(1,11,MD_PLN_FAST,FUNC3);// D4
		scu_pinmux(1,12,MD_PLN_FAST,FUNC3);// D5
		scu_pinmux(1,13,MD_PLN_FAST,FUNC3);// D6
		scu_pinmux(1,14,MD_PLN_FAST,FUNC3);// D7
		scu_pinmux(5,4,MD_PLN_FAST,FUNC2); // D8
		scu_pinmux(5,5,MD_PLN_FAST,FUNC2); // D9
		scu_pinmux(5,6,MD_PLN_FAST,FUNC2); // D10
		scu_pinmux(5,7,MD_PLN_FAST,FUNC2); // D11
		scu_pinmux(5,0,MD_PLN_FAST,FUNC2); // D12
		scu_pinmux(5,1,MD_PLN_FAST,FUNC2); // D13
		scu_pinmux(5,2,MD_PLN_FAST,FUNC2); // D14
		scu_pinmux(5,3,MD_PLN_FAST,FUNC2); // D15

	    // Address bus pins A[22:0]
		scu_pinmux(2,9,MD_PLN_FAST,FUNC3);  // A0
		scu_pinmux(2,10,MD_PLN_FAST,FUNC3); // A1
		scu_pinmux(2,11,MD_PLN_FAST,FUNC3); // A2
		scu_pinmux(2,12,MD_PLN_FAST,FUNC3); // A3
		scu_pinmux(2,13,MD_PLN_FAST,FUNC3); // A4
		scu_pinmux(1,0,MD_PLN_FAST,FUNC2);  // A5
		scu_pinmux(1,1,MD_PLN_FAST,FUNC2);  // A6
		scu_pinmux(1,2,MD_PLN_FAST,FUNC2);  // A7
		scu_pinmux(2,8,MD_PLN_FAST,FUNC3);  // A8
		scu_pinmux(2,7,MD_PLN_FAST,FUNC3);  // A9
		scu_pinmux(2,6,MD_PLN_FAST,FUNC2);  // A10
		scu_pinmux(2,2,MD_PLN_FAST,FUNC2);  // A11
		scu_pinmux(2,1,MD_PLN_FAST,FUNC2);  // A12
		scu_pinmux(2,0,MD_PLN_FAST,FUNC2);  // A13
		scu_pinmux(6,8,MD_PLN_FAST,FUNC1);  // A14
		scu_pinmux(6,7,MD_PLN_FAST,FUNC1);  // A15
		scu_pinmux(0xD,16,MD_PLN_FAST,FUNC2);  // A16
		scu_pinmux(0xD,15,MD_PLN_FAST,FUNC2);  // A17
		scu_pinmux(0xE,0,MD_PLN_FAST,FUNC3);  // A18
		scu_pinmux(0xE,1,MD_PLN_FAST,FUNC3);  // A19
		scu_pinmux(0xE,2,MD_PLN_FAST,FUNC3);  // A20
		scu_pinmux(0xE,3,MD_PLN_FAST,FUNC3);  // A21

	    //# Control signals
		scu_pinmux(1,5,MD_PLN_FAST,FUNC3);	// CS0
		scu_pinmux(1,6,MD_PLN_FAST,FUNC3);	// WE
		scu_pinmux(1,3,MD_PLN_FAST,FUNC3);	// OE

	    //# Enable the EMC before waitstate configurations
		*(uint32_t *)0x40005000 = 0x0000001;      // Enable

	    //# Configuration for flash on CS0 (14WS for 70ns memory @ 204 MHz core clock)
		*(uint32_t *)0x40005200 = 0x00000081;      // CS0: 16 bit, WE
		*(uint32_t *)0x40005208 = 0x00000000;      // CS0: WAITOEN = 0
		*(uint32_t *)0x4000520C = 0x000000014;      // CS0: WAITRD = 14


	} // if (fnc == 1)

	return (0);
}


/*
 *  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */

int UnInit (unsigned long fnc) {
  return (0);
}


/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseChip (void) {
  int ret_val;

  // Start Chip Erase Command
  M16(base_adr + 0xAAA) = 0xAA;
  M16(base_adr + 0x554) = 0x55;
  M16(base_adr + 0xAAA) = 0x80;
  M16(base_adr + 0xAAA) = 0xAA;
  M16(base_adr + 0x554) = 0x55;
  M16(base_adr + 0xAAA) = 0x10;

  do
	{
	  ret_val = Polling(base_adr);
    if (ret_val != 0) return (1);
	}
  while(M16(base_adr) != 0xFFFF);  // Verify first data	if it matches expected value(0xFFFF)

  return(0);
}


/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */

int EraseSector (unsigned long adr) {
  int ret_val;

  // Start Erase Sector Command
  M16(base_adr + 0xAAA) = 0xAA;
  M16(base_adr + 0x554) = 0x55;
  M16(base_adr + 0xAAA) = 0x80;
  M16(base_adr + 0xAAA) = 0xAA;
  M16(base_adr + 0x554) = 0x55;

  M16(adr) = 0x30;

  do {
    fsr.v = M16(adr);
  } while (fsr.b.q3 == 0);     // Wait for Sector Erase Timeout

  do
	{
	  ret_val = Polling(adr);
    if (ret_val != 0) return (1);
	}
  while(M16(adr) != 0xFFFF);	// Verify first data in the Sector if it matches expected value(0xFFFF)

  return(0);

}


/*
 *  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

int ProgramPage (unsigned long adr, unsigned long sz, unsigned char *buf) {
  int i, ret_val;
  unsigned short exp_val; 

  M16(adr) = 0xF0;    //Reset Command

  for (i = 0; i < ((sz+1)/2); i++)  {
    // Start Program Command
    M16(base_adr + 0xAAA) = 0xAA;
    M16(base_adr + 0x554) = 0x55;
    M16(base_adr + 0xAAA) = 0xA0;
    M16(adr) = *((volatile unsigned short *) buf);

    exp_val = *((unsigned short *) buf);

    do
    {
      ret_val = Polling(adr);
      if (ret_val != 0) return (1);
    }
    while(M16(adr) != exp_val);		 // Verify written data if it matches expected value

    buf += 2;
    adr += 2;
  }
  return (0);
}
