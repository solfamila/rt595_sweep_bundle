/*
 * @brief LPC18xx/43xx AES Engine driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

#define BOOTROM_BASE            0x10400100
#define AES_API_TABLE_OFFSET    0x2

static unsigned long *BOOTROM_API_TABLE;

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

static uint32_t (*aes_SetMode)(CHIP_AES_OP_MODE_T AesMode);
static void (*aes_LoadKey1)(void);
static void (*aes_LoadKey2)(void);
static void (*aes_LoadKeyRNG)(void);
static void (*aes_LoadKeySW)(uint8_t *pKey);
static void (*aes_LoadIV_SW)(uint8_t *pVector);
static void (*aes_LoadIV_IC)(void);
static uint32_t (*aes_Operate)(uint8_t *pDatOut, uint8_t *pDatIn, uint32_t size);
static uint32_t (*aes_ProgramKey1)(uint8_t *pKey);
static uint32_t (*aes_ProgramKey2)(uint8_t *pKey);

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* CHIP AES Initialisation function */
void Chip_AES_Init(void)
{
	uint32_t (*ROM_aes_Init)(void);

	BOOTROM_API_TABLE = *((unsigned long * *) BOOTROM_BASE + AES_API_TABLE_OFFSET);

	ROM_aes_Init      = (uint32_t (*)(void))BOOTROM_API_TABLE[0];
	aes_SetMode       = (uint32_t (*)(CHIP_AES_OP_MODE_T AesMode))BOOTROM_API_TABLE[1];
	aes_LoadKey1      = (void (*)(void))BOOTROM_API_TABLE[2];
	aes_LoadKey2      = (void (*)(void))BOOTROM_API_TABLE[3];
	aes_LoadKeyRNG    = (void (*)(void))BOOTROM_API_TABLE[4];
	aes_LoadKeySW     = (void (*)(uint8_t *pKey))BOOTROM_API_TABLE[5];
	aes_LoadIV_SW     = (void (*)(uint8_t *pVector))BOOTROM_API_TABLE[6];
	aes_LoadIV_IC     = (void (*)(void))BOOTROM_API_TABLE[7];
	aes_Operate       = (uint32_t (*)(uint8_t *pDatOut, uint8_t *pDatIn, uint32_t Size))BOOTROM_API_TABLE[8];
	aes_ProgramKey1   = (uint32_t (*)(uint8_t *pKey))BOOTROM_API_TABLE[9];
	aes_ProgramKey2   = (uint32_t (*)(uint8_t *pKey))BOOTROM_API_TABLE[10];

	ROM_aes_Init();
}

/* Set Operation mode in AES Engine */
uint32_t Chip_AES_SetMode(CHIP_AES_OP_MODE_T AesMode)
{
	return aes_SetMode(AesMode);
}

/* Load 128-bit user key in AES Engine */
void Chip_AES_LoadKey(uint32_t keyNum)
{
	if (keyNum) {
		aes_LoadKey2();
	}
	else {
		aes_LoadKey1();
	}
}

/* Load randomly generated key in AES engine */
void Chip_AES_LoadKeyRNG(void)
{
	aes_LoadKeyRNG();
}

/* Load 128-bit AES software defined user key */
void Chip_AES_LoadKeySW(uint8_t *pKey)
{
	aes_LoadKeySW(pKey);
}

/* Load 128-bit AES initialization vector */
void Chip_AES_LoadIV_SW(uint8_t *pVector)
{
	aes_LoadIV_SW(pVector);
}

/* Load IC specific 128-bit AES initialization vector */
void Chip_AES_LoadIV_IC(void)
{
	aes_LoadIV_IC();
}

/* Operate AES Engine */
uint32_t Chip_AES_Operate(uint8_t *pDatOut, uint8_t *pDatIn, uint32_t Size)
{
	return aes_Operate(pDatOut, pDatIn, Size);
}

/* Program 128-bit AES Key in OTP */
uint32_t Chip_AES_ProgramKey(uint32_t KeyNum, uint8_t *pKey)
{
	uint32_t status;

	if (KeyNum) {
		status = aes_ProgramKey2(pKey);
	}
	else {
		status = aes_ProgramKey1(pKey);
	}
	return status;
}
