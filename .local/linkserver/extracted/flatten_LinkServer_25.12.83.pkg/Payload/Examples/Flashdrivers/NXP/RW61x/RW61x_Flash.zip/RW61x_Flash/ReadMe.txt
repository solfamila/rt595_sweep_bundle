RW61x LinkServer/CMSIS-DAP Flash Drivers
====================================================================

MCUXpresso IDE LinkServer/CMSIS-DAP flash driver example for QSPI
flash devices suitable for RW61x platform.


Requirements for Building
=========================

The use of MCUXpresso IDE v11.6.0 or later is required for building
this project.

The project is created for the RW61x MCU and so an SDK with support
for this device is required.

The LPCXFlashDriverLib project must also be imported into the flash
driver project's workspace. For correct linkage ensure that both debug
and release variants of this project must be manually pre-built.

Starting with MCUXpresso IDE version 11.1.0 most LinkServer flash drivers
now implement a Verify Same operation (via a flash hashing mechanism) for
any flash sectors that are unchanged from previous debug operations.
To make use of this feature, use the Release_SectorHashing variant of the
LPCXFlashDriverLib project, and enable the corresponding opmap bit in the
flash driver's linker script.


Build Configurations
====================

There are multiple build configurations within the project:

'Debug'
-------
This build configuration can be used to generate a test version of the
flash driver that can be run within the MCUXPresso IDE debug environment.
This configuration builds the flash driver wrapped by an interface that
mimics the interface used by MCUXpresso IDE when programming a project
executable/binary into flash.

This configuration can be very useful when adding support for a new flash
device, to ensure that basic operation works, before trying out the full
flash driver.

'RW61X_FlexSPI_A_SFDP_QSPI' and 'RW61X_FlexSPI_A_SFDP_QSPI_S'
---------------------------------------------------------------------
This configuration creates in a project directory called 'builds' the driver
'RW61X_FlexSPI_A_SFDP_QSPI.cfx' and 'RW61X_FlexSPI_A_SFDP_QSPI_S.cfx'
suitable for an external Flash device of 128MB,
connected to the FlexSPI interface.

Each build configuration except Debug produces a corresponding cfx driver
image in 'builds' folder. The cfx driver is suitable for being referenced
from the IDE. This can be achieved by copying the cfx file to the application
project, and editing the Memory Configuration to point to the flash driver
to use for the Flash memory block.


Linker Scripts
==============

This project forgoes the use of automatic managed linkerscript generation
due its special requirements for image layout.

Instead a directory containing a linker script per configuration (debug /
release) is supplied. These linker scripts link to use on-chip SRAM and
assume 1MB is available.

The linker script used for building release versions of the flash driver
defines a special __opmap_val linker symbol. Its purpose is to inform
the LinkServer about the driver's capabilities, so it is important that
the value matches the driver's implementation.


Driver Performance
==================

In testing this driver can achieve programming speeds of around:

.....64kB/s with MCU-Link Firmware


Supporting Other Flash Devices
==============================

This example flash driver targets a single QSPI device only.

Adding support for another flash device is a matter of modifying
the implementation located in source/FlashPrg.c and source/FlashDev.c
