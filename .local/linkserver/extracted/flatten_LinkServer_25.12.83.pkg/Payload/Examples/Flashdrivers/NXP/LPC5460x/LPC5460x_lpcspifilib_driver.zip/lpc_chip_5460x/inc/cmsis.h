/*
 * @brief LPC5460x selective CMSIS inclusion file
 *
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __CMSIS_H_
#define __CMSIS_H_

#include "lpc_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Select correct CMSIS include file based on CORE_* definition */
#if defined(CORE_M4)
#include "cmsis_5460x.h"
typedef LPC5460X_IRQn_Type IRQn_Type;
#include "core_cm4.h"					/*!< Cortex-M4 processor and core peripherals      */
#elif defined(CORE_M0PLUS)
#include "cmsis_5460x_m0.h"
typedef LPC5460X_M0_IRQn_Type IRQn_Type;
#include "core_cm0plus.h"				/*!< Cortex-M0 Plus processor and core peripherals  */
#else
#error "No CORE_* definition is defined"
#endif

#ifdef __cplusplus
}
#endif

#endif /* __CMSIS_H_ */
