
//*****************************************************************************
// FlashDev.c
// MCUXpresso IDE Flash driver - Flash Device settings
//
// i.MX RT600 (rev B0) FlexSPI SFDP based drivers
//
//*****************************************************************************
//
// Copyright 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "FlashConfig.h"
#include "lpcx_flash_driver.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS,				// Driver Version, do not modify!

#if defined (MIMXRT600_FlexSPI_A_MXIC_OPI)
   "MIMXRT600_FlexSPI_A_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_B_MXIC_OPI)
   "MIMXRT600_FlexSPI_B_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_A_SFDP_QSPI)
   "MIMXRT600_FlexSPI_A_SFDP SDR QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_B_SFDP_QSPI)
   "MIMXRT600_FlexSPI_B_SFDP SDR QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_A_MXIC_OPI_S)
   "MIMXRT600_FlexSPI_A_MXIC_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_B_MXIC_OPI_S)
   "MIMXRT600_FlexSPI_B_MXIC_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_A_SFDP_QSPI_S)
   "MIMXRT600_FlexSPI_A_SFDP SDR QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT600_FlexSPI_B_SFDP_QSPI_S)
   "MIMXRT600_FlexSPI_B_SFDP SDR QSPI (Secure) "__DATE__" "__TIME__,
#else
#error "No driver defined"
#endif

   EXTSPIJ,     // Device Type

   FLASH_BASE_ADDR, // Device Start Address

   0x400000,   // Device Size ** Will be updated by call to Init() **
   0x100,      // Programming Page Size ** Will be updated by call to Init() **
   0,          // Reserved, must be 0
   0xFF,       // Initial Content of Erased Memory
   3000,       // Program Page Timeout
   6000,       // Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{0x10000, 0},   // Sector sizes ** Will be updated by call to Init() **
   {SECTOR_END}}
};


