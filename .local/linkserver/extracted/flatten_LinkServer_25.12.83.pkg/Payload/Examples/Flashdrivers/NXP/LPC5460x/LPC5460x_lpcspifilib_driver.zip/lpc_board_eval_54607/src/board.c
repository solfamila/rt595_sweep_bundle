/*
 * @brief LPCXpresso LPC54102 board file
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "board.h"
#include "retarget.h"
#include <string.h>

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

typedef struct {
	uint8_t port;
	uint8_t pin;
} PORT_PIN_T;

static const PORT_PIN_T ledBits[] = {{3, 14}, {3, 3}, {2, 2}};
static const uint32_t ledBits_ct = sizeof(ledBits) / sizeof(PORT_PIN_T);

static const PORT_PIN_T btnBits[] = {{1, 1}, {0, 6}, {0, 5}, {0, 4}};
static const uint32_t btnBits_ct = sizeof(btnBits) / sizeof(PORT_PIN_T);

static const uint8_t MACAddr[6] = {0x56, 0x34, 0x12, 0x37, 0x60, 0x00};

const LCD_CONFIG_T RK043_LCD = {
	8,						/*!< Horizontal back porch in clocks */
	5,						/*!< Horizontal front porch in clocks */
	2,						/*!< HSYNC pulse width in clocks */
	480,					/*!< Pixels per line */
	8,						/*!< Vertical back porch in clocks */
	8,						/*!< Vertical front porch in clocks */
	10,						/*!< VSYNC pulse width in clocks */
	272,					/*!< Lines per panel */
	0,						/*!< Invert output enable, 1 = invert */
	0,						/*!< Invert panel clock, 1 = invert */
	1,						/*!< Invert HSYNC, 1 = invert */
	1,						/*!< Invert VSYNC, 1 = invert */
	1,						/*!< AC bias frequency in clocks (not used) */
	6,						/*!< Maximum bits per pixel the display supports */
	LCD_TFT,				/*!< LCD panel type */
	LCD_COLOR_FORMAT_BGR,	/*!< BGR or RGB */
	0,						/*!< Dual panel, 1 = dual panel display */
};

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/* Clock rate on the CLKIN pin */
const uint32_t ExtClockIn = BOARD_EXTCLKINRATE;

/*****************************************************************************
 * Private functions
 ****************************************************************************/

#define ABS(x) ((int) (x) < 0 ? -(x) : (x))

/* Initialize the LEDs on the NXP LPC5460x NXP Eval Board */
static void Board_LED_Init(void)
{
	uint32_t i;

	/* Pin muxing setup as part of board_sysinit */
	for (i = 0; i < ledBits_ct; i++) {
		Chip_GPIO_SetPinDIROutput(LPC_GPIO, ledBits[i].port, ledBits[i].pin);
		Chip_GPIO_SetPinState(LPC_GPIO, ledBits[i].port, ledBits[i].pin, true);
	}
}

/* Initialize the buttons on the NXP LPC542xx LPCXpresso Board */
static void Board_Button_Init(void)
{
	uint32_t i;

	/* Pin muxing setup as part of board_sysinit */
	for (i = 0; i < btnBits_ct; i++) {
		Chip_GPIO_SetPinDIRInput(LPC_GPIO, btnBits[i].port, btnBits[i].pin);
	}
}

/* Board Debug UART Initialisation function */
static void Board_UART_Init(void)
{
	Chip_UART_Init(DEBUG_UART);
	Chip_UART_SetBaud(DEBUG_UART, DEBUGBAUDRATE);
	Chip_UART_ConfigData(DEBUG_UART, UART_CFG_DATALEN_8 | UART_CFG_PARITY_NONE | UART_CFG_STOPLEN_1);
	Chip_UART_Enable(DEBUG_UART);
	Chip_UART_TXEnable(DEBUG_UART);
}

static void board_sdio_pinmux(void)
{
	/* SDIO interface pins */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 3, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD_CLK */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 4, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD_CMD */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 5, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));    /* SD_PWR_EN */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 6, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT0 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 7, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT1 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 8, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT2 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 9, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN | IOCON_I2C_SLEW));    /* SD DAT3 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 10, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));   /* SD CARD DET */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 15, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));   /* SD WRITE PROT */
	/** FIXME: For some reason SDMMC does not work without these pins! */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 16, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT4 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 17, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT5 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 18, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT6 */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 19, (IOCON_FUNC2 | IOCON_MODE_INACT | IOCON_DIGITAL_EN | IOCON_HIGH_SPEED_EN));    /* SD DAT7 */
}

static void board_enet_pinmux(void)
{
	/* Ethernet interface pins */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 8, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 10, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 11, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 12, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 13, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 14, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 15, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 16, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 17, (IOCON_FUNC7 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 26, (IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_DIGITAL_EN));
}

static void board_lcd_pinmux(void)
{
	/* Red Data pins */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 21, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 22, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 23, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 24, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 25, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	/* Green Data Pins */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 28, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 29, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 30, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 31, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 0, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 1, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	/* Blue Data pins */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 5, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 6, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 7, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 8, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 3, 9, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	/* Control pins */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 11, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 13, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 14, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 15, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 16, (IOCON_FUNC1 | IOCON_MODE_INACT | IOCON_DIGITAL_EN));
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

void Board_ENET_GetMacADDR(uint8_t *macaddr)
{
	memcpy(macaddr, MACAddr, sizeof(MACAddr));
}

/* Read button state */
bool Board_Button_Get(uint8_t btnNum)
{
	bool ret_val = false;

	if (btnNum < btnBits_ct) {
		ret_val = Chip_GPIO_GetPinState(LPC_GPIO, btnBits[btnNum].port, btnBits[btnNum].pin) ? false : true;
	}

	return ret_val;
}

/* Set the LED to the state of "On" */
void Board_LED_Set(uint8_t LEDNumber, bool On)
{
	if (LEDNumber < ledBits_ct) {
		Chip_GPIO_SetPinState(LPC_GPIO, ledBits[LEDNumber].port, ledBits[LEDNumber].pin, (bool) !On);
	}
}

/* Return the state of LEDNumber */
bool Board_LED_Test(uint8_t LEDNumber)
{
	if (LEDNumber < ledBits_ct) {
		return (bool) !Chip_GPIO_GetPinState(LPC_GPIO, ledBits[LEDNumber].port, ledBits[LEDNumber].pin);
	}

	return false;
}

/* Toggles the current state of a board LED */
void Board_LED_Toggle(uint8_t LEDNumber)
{
	if (LEDNumber < ledBits_ct) {
		Chip_GPIO_SetPinToggle(LPC_GPIO, ledBits[LEDNumber].port, ledBits[LEDNumber].pin);
	}
}

/* Sends a character on the UART */
void Board_UARTPutChar(char ch)
{
#if defined(DEBUG_UART)
	Chip_UART_SendBlocking(DEBUG_UART, &ch, 1);
#endif
}

/* Gets a character from the UART, returns EOF if no character is ready */
int Board_UARTGetChar(void)
{
#if defined(DEBUG_UART)
	char uart_rx;
	if (Chip_UART_Read(DEBUG_UART, &uart_rx, 1) != 0) {
		return (int) uart_rx;
	}
#endif
	return EOF;
}

/* Outputs a string on the debug UART */
void Board_UARTPutSTR(char *str)
{
#if defined(DEBUG_UART)
	Chip_UART_SendBlocking(DEBUG_UART, str, strlen(str));
#endif
}

/* Initialize debug output via UART for board */
void Board_Debug_Init(void)
{
#if defined(DEBUG_UART)
	Board_UART_Init();
#endif
}

/* Initialize the LCD connected to this board */
void Board_LCD_Init(void)
{
	board_lcd_pinmux();
	Chip_Clock_SetLCDClockSource(SYSCON_LCDCLKSRC_MAINCLK, Chip_Clock_GetMainClockRate()/9000000);
}

void Board_SDIO_Init(void)
{
	board_sdio_pinmux();
}

void Board_Ethernet_Init(void)
{
	board_enet_pinmux();
}

#define I2C0_FLEXCOMM   2
#define TOUCH_CONTROLLER_I2C_ADDR 0x38
void Board_InitTouchController(void)
{
	I2CM_XFER_T xfer;
	uint32_t i;
	uint8_t buff[5];

	Chip_IOCON_PinMuxSet(LPC_IOCON, 2, 27, (IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_DIGITAL_EN));
	Chip_IOCON_PinMuxSet(LPC_IOCON, 4, 0, (IOCON_FUNC0 | IOCON_MODE_PULLUP | IOCON_DIGITAL_EN));

	Chip_GPIO_SetPinDIROutput(LPC_GPIO, 2, 27);
	Chip_GPIO_SetPinState(LPC_GPIO, 2, 27, false);
	/* Min 1ms delay for even the highest frequency */
	for(i = 0; i < 40000; i++);
	Chip_GPIO_SetPinState(LPC_GPIO, 2, 27, true);

	/*Set Interrupt Mode to polling */
	buff[0] = 0xA4;
	buff[1] = 0;

	xfer.slaveAddr= TOUCH_CONTROLLER_I2C_ADDR;
	xfer.rxBuff = 0;
	xfer.txBuff = buff;
	xfer.txSz = 2;
	xfer.rxSz = 0;

	do {
		Chip_I2CM_XferBlocking(LPC_I2C0, &xfer);
	} while(xfer.status != I2CM_STATUS_OK);

}

void Board_GetTouchPos(int16_t *x, int16_t *y)
{
	I2CM_XFER_T xfer;
	uint8_t tx_buff[5], rx_buff[15];
	uint8_t index, i;

	*x = *y = 0;
	if(!Chip_GPIO_GetPinState(LPC_GPIO, 4, 0)) {
		/*Read  */
		tx_buff[0] = 0x00;

		xfer.slaveAddr = TOUCH_CONTROLLER_I2C_ADDR;
		xfer.rxBuff = rx_buff;
		xfer.txBuff = tx_buff;
		xfer.txSz = 1;
		xfer.rxSz = 15;

		Chip_I2CM_XferBlocking(LPC_I2C0, &xfer);
		if(xfer.status == I2CM_STATUS_OK) {
			for ( i = 0; i < 2; i++) {
				index = 3 + i*6;
				if(((rx_buff[index] & 0xC0) != 0xC0) && ((rx_buff[index + 2] >> 4) != 0x0f)) {
					*x = ((rx_buff[index] & 0x0f) << 8) | rx_buff[index + 1];
					*y = ((rx_buff[index + 2] & 0x0f) << 8) | rx_buff[index + 3];
				}
			}


		}
	}
}

/* Set up and initialize all required blocks and functions related to the
   board hardware */
void Board_Init(void)
{
	/* INMUX and IOCON are used by many apps, enable both INMUX and IOCON clock bits here. */
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_INPUTMUX);
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_IOCON);

	/* Sets up DEBUG UART */
	DEBUGINIT();

	/* Initialize GPIO */
	Chip_GPIO_Init(LPC_GPIO);

	/* Initialize the LEDs. Be careful with below routine, once it's called some of the I/O will be set to output. */
	Board_LED_Init();

	/* Initialize the Buttons */
	Board_Button_Init();
}
