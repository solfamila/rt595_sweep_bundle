//*****************************************************************************
// LPC5410x eCRP header file
//
//*****************************************************************************
//
// Copyright 2014-2016, 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#define ECRP_SECT_ERASE_SHIFT	10
#define ECRP_ISP_PIN_SHIFT		12
#define ECRP_ISP_IAP_SHIFT		14
#define ECRP_JTAG_SHIFT			16
#define ECRP_MBOX_SHIFT			18

//------------------------------------------------------------------------------
//	eCRP bit definitions
//	This value is set in the "Symbols" settings in the project properties
//------------------------------------------------------------------------------
#define ECRP_SECT_ERASE_BITS 	(3 << ECRP_SECT_ERASE_SHIFT)
#define ECRP_ISP_PIN_BITS		(3 << ECRP_ISP_PIN_SHIFT)
#define ECRP_ISP_IAP_BITS		(3 << ECRP_ISP_IAP_SHIFT)
#define ECRP_JTAG_BITS			(3 << ECRP_JTAG_SHIFT)
#define ECRP_MBOX_BITS			(3 << ECRP_MBOX_SHIFT)

//------------------------------------------------------------------------------
//	Configure the image eCRP:
//	everything enabled / all sectors enabled: 0x000aa83f
//	everything enabled / one sector disabled: 0x000aa83e
//------------------------------------------------------------------------------
#ifndef ECRP_VAL
#define ECRP_VAL		0x000aa83f												// everything enabled
#endif
