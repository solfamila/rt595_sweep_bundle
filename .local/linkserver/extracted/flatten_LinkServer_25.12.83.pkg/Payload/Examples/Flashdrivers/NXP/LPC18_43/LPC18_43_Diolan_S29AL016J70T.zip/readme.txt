LPC18/43 S29AL016J70T Flash driver source project
=================================================

This project provides all files required to create a flash 
driver for the Spansion S29AL016J70T 2MB flash mounted on
 the Diolan LPC1850 / LPC4350 DB1 boards.  
   
Two project configurations are provided....

1) Debug
      - produces a test version of the flash driver that can 
        be run within the Code Red debug environment. This 
        configuration builds the flash driver wrapped by an 
        interface that mimics the interface used by the Code
        Red IDE when programming a project executable into 
        flash.
        
2) Release
      - produces LPC18_43_Diolan_S29AL016J70T.cfx - the actual
        flash driver file for use by the Code Red IDE to  
        program a project into the Spansion S29AL016J70T 2MB
        flash device.
               
The code is based on the  Flash driver sources provided in 
the LPC18/43 Peripheral Driver Libraries, the original sources 
for which are available from http://www.lpcware.com/        





        
        