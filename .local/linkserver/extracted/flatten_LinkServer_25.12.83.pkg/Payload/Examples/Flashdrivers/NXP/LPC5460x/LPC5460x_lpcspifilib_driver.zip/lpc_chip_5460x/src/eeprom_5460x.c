/*
 * @brief LPC5460x EEPROM driver
 *
 * @note
 * Copyright 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/* Setup EEPROM clock */
STATIC void setClkDiv(LPC_EEPROM_T *pEEPROM)
{
	uint32_t clk;

	/* Setup EEPROM timing to 1500KHz based on SYSCLK rate */
	clk = Chip_Clock_GetSystemClockRate();

	/* Set EEPROM clock divide value*/
	pEEPROM->CLKDIV = clk / EEPROM_CLOCK_DIV - 1;
}

/* Setup EEPROM clock */
STATIC INLINE void setWaitState(LPC_EEPROM_T *pEEPROM)
{
	/* Setup EEPROM wait states*/
	Chip_EEPROM_SetReadWaitState(pEEPROM, EEPROM_READ_WAIT_STATE_VAL);
	Chip_EEPROM_SetWaitState(pEEPROM, EEPROM_WAIT_STATE_VAL);

}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Initializes the EEPROM peripheral with specified parameter */
void Chip_EEPROM_Init(LPC_EEPROM_T *pEEPROM)
{
	LPC_SYSCON->PDRUNCFGCLR[0] = 3 << 11;
	LPC_SYSCON->PDRUNCFGCLR[1] = 1 << 5;
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_EEPROM);
	Chip_SYSCON_PeriphReset(RESET_EEPROM);
	/* Disable EEPROM power down mode */
	Chip_EEPROM_DisablePowerDown(pEEPROM);
	setClkDiv(pEEPROM);
	setWaitState(pEEPROM);
}

/* Write data from page register to non-volatile memory */
void Chip_EEPROM_EraseProgramPage(LPC_EEPROM_T *pEEPROM)
{
	Chip_EEPROM_ClearIntStatus(pEEPROM, EEPROM_CMD_ERASE_PRG_PAGE);
	Chip_EEPROM_SetCmd(pEEPROM, EEPROM_CMD_ERASE_PRG_PAGE);
	Chip_EEPROM_WaitForIntStatus(pEEPROM, EEPROM_INT_ENDOFPROG);
}

/* Wait for interrupt */
void Chip_EEPROM_WaitForIntStatus(LPC_EEPROM_T *pEEPROM, uint32_t mask)
{
	uint32_t status;
	while (1) {
		status = Chip_EEPROM_GetIntStatus(pEEPROM);
		if ((status & mask) == mask) {
			break;
		}
	}
	Chip_EEPROM_ClearIntStatus(pEEPROM, mask);
}

