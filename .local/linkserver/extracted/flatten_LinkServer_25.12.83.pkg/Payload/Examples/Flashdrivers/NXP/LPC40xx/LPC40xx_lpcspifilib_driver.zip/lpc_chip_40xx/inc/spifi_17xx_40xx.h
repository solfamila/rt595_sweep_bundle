/*
 * @brief LPC17xx/40xx SPIFI driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __SPIFI_17XX_40XX_H_
#define __SPIFI_17XX_40XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup SPIFI_17XX_40XX CHIP: LPC17xx/40xx SPIFI Driver
 * @ingroup CHIP_17XX_40XX_Drivers
 * @{
 */

#if defined(CHIP_LPC40XX)

/** SPIFI memory base address */
#define SPIFLASH_BASE_ADDRESS                 (0x28000000)
/** SPIFI API ROM address */
#define SPIFI_ROM_PTR                         (0x1FFF1954)

/**
 * @brief	Initialize the SPIFI
 * @return	None
 */
STATIC INLINE void Chip_SPIFI_Init(void)
{
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_SPIFI);
}

/**
 * @brief	Shutdown the SPIFI
 * @return	None
 */
STATIC INLINE void Chip_SPIFI_DeInit(void)
{
	Chip_Clock_DisablePeriphClock(SYSCTL_CLOCK_SPIFI);
}

#endif /* defined(CHIP_LPC40XX) */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __SPIFI_17XX_40XX_H_ */
