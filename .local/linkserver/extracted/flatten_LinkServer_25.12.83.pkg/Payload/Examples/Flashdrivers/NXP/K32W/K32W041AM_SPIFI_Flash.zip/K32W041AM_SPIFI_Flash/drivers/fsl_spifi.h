/*
 * Copyright (c) 2016, Freescale Semiconductor, Inc.
 * Copyright 2016-2020 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef _FSL_SPIFI_H_
#define _FSL_SPIFI_H_

#include "fsl_common.h"

/*!
 * @addtogroup spifi
 * @{
 */

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*! @name Driver version */
/*@{*/
/*! @brief SPIFI driver version 2.0.2. */
#define FSL_SPIFI_DRIVER_VERSION (MAKE_VERSION(2, 0, 2))
/*@}*/

/*! @brief Status structure of SPIFI.*/
enum _status_t
{
    kStatus_SPIFI_Idle  = MAKE_STATUS(kStatusGroup_SPIFI, 0), /*!< SPIFI is in idle state  */
    kStatus_SPIFI_Busy  = MAKE_STATUS(kStatusGroup_SPIFI, 1), /*!< SPIFI is busy */
    kStatus_SPIFI_Error = MAKE_STATUS(kStatusGroup_SPIFI, 2), /*!< Error occurred during SPIFI transfer */
};

/*! @brief SPIFI interrupt source */
typedef enum _spifi_interrupt_enable
{
    kSPIFI_CommandFinishInterruptEnable = SPIFI_CTRL_INTEN_MASK, /*!< Interrupt while command finished */
} spifi_interrupt_enable_t;

/*! @brief SPIFI SPI mode select */
typedef enum _spifi_spi_mode
{
    kSPIFI_SPISckLow  = 0x0U, /*!< SCK low after last bit of command, keeps low while CS high */
    kSPIFI_SPISckHigh = 0x1U  /*!< SCK high after last bit of command and while CS high */
} spifi_spi_mode_t;

/*! @brief SPIFI dual mode select */
typedef enum _spifi_dual_mode
{
    kSPIFI_QuadMode = 0x0U, /*!< SPIFI uses IO3:0 */
    kSPIFI_DualMode = 0x1U  /*!< SPIFI uses IO1:0 */
} spifi_dual_mode_t;

/*! @brief SPIFI data direction */
typedef enum _spifi_data_direction
{
    kSPIFI_DataInput  = 0x0U, /*!< Data input from serial flash. */
    kSPIFI_DataOutput = 0x1U  /*!< Data output to serial flash. */
} spifi_data_direction_t;

/*! @brief SPIFI command opcode format */
typedef enum _spifi_command_format
{
    kSPIFI_CommandAllSerial    = 0x0,  /*!< All fields of command are serial. */
    kSPIFI_CommandDataQuad     = 0x1U, /*!< Only data field is dual/quad, others are serial. */
    kSPIFI_CommandOpcodeSerial = 0x2U, /*!< Only opcode field is serial, others are quad/dual. */
    kSPIFI_CommandAllQuad      = 0x3U  /*!< All fields of command are dual/quad mode. */
} spifi_command_format_t;

/*! @brief SPIFI command type */
typedef enum _spifi_command_type
{
    kSPIFI_CommandOpcodeOnly             = 0x1U, /*!< Command only have opcode, no address field */
    kSPIFI_CommandOpcodeAddrOneByte      = 0x2U, /*!< Command have opcode and also one byte address field */
    kSPIFI_CommandOpcodeAddrTwoBytes     = 0x3U, /*!< Command have opcode and also two bytes address field */
    kSPIFI_CommandOpcodeAddrThreeBytes   = 0x4U, /*!< Command have opcode and also three bytes address field. */
    kSPIFI_CommandOpcodeAddrFourBytes    = 0x5U, /*!< Command have opcode and also four bytes address field */
    kSPIFI_CommandNoOpcodeAddrThreeBytes = 0x6U, /*!< Command have no opcode and three bytes address field */
    kSPIFI_CommandNoOpcodeAddrFourBytes  = 0x7U  /*!< Command have no opcode and four bytes address field */
} spifi_command_type_t;

/*! @brief SPIFI status flags */
enum _spifi_status_flags
{
    kSPIFI_MemoryCommandWriteFinished = SPIFI_STAT_MCINIT_MASK, /*!< Memory command write finished */
    kSPIFI_CommandWriteFinished       = SPIFI_STAT_CMD_MASK,    /*!< Command write finished */
    kSPIFI_InterruptRequest = SPIFI_STAT_INTRQ_MASK /*!< CMD flag from 1 to 0, means command execute finished */
};

/*! @brief SPIFI command structure */
typedef struct _spifi_command
{
    uint16_t dataLen;                 /*!< How many data bytes are needed in this command. */
    bool isPollMode;                  /*!< For command need to read data from serial flash */
    spifi_data_direction_t direction; /*!< Data direction of this command. */
    uint8_t intermediateBytes;        /*!< How many intermediate bytes needed */
    spifi_command_format_t format;    /*!< Command format */
    spifi_command_type_t type;        /*!< Command type */
    uint8_t opcode;                   /*!< Command opcode value */
} spifi_command_t;

/*!
 * @brief SPIFI region configuration structure.
 */
typedef struct _spifi_config
{
    uint16_t timeout;           /*!< SPI transfer timeout, the unit is SCK cycles */
    uint8_t csHighTime;         /*!< CS high time cycles */
    bool disablePrefetch;       /*!< True means SPIFI will not attempt a speculative prefetch. */
    bool disableCachePrefech;   /*!< Disable prefetch of cache line */
    bool isFeedbackClock;       /*!< Is data sample uses feedback clock. */
    spifi_spi_mode_t spiMode;   /*!< SPIFI spi mode select */
    bool isReadFullClockCycle;  /*!< If enable read full clock cycle. */
    spifi_dual_mode_t dualMode; /*!< SPIFI dual mode, dual or quad. */
} spifi_config_t;

/*! @brief Transfer structure for SPIFI */
typedef struct _spifi_transfer
{
    uint8_t *data;   /*!< Pointer to data to transmit */
    size_t dataSize; /*!< Bytes to be transmit */
} spifi_transfer_t;

/*******************************************************************************
 * API
 ******************************************************************************/

#if defined(__cplusplus)
extern "C" {
#endif /* _cplusplus */

/*!
 * @name Initialization and deinitialization
 * @{
 */

/*!
 * @brief Get the SPIFI instance from peripheral base address.
 *
 * @param base SPIFI peripheral base address.
 * @return SPIFI instance.
 */
uint32_t SPIFI_GetInstance(SPIFI_Type *base);

/*!
 * @brief Initializes the SPIFI with the user configuration structure.
 *
 * This function configures the SPIFI module with the user-defined configuration.
 *
 * @param base     SPIFI peripheral base address.
 * @param config   The pointer to the configuration structure.
 */
void SPIFI_Init(SPIFI_Type *base, const spifi_config_t *config);

/*!
 * @brief Get SPIFI default configure settings.
 *
 * @param config  SPIFI config structure pointer.
 */
void SPIFI_GetDefaultConfig(spifi_config_t *config);

/*!
 * @brief Deinitializes the SPIFI regions.
 *
 * @param base     SPIFI peripheral base address.
 */
void SPIFI_Deinit(SPIFI_Type *base);

/* @}*/

/*!
 * @name Basic Control Operations
 * @{
 */

/*!
 * @brief Set SPIFI flash command.
 *
 * @param base     SPIFI peripheral base address.
 * @param cmd      SPIFI command structure pointer.
 */
void SPIFI_SetCommand(SPIFI_Type *base, const spifi_command_t *cmd);

/*!
 * @brief Set SPIFI command address.
 *
 * @param base     SPIFI peripheral base address.
 * @param addr     Address value for the command.
 */
static inline void SPIFI_SetCommandAddress(SPIFI_Type *base, uint32_t addr)
{
    base->ADDR = addr;
}

/*!
 * @brief Set SPIFI intermediate data.
 *
 * Before writing a command wihch needs specific intermediate value, users shall call this function to write it.
 * The main use of this function for current serial flash is to select no-opcode mode and cancelling this mode. As
 * dummy cycle do not care about the value, no need to call this function.
 *
 * @param base     SPIFI peripheral base address.
 * @param val      Intermediate data.
 */
static inline void SPIFI_SetIntermediateData(SPIFI_Type *base, uint32_t val)
{
    base->IDATA = val;
}

/*!
 * @brief Set SPIFI Cache limit value.
 *
 * SPIFI includes caching of prevously-accessed data to improve performance. Software can write an address to this
 * function, to prevent such caching at and above the address.
 *
 * @param base     SPIFI peripheral base address.
 * @param val     Zero-based upper limit of cacheable memory.
 */
static inline void SPIFI_SetCacheLimit(SPIFI_Type *base, uint32_t val)
{
    base->CLIMIT = val;
}

/*!
 * @brief Reset the command field of SPIFI.
 *
 * This function is used to abort the current command or memory mode.
 *
 * @param base     SPIFI peripheral base address.
 */
static inline void SPIFI_ResetCommand(SPIFI_Type *base)
{
    base->STAT = SPIFI_STAT_RESET_MASK;
    /* Wait for the RESET flag cleared by HW */
    while (base->STAT & SPIFI_STAT_RESET_MASK)
    {
    }
}

/*!
 * @brief Set SPIFI flash AHB read command.
 *
 * Call this function means SPIFI enters to memory mode, while users need to use command, a SPIFI_ResetCommand shall
 * be called.
 *
 * @param base     SPIFI peripheral base address.
 * @param cmd      SPIFI command structure pointer.
 */
void SPIFI_SetMemoryCommand(SPIFI_Type *base, const spifi_command_t *cmd);

/*!
 * @brief Enable SPIFI interrupt.
 *
 * The interrupt is triggered only in command mode, and it means the command now is finished.
 *
 * @param base     SPIFI peripheral base address.
 * @param mask     SPIFI interrupt enable mask. It is a logic OR of members the
 *                 enumeration :: spifi_interrupt_enable_t
 */
static inline void SPIFI_EnableInterrupt(SPIFI_Type *base, uint32_t mask)
{
    base->CTRL |= mask;
}

/*!
 * @brief Disable SPIFI interrupt.
 *
 * The interrupt is triggered only in command mode, and it means the command now is finished.
 *
 * @param base     SPIFI peripheral base address.
 * @param mask     SPIFI interrupt enable mask. It is a logic OR of members the
 *                 enumeration :: spifi_interrupt_enable_t
 */
static inline void SPIFI_DisableInterrupt(SPIFI_Type *base, uint32_t mask)
{
    base->CTRL &= ~mask;
}

/*!
 * @name Status
 * @{
 */

/*!
 * @brief Get the status of all interrupt flags for SPIFI.
 *
 * @param base     SPIFI peripheral base address.
 * @return SPIFI flag status
 */
static inline uint32_t SPIFI_GetStatusFlag(SPIFI_Type *base)
{
    return base->STAT;
}

/* @}*/

/*!
 * @brief Enable or disable DMA request for SPIFI.
 *
 * @param base     SPIFI peripheral base address.
 * @param enable   True means enable DMA and false means disable DMA.
 */
static inline void SPIFI_EnableDMA(SPIFI_Type *base, bool enable)
{
    if (enable)
    {
        base->CTRL |= SPIFI_CTRL_DMAEN_MASK;
    }
    else
    {
        base->CTRL &= ~SPIFI_CTRL_DMAEN_MASK;
    }
}

/*!
 * @brief  Gets the SPIFI data register address.
 *
 * This API is used to provide a transfer address for the SPIFI DMA transfer configuration.
 *
 * @param base SPIFI base pointer
 * @return data register address
 */
static inline uint32_t SPIFI_GetDataRegisterAddress(SPIFI_Type *base)
{
    return (uint32_t)(&(base->DATA));
}

/*!
 * @brief Write a word data in address of SPIFI.
 *
 * Users can write a page or at least a word data into SPIFI address.
 * Beware: certain SPIFI implementations (such as that of JN5189/QN9090/K32W061)
 * require that the data do not exceed the actual size of the command, so cannot call
 * SPIFI_WriteData when less than 32 bits are expected.
 *
 * @param base     SPIFI peripheral base address.
 * @param data     Data that need to be written.
 */
static inline void SPIFI_WriteData(SPIFI_Type *base, uint32_t data)
{
    base->DATA = data;
}

#ifdef CPU_JN518X
/*!
 * @brief Write a byte data in address of SPIFI.
 *
 * Used for transaction requiring less than 32 bits of data
 *
 * @param base     SPIFI peripheral base address.
 * @param data     8 bit word that need to be written.
 */
static inline void SPIFI_Write8bitWord(SPIFI_Type *base, uint8_t byte)
{
    __IO uint8_t *reg8 = (__IO uint8_t *) &base->DATA;
    *reg8 = byte;
}

/*!
 * @brief Write a short data in address of SPIFI.
 *
 * Used for transaction requiring less than 32 bits of data
 *
 * @param base     SPIFI peripheral base address.
 * @param word     16 bit word  that needs to be written.
 */
static inline void SPIFI_Write16bitWord(SPIFI_Type *base, uint16_t word)
{
    __IO uint16_t *reg16 = (__IO uint16_t *) &base->DATA;
    *reg16 = (uint16_t)word;
}

void SPIFI_WritePartialWord(SPIFI_Type *base, uint32_t data, uint8_t partial_write_width);
#endif

/*!
 * @brief Write a buffer worth of data to SPIFI .
 *
 * Used for transaction requiring less than 32 bits of data
 *
 * @param base    SPIFI peripheral base address.
 * @param buf     pointer on octet buffer to be written to the SPIFI.
 * @param size_to_write     size of buffer.
 */
void SPIFI_WriteBuffer(SPIFI_Type *base, uint8_t *buf, size_t size_to_write);

/*!
 * @brief Write a byte data in address of SPIFI.
 *
 * Users can write a byte data into SPIFI address.
 *
 * @param base     SPIFI peripheral base address.
 * @param data     Data need be write.
 */
static inline void SPIFI_WriteDataByte(SPIFI_Type *base, uint8_t data)
{
    *((volatile uint8_t *)(&(base->DATA))) = data;
}

/*!
 * @brief Write a halfword data in address of SPIFI.
 *
 * Users can write a halfword data into SPIFI address.
 *
 * @param base     SPIFI peripheral base address.
 * @param data     Data need be write.
 */
void SPIFI_WriteDataHalfword(SPIFI_Type *base, uint16_t data);

/*!
 * @brief Read data from serial flash.
 *
 * Users should notice before call this function, the data length field in command register shall be larger
 * than 4, otherwise a hard fault will happen.
 *
 * @param base     SPIFI peripheral base address.
 * @return Data input from flash.
 */
static inline uint32_t SPIFI_ReadData(SPIFI_Type *base)
{
    return base->DATA;
}

#ifdef CPU_JN518X
/*!
 * @brief Read an 8 bit word from  SPIFI.
 *
 * Used for transaction requiring less than 32 bits of data
 *
 * @param base     SPIFI peripheral base address.
 */
static inline uint8_t SPIFI_Read8bitWord(SPIFI_Type *base)
{
    __IO uint8_t *reg8 = (__IO uint8_t *) &base->DATA;
    return *reg8;;
}

/*!
 * @brief Read between 16 bit word  from SPIFI.
 *
 * Used for transaction requiring less than 32 bits of data
 *
 * @param base     SPIFI peripheral base address.
 */
static inline uint16_t SPIFI_Read16bitWord(SPIFI_Type *base)
{
    __IO uint16_t *reg16 = (__IO uint16_t *) &base->DATA;
    return *reg16;
}

uint32_t SPIFI_ReadPartialWord(SPIFI_Type *base,  uint8_t partial_read_width);
#endif

/*!
 * @brief Read a byte data from serial flash.
 *
 * @param base     SPIFI peripheral base address.
 * @return Data input from flash.
 */
static inline uint8_t SPIFI_ReadDataByte(SPIFI_Type *base)
{
    return *((volatile uint8_t *)(&(base->DATA)));
}

/*!
 * @brief Read a halfword data from serial flash.
 *
 * @param base     SPIFI peripheral base address.
 * @return Data input from flash.
 */
uint16_t SPIFI_ReadDataHalfword(SPIFI_Type *base);

/* @} */

#if defined(__cplusplus)
}
#endif

/*! @}*/

#endif /* _FSL_SPIFI_H_ */
