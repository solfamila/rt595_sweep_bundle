/*
 * @brief LPC5460X FLEXCOMM specific functions
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

 /* Get the index corresponding to the flexcomm */
int Chip_FLEXCOMM_GetIndex(LPC_FLEXCOMM_T *pFCOMM)
{
	 switch ((uint32_t) pFCOMM) {
		case LPC_FLEXCOMM0_BASE:
			 return 0;
		case LPC_FLEXCOMM1_BASE:
			 return 1;
		case LPC_FLEXCOMM2_BASE:
			 return 2;
		case LPC_FLEXCOMM3_BASE:
			 return 3;
		case LPC_FLEXCOMM4_BASE:
			 return 4;
		case LPC_FLEXCOMM5_BASE:
			 return 5;
		case LPC_FLEXCOMM6_BASE:
			 return 6;
		case LPC_FLEXCOMM7_BASE:
			return 7;
		case LPC_FLEXCOMM8_BASE:
			return 8;
		case LPC_FLEXCOMM9_BASE:
			return 9;
		default:
			return ERR_FLEXCOMM_INVALIDBASE;
	}
}

/* Return the clock index of the given flexcomm */
CHIP_SYSCON_CLOCK_T Chip_FLEXCOMM_GetClockIndex(int flex_index)
{
	if (flex_index <= 7)
		return (CHIP_SYSCON_CLOCK_T) (SYSCON_CLOCK_FLEXCOMM0 + flex_index);
	flex_index -= 8;
	return (CHIP_SYSCON_CLOCK_T) (SYSCON_CLOCK_FLEXCOMM8 + flex_index);
}

/* Return the clock index of the given flexcomm */
CHIP_SYSCON_PERIPH_RESET_T Chip_FLEXCOMM_GetResetIndex(int flex_index)
{
	if (flex_index <= 7)
		return (CHIP_SYSCON_PERIPH_RESET_T) (RESET_FLEXCOMM0 + flex_index);
	flex_index -= 8;
	return (CHIP_SYSCON_PERIPH_RESET_T) (RESET_FLEXCOMM8 + flex_index);
}

/* Initialize FlexCOMM to a given peripheral */
int Chip_FLEXCOMM_Init(LPC_FLEXCOMM_T *pFCOMM, FLEXCOMM_PERIPH_T periph)
{
	int ret;
	int idx = Chip_FLEXCOMM_GetIndex(pFCOMM);

	if (idx < 0)
		return idx;

	/* Enable the peripheral clock */
	Chip_Clock_EnablePeriphClock(Chip_FLEXCOMM_GetClockIndex(idx));

	/* Reset FlexCOMM */
	Chip_SYSCON_PeriphReset(Chip_FLEXCOMM_GetResetIndex(idx));

	/* Set the FLEXCOMM to given peripheral */
	ret = Chip_FLEXCOMM_SetPeriph(pFCOMM, periph, 0);
	if (ret) {
		return ret;
	}

#warning "Fixme: wakeup numbers not updated yet."
	/* By default enable wakeup from this peripheral */
	Chip_SYSCON_EnableWakeup((CHIP_SYSCON_WAKEUP_T) (SYSCON_STARTER_FLEXCOMM0 + idx));

	/* Set a default source for this flexcomm */
	Chip_Clock_SetFLEXCOMMClockSource(idx, SYSCON_FLEXCOMMCLKSELSRC_FRO12MHZ);

	return 0;
}

/* Initialize FlexCOMM to a given peripheral */
void Chip_FLEXCOMM_DeInit(LPC_FLEXCOMM_T *pFCOMM)
{
	int idx = Chip_FLEXCOMM_GetIndex(pFCOMM);
	if (idx < 0)
		return ;


	/* Disable source clock to this flexcomm */
	Chip_Clock_SetFLEXCOMMClockSource(idx, SYSCON_FLEXCOMMCLKSELSRC_NONE);

	/* Disable wakeup from this FlexCOMM */
	Chip_SYSCON_DisableWakeup((CHIP_SYSCON_WAKEUP_T) (SYSCON_STARTER_FLEXCOMM0 + idx));

	if (Chip_FLEXCOMM_IsLocked(pFCOMM)) {
		/* Reset FlexCOMM */
		Chip_SYSCON_PeriphReset((CHIP_SYSCON_PERIPH_RESET_T) (RESET_FLEXCOMM0 + idx));
	}
	Chip_FLEXCOMM_SetPeriph(pFCOMM, FLEXCOMM_PERIPH_NONE, 0);
	Chip_Clock_DisablePeriphClock((CHIP_SYSCON_CLOCK_T) (SYSCON_CLOCK_FLEXCOMM0 + idx));
}

/* Set a given flexcomm to a function */
int Chip_FLEXCOMM_SetPeriph(LPC_FLEXCOMM_T *pFCOMM, FLEXCOMM_PERIPH_T periph, int lock)
{
	volatile uint32_t *psel = &((volatile uint32_t *)pFCOMM)[FLEXCOMM_PSEL_OFFSET / 4];
	int fnum = (int) periph - 1;

	if (periph) {
		if (fnum == 4)
			fnum --;
		if (!(*psel & (0x10 << fnum)))
			return ERR_FLEXCOMM_FUNCNOTSUPPORTED;
	}

	/* Check if the flexcomm is already locked */
	if ((*psel & FLEXCOMM_LOCK) || (*psel & 7))
		return ERR_FLEXCOMM_NOTFREE;

	/* Check if we are asked to lock */
	if (lock)
		*psel = (uint32_t) periph | FLEXCOMM_LOCK;
	else
		*psel = (uint32_t) periph;

	return 0;
}

