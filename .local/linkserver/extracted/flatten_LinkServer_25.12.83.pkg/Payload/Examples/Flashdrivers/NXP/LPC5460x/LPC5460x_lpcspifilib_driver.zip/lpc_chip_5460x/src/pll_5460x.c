/*
 * @brief LPC5460X PLL driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

#define NVALMAX                     (0x100)
#define PVALMAX                     (0x20)
#define MVALMAX                     (0x8000)

/* SYS PLL related bit fields */
#define SYS_PLL_SELR(d)             (((d) & 0xf) << 0)		/*!< Bandwidth select R value */
#define SYS_PLL_SELI(d)             (((d) & 0x3f) << 4)		/*!< Bandwidth select I value */
#define SYS_PLL_SELP(d)             (((d) & 0x1f) << 10)	/*!< Bandwidth select P value */

// #define FRAC_BITS_SELI			(8)		// For retaining fractions in divisions
#define PLL_MDEC_VAL_P          (0)			// MDEC is in bits  16 downto 0
#define PLL_MDEC_VAL_M          (0x1FFFFUL << PLL_MDEC_VAL_P)		// NDEC is in bits  9 downto 0
#define PLL_NDEC_VAL_P          (0)			// NDEC is in bits  9:0
#define PLL_NDEC_VAL_M          (0x3FFUL << PLL_NDEC_VAL_P)
#define PLL_PDEC_VAL_P          (0)			// PDEC is in bits 6:0
#define PLL_PDEC_VAL_M          (0x3FFUL << PLL_PDEC_VAL_P)

#define PLL_MIN_CCO_FREQ_MHZ    (275000000)
#define PLL_MAX_CCO_FREQ_MHZ    (550000000)
#define PLL_LOWER_IN_LIMIT      (4000)				/*!< Minimum PLL input rate */
#define PLL_MIN_IN_SSMODE       (2000000)
#define PLL_MAX_IN_SSMODE       (4000000)

// pll SYSPLLCTRL Bits
#define SYSCON_SYSPLLCTRL_SELR_P              0
#define SYSCON_SYSPLLCTRL_SELR_M              (0xFUL << SYSCON_SYSPLLCTRL_SELR_P)
#define SYSCON_SYSPLLCTRL_SELI_P              4
#define SYSCON_SYSPLLCTRL_SELI_M              (0x3FUL << SYSCON_SYSPLLCTRL_SELI_P)
#define SYSCON_SYSPLLCTRL_SELP_P              10
#define SYSCON_SYSPLLCTRL_SELP_M              (0x1FUL << SYSCON_SYSPLLCTRL_SELP_P)

#define SYSCON_SYSPLLCTRL_BYPASS_P            15		// sys_pll150_ctrl
#define SYSCON_SYSPLLCTRL_BYPASS              (1UL << SYSCON_SYSPLLCTRL_BYPASS_P)
#define SYSCON_SYSPLLCTRL_UPLIMOFF_P          17
#define SYSCON_SYSPLLCTRL_UPLIMOFF            (1UL << SYSCON_SYSPLLCTRL_UPLIMOFF_P)
#define SYSCON_SYSPLLCTRL_DIRECTI_P           19
#define SYSCON_SYSPLLCTRL_DIRECTI             (1UL << SYSCON_SYSPLLCTRL_DIRECTI_P)
#define SYSCON_SYSPLLCTRL_DIRECTO_P           20
#define SYSCON_SYSPLLCTRL_DIRECTO             (1UL << SYSCON_SYSPLLCTRL_DIRECTO_P)

#define SYSCON_SYSPLLSTAT_LOCK_P              0
#define SYSCON_SYSPLLSTAT_LOCK                (1UL << SYSCON_SYSPLLSTAT_LOCK_P)

// PLL NDEC reg
#define PLL_NDEC_VAL_SET(value)               (((unsigned long) (value) << PLL_NDEC_VAL_P) & PLL_NDEC_VAL_M)
#define PLL_NDEC_NREQ_P                       10
#define PLL_NDEC_NREQ                         (1 << PLL_NDEC_NREQ_P)

// PLL PDEC reg
#define PLL_PDEC_VAL_SET(value)               (((unsigned long) (value) << PLL_PDEC_VAL_P) & PLL_PDEC_VAL_M)
#define PLL_PDEC_PREQ_P                       7
#define PLL_PDEC_PREQ                         (1 << PLL_PDEC_PREQ_P)

// MDEC
#define PLL_MDEC_VAL_SET(value)               (((unsigned long) (value) << PLL_MDEC_VAL_P) & PLL_MDEC_VAL_M)
#define PLL_MDEC_MREQ_P                       17
#define PLL_MDEC_MREQ                         (1 << PLL_MDEC_MREQ_P)

/* Saved value of PLL output rate, computed whenever needed to save run-time
   computation on each call to retrive the PLL rate. */
static uint32_t curPllRate;

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/* Find encoded NDEC value for raw N value, max N = NVALMAX */
static uint32_t pllEncodeN(uint32_t N)
{
	uint32_t x, i;

	/* Find NDec */
	switch (N) {
	case 0:
		x = 0xFFF;
		break;

	case 1:
		x = 0x302;
		break;

	case 2:
		x = 0x202;
		break;

	default:
		x = 0x080;
		for (i = N; i <= NVALMAX; i++) {
			x = (((x ^ (x >> 2) ^ (x >> 3) ^ (x >> 4)) & 1) << 7) | ((x >> 1) & 0x7F);
		}
		break;
	}

	return x & (PLL_NDEC_VAL_M >> PLL_NDEC_VAL_P);
}

/* Find decoded N value for raw NDEC value */
static uint32_t pllDecodeN(uint32_t NDEC)
{
	uint32_t n, x, i;

	/* Find NDec */
	switch (NDEC) {
	case 0xFFF:
		n = 0;
		break;

	case 0x302:
		n = 1;
		break;

	case 0x202:
		n = 2;
		break;

	default:
		x = 0x080;
		n = 0xFFFFFFFF;
		for (i = NVALMAX; ((i >= 3) && (n == 0xFFFFFFFF)); i--) {
			x = (((x ^ (x >> 2) ^ (x >> 3) ^ (x >> 4)) & 1) << 7) | ((x >> 1) & 0x7F);
			if ((x & (PLL_NDEC_VAL_M >> PLL_NDEC_VAL_P)) == NDEC) {
				/* Decoded value of NDEC */
				n = i;
			}
		}
		break;
	}

	return n;
}

/* Find encoded PDEC value for raw P value, max P = PVALMAX */
static uint32_t pllEncodeP(uint32_t P)
{
	uint32_t x, i;

	/* Find PDec */
	switch (P) {
	case 0:
		x = 0xFF;
		break;

	case 1:
		x = 0x62;
		break;

	case 2:
		x = 0x42;
		break;

	default:
		x = 0x10;
		for (i = P; i <= PVALMAX; i++) {
			x = (((x ^ (x >> 2)) & 1) << 4) | ((x >> 1) & 0xF);
		}
		break;
	}

	return x & (PLL_PDEC_VAL_M >> PLL_PDEC_VAL_P);
}

/* Find decoded P value for raw PDEC value */
static uint32_t pllDecodeP(uint32_t PDEC)
{
	uint32_t p, x, i;

	/* Find PDec */
	switch (PDEC) {
	case 0xFF:
		p = 0;
		break;

	case 0x62:
		p = 1;
		break;

	case 0x42:
		p = 2;
		break;

	default:
		x = 0x10;
		p = 0xFFFFFFFF;
		for (i = PVALMAX; ((i >= 3) && (p == 0xFFFFFFFF)); i--) {
			x = (((x ^ (x >> 2)) & 1) << 4) | ((x >> 1) & 0xF);
			if ((x & (PLL_PDEC_VAL_M >> PLL_PDEC_VAL_P)) == PDEC) {
				/* Decoded value of PDEC */
				p = i;
			}
		}
		break;
	}

	return p;
}

/* Find encoded MDEC value for raw M value, max M = MVALMAX */
static uint32_t pllEncodeM(uint32_t M)
{
	uint32_t i, x;

	/* Find MDec */
	switch (M) {
	case 0:
		x = 0xFFFFF;
		break;

	case 1:
		x = 0x18003;
		break;

	case 2:
		x = 0x10003;
		break;

	default:
		x = 0x04000;
		for (i = M; i <= MVALMAX; i++) {
			x = (((x ^ (x >> 1)) & 1) << 14) | ((x >> 1) & 0x3FFF);
		}
		break;
	}

	return x & (PLL_MDEC_VAL_M >> PLL_MDEC_VAL_P);
}

/* Find decoded M value for raw MDEC value */
static uint32_t pllDecodeM(uint32_t MDEC)
{
	uint32_t m, i, x;

	/* Find MDec */
	switch (MDEC) {
	case 0xFFFFF:
		m = 0;
		break;

	case 0x18003:
		m = 1;
		break;

	case 0x10003:
		m = 2;
		break;

	default:
		x = 0x04000;
		m = 0xFFFFFFFF;
		for (i = MVALMAX; ((i >= 3) && (m == 0xFFFFFFFF)); i--) {
			x = (((x ^ (x >> 1)) & 1) << 14) | ((x >> 1) & 0x3FFF);
			if ((x & (PLL_MDEC_VAL_M >> PLL_MDEC_VAL_P)) == MDEC) {
				/* Decoded value of MDEC */
				m = i;
			}
		}
		break;
	}

	return m;
}

/* Find SELP, SELI, and SELR values for raw M value, max M = MVALMAX */
static void pllFindSel(uint32_t M, uint32_t *pSelP, uint32_t *pSelI, uint32_t *pSelR)
{
	/* bandwidth: compute selP from Multiplier */
	if (M < 60) {
		*pSelP = (M >> 1) + 1;
	}
	else {
		*pSelP = PVALMAX - 1;
	}

	/* bandwidth: compute selI from Multiplier */
	if (M > 16384) {
		*pSelI = 1;
	}
	else if (M > 8192) {
		*pSelI = 2;
	}
	else if (M > 2048) {
		*pSelI = 4;
	}
	else if (M >= 501) {
		*pSelI = 8;
	}
	else if (M >= 60) {
		*pSelI = 4 * (1024 / (M + 9));
	}
	else {
		*pSelI = (M & 0x3C) + 4;
	}

	if (*pSelI > (SYSCON_SYSPLLCTRL_SELI_M >> SYSCON_SYSPLLCTRL_SELI_P)) {
		*pSelI = (SYSCON_SYSPLLCTRL_SELI_M >> SYSCON_SYSPLLCTRL_SELI_P);
	}

	*pSelR = 0;
}

/* Get predivider (N) from PLL NDEC setting */
uint32_t findPllPreDiv(uint32_t ctrlReg, uint32_t nDecReg)
{
	uint32_t preDiv = 1;

	/* Direct input is not used? */
	if ((ctrlReg & SYSCON_SYSPLLCTRL_DIRECTI) == 0) {
		/* Decode NDEC value to get (N) pre divider */
		preDiv = pllDecodeN(nDecReg & 0x3FF);
		if (preDiv == 0) {
			preDiv = 1;
		}
	}

	/* Adjusted by 1, directi is used to bypass */
	return preDiv;
}

/* Get postdivider (P) from PLL PDEC setting */
uint32_t findPllPostDiv(uint32_t ctrlReg, uint32_t pDecReg)
{
	uint32_t postDiv = 1;

	/* Direct input is not used? */
	if ((ctrlReg & SYSCON_SYSPLLCTRL_DIRECTO) == 0) {
		/* Decode PDEC value to get (P) post divider */
		postDiv = 2 * pllDecodeP(pDecReg & 0x7F);
		if (postDiv == 0) {
			postDiv = 2;
		}
	}

	/* Adjusted by 1, directo is used to bypass */
	return postDiv;
}

/* Get multiplier (M) from PLL MDEC and BYPASS_FBDIV2 settings */
uint32_t findPllMMult(uint32_t ctrlReg, uint32_t mDecReg)
{
	uint32_t mMult = 1;

	/* Decode MDEC value to get (M) multiplier */
	mMult = pllDecodeM(mDecReg & 0x1FFFF);

	/* hardcorded inside H/W, divided by 2 is always needed on LPC5460x. */
	mMult = mMult << 1;

	if (mMult == 0) {
		mMult = 1;
	}

	return mMult;
}

static uint32_t FindGreatestCommonDivisor(uint32_t m, uint32_t n)
{
	uint32_t tmp;

	while (n != 0) {
		tmp = n;
		n = m % n;
		m = tmp;
	}

	return m;
}

/* Set PLL output based on desired output rate */
static PLL_ERROR_T Chip_Clock_GetPllConfig(uint32_t finHz, uint32_t foutHz, PLL_SETUP_T *pSetup )
{
	uint32_t nDivOutHz, fccoHz, multFccoDiv;
	uint32_t pllPreDivider, pllMultiplier, pllPostDivider;
	uint32_t pllDirectInput, pllDirectOutput;
	uint32_t pllSelP, pllSelI, pllSelR, uplimoff;

	/* Baseline parameters (no input or output dividers) */
	pllPreDivider = 1;	/* 1 implies pre-divider will be enabled */
	pllPostDivider = 1;	/* 0 implies post-divider will be disabled */
	pllDirectOutput = 1;
	multFccoDiv = 2;

	/* Verify output rate parameter */
	if (foutHz > PLL_MAX_CCO_FREQ_MHZ) {
		/* Maximum PLL output with post divider=1 cannot go above this frequency */
		return PLL_ERROR_OUTPUT_TOO_HIGH;
	}
	if (foutHz < (PLL_MIN_CCO_FREQ_MHZ / (PVALMAX << 1))) {
		/* Minmum PLL output with maximum post divider cannot go below this frequency */
		return PLL_ERROR_OUTPUT_TOO_LOW;
	}

	/* Verify input rate parameter */
	if (finHz < PLL_LOWER_IN_LIMIT) {
		/* Input clock into the PLL cannot be lower than this */
		return PLL_ERROR_INPUT_TOO_LOW;
	}

	/* Find the optimal CCO frequency for the output and input that
	   will keep it inside the PLL CCO range. This may require
	   tweaking the post-divider for the PLL. */
	fccoHz = foutHz;
	while (fccoHz < PLL_MIN_CCO_FREQ_MHZ) {
		/* CCO output is less than minimum CCO range, so the CCO output
		   needs to be bumped up and the post-divider is used to bring
		   the PLL output back down. */
		pllPostDivider++;
		if (pllPostDivider > PVALMAX) {
			return PLL_ERROR_OUTSIDE_INTLIMIT;
		}

		/* Target CCO goes up, PLL output goes down */
		fccoHz = foutHz * (pllPostDivider * 2);
		pllDirectOutput = 0;
	}

	/* Determine if a pre-divider is needed to get the best frequency */
	if ((finHz > PLL_LOWER_IN_LIMIT) && (fccoHz >= finHz)) {
		uint32_t a = FindGreatestCommonDivisor(fccoHz, (multFccoDiv * finHz));

		if (a > 20000) {
			a = (multFccoDiv * finHz) / a;
			if ((a != 0) && (a < NVALMAX)) {
				pllPreDivider = a;
			}
		}
	}

	/* Bypass pre-divider hardware if pre-divider is 1 */
	if (pllPreDivider > 1) {
		pllDirectInput = 0;
	}
	else {
		pllDirectInput = 1;
	}

	/* Determine PLL multipler */
	nDivOutHz = (finHz / pllPreDivider);
	pllMultiplier = (fccoHz / nDivOutHz) / multFccoDiv;

	/* Will bumping up M by 1 get us closer to the desired CCO frequency? */
	if ((nDivOutHz * ((multFccoDiv * pllMultiplier * 2) + 1)) < (fccoHz * 2)) {
		pllMultiplier++;
	}

	/* Setup filtering */
	pllFindSel(pllMultiplier, &pllSelP, &pllSelI, &pllSelR);
	uplimoff = 0;

	/* Get encoded value for M (mult) and use manual filter, disable SS mode */
	pSetup->SYSPLLMDEC = PLL_MDEC_VAL_SET(pllEncodeM(pllMultiplier));

	/* Get encoded values for N (prediv) and P (postdiv) */
	pSetup->SYSPLLNDEC = PLL_NDEC_VAL_SET(pllEncodeN(pllPreDivider));
	pSetup->SYSPLLPDEC = PLL_PDEC_VAL_SET(pllEncodeP(pllPostDivider));

	/* PLL control */
	pSetup->SYSPLLCTRL =
		(pllSelR << SYSCON_SYSPLLCTRL_SELR_P) |					/* Filter coefficient */
		(pllSelI << SYSCON_SYSPLLCTRL_SELI_P) |					/* Filter coefficient */
		(pllSelP << SYSCON_SYSPLLCTRL_SELP_P) |					/* Filter coefficient */
		(0 << SYSCON_SYSPLLCTRL_BYPASS_P) |						/* PLL bypass mode disabled */
		(uplimoff << SYSCON_SYSPLLCTRL_UPLIMOFF_P) |			/* SS/fractional mode disabled */
		(pllDirectInput << SYSCON_SYSPLLCTRL_DIRECTI_P) |		/* Bypass pre-divider? */
		(pllDirectOutput << SYSCON_SYSPLLCTRL_DIRECTO_P);		/* Bypass post-divider? */

	return PLL_ERROR_SUCCESS;
}

/* Update local PLL rate variable */
static void Chip_Clock_GetSystemPLLOutFromSetupUpdate(PLL_SETUP_T *pSetup)
{
	curPllRate = Chip_Clock_GetSystemPLLOutFromSetup(pSetup);
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Return System PLL input clock rate */
uint32_t Chip_Clock_GetSystemPLLInClockRate(void)
{
	uint32_t clkRate = 0;

	switch ((CHIP_SYSCON_PLLCLKSRC_T) (LPC_SYSCON->SYSPLLCLKSEL & 0x3)) {
	case SYSCON_PLLCLKSRC_FRO12MHZ:
		clkRate = SYSCON_FRO12MHZ_FREQ;
		break;

	case SYSCON_PLLCLKSRC_CLKIN:
		clkRate = Chip_Clock_GetExtClockInRate();
		break;

	case SYSCON_PLLCLKSRC_RTC:
		clkRate = Chip_Clock_GetRTCOscRate();
		break;

	default:
		clkRate = 0;
		break;
	}

	return clkRate;
}

/* Return System PLL output clock rate from setup structure */
uint32_t Chip_Clock_GetSystemPLLOutFromSetup(PLL_SETUP_T *pSetup)
{
	uint32_t prediv, postdiv, mMult, inPllRate;
	uint64_t workRate;

	inPllRate = Chip_Clock_GetSystemPLLInClockRate();
	if ((pSetup->SYSPLLCTRL & SYSCON_SYSPLLCTRL_BYPASS) == 0) {
		/* PLL is not in bypass mode, get pre-divider, post-divider, and M divider */
		prediv = findPllPreDiv(pSetup->SYSPLLCTRL, pSetup->SYSPLLNDEC);
		postdiv = findPllPostDiv(pSetup->SYSPLLCTRL, pSetup->SYSPLLPDEC);

		/* Adjust input clock */
		inPllRate = inPllRate / prediv;

		/* MDEC used for rate */
		mMult = findPllMMult(pSetup->SYSPLLCTRL, pSetup->SYSPLLMDEC);
		workRate = (uint64_t) inPllRate * (uint64_t) mMult;
		workRate = workRate / ((uint64_t) postdiv);
	}
	else {
		/* In bypass mode */
		workRate = (uint64_t) inPllRate;
	}

	return (uint32_t) workRate;
}

/* Get the stored PLL rate */
uint32_t Chip_Clock_GetStoredPLLClockRate(void)
{
	return curPllRate;
}

/* Set the current PLL Rate */
void Chip_Clock_SetStoredPLLClockRate(uint32_t rate)
{
	curPllRate = rate;
}

/* Return System PLL output clock rate */
uint32_t Chip_Clock_GetSystemPLLOutClockRate(bool recompute)
{
	PLL_SETUP_T Setup;
	uint32_t rate;

	if ((recompute) || (curPllRate == 0)) {
		Setup.SYSPLLCTRL = LPC_SYSCON->SYSPLLCTRL;
		Setup.SYSPLLNDEC = LPC_SYSCON->SYSPLLNDEC;
		Setup.SYSPLLPDEC = LPC_SYSCON->SYSPLLPDEC;
		Setup.SYSPLLMDEC = LPC_SYSCON->SYSPLLMDEC;
		Chip_Clock_GetSystemPLLOutFromSetupUpdate(&Setup);
	}

	rate = curPllRate;
	return rate;
}

/* Return System PLL output clock rate */
uint32_t Chip_Clock_GetAudioPLLOutClockRate()
{
	uint32_t inRate = 0;
	uint64_t outRate;
	uint32_t prediv, postdiv, mMult;

	switch ((CHIP_SYSCON_AUDPLLCLKSRC_T) (LPC_SYSCON->AUDPLLCLKSEL & 0x3)) {
		case SYSCON_AUDPLLCLKSRC_FRO12MHZ:
			inRate = SYSCON_FRO12MHZ_FREQ;
			break;

		case SYSCON_AUDPLLCLKSRC_OSCCLK:
			inRate = Chip_Clock_GetExtClockInRate();
			break;
		case SYSCON_AUDPLLCLKSRC_DISABLED:
			inRate = 0;
			break;
	}

	if ((LPC_SYSCON->AUDPLLCTRL & SYSCON_SYSPLLCTRL_BYPASS_P) == 0) {
		/* PLL is not in bypass mode, get pre-divider, post-divider, and M divider */
		prediv = findPllPreDiv(LPC_SYSCON->AUDPLLCTRL, LPC_SYSCON->AUDPLLNDEC);
		postdiv = findPllPostDiv(LPC_SYSCON->AUDPLLCTRL, LPC_SYSCON->AUDPLLPDEC);

		/* Adjust input clock */
		inRate = inRate / prediv;

		/* If using the SS, use the multiplier */
		if (LPC_SYSCON->AUDPLLFRAC & (1 << 23)) {
			/* MDEC used for rate */
			mMult = findPllMMult(LPC_SYSCON->AUDPLLCTRL, LPC_SYSCON->AUDPLLMDEC);
			outRate = (uint64_t) inRate * (uint64_t) mMult;
		}
		else {
			/*FIXME: Calculation for fractional divider*/
			outRate = 0;
		}

		outRate = outRate / ((uint64_t) postdiv);
	}
	else {
		/* In bypass mode */
		outRate = (uint64_t) inRate;
	}

	return (uint32_t)outRate;
}

/* Enables and disables PLL bypass mode */
void Chip_Clock_SetBypassPLL(bool bypass)
{
	if (bypass) {
		LPC_SYSCON->SYSPLLCTRL |= SYSCON_SYSPLLCTRL_BYPASS;
	}
	else {
		LPC_SYSCON->SYSPLLCTRL &= ~SYSCON_SYSPLLCTRL_BYPASS;
	}
}

/* Set PLL output based on the passed PLL setup data */
PLL_ERROR_T Chip_Clock_SetupPLLData(PLL_CONFIG_T *pControl, PLL_SETUP_T *pSetup)
{
	uint32_t inRate;
	PLL_ERROR_T pllError;

	/* Determine input rate for the PLL */
	if ((pControl->flags & PLL_CONFIGFLAG_USEINRATE) != 0) {
		inRate = pControl->InputRate;
	}
	else {
		inRate = Chip_Clock_GetSystemPLLInClockRate();
	}

	/* PLL flag options */
	pllError = Chip_Clock_GetPllConfig(inRate, pControl->desiredRate, pSetup);
	return pllError;
}

/* Set PLL output from PLL setup structure */
PLL_ERROR_T Chip_Clock_SetupSystemPLLPrec(PLL_SETUP_T *pSetup)
{
	/* Power off PLL during setup changes */
	Chip_SYSCON_PowerDown(SYSCON_PDRUNCFG_PD_SYS_PLL);

	/* Write PLL setup data */
	LPC_SYSCON->SYSPLLCTRL = pSetup->SYSPLLCTRL;
	LPC_SYSCON->SYSPLLNDEC = pSetup->SYSPLLNDEC;
	LPC_SYSCON->SYSPLLNDEC = pSetup->SYSPLLNDEC | PLL_NDEC_NREQ;/* latch */
	LPC_SYSCON->SYSPLLPDEC = pSetup->SYSPLLPDEC;
	LPC_SYSCON->SYSPLLPDEC = pSetup->SYSPLLPDEC | PLL_PDEC_PREQ;/* latch */
	LPC_SYSCON->SYSPLLMDEC = pSetup->SYSPLLMDEC;
	LPC_SYSCON->SYSPLLMDEC = pSetup->SYSPLLMDEC | PLL_MDEC_MREQ;	/* latch */

	/* Flags for lock or power on */
	if ((pSetup->flags & (PLL_SETUPFLAG_POWERUP | PLL_SETUPFLAG_WAITLOCK)) != 0) {
		Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_SYS_PLL);
	}
	if ((pSetup->flags & PLL_SETUPFLAG_WAITLOCK) != 0) {
		while (Chip_Clock_IsSystemPLLLocked() == false) {}
	}

	/* Update current programmed PLL rate var */
	Chip_Clock_GetSystemPLLOutFromSetupUpdate(pSetup);

	/* System voltage adjustment, occurs prior to setting main system clock */
	if ((pSetup->flags & PLL_SETUPFLAG_ADGVOLT) != 0) {
		Chip_POWER_SetVoltage(curPllRate);
	}

	return PLL_ERROR_SUCCESS;
}

/* Setup PLL Frequency from pre-calculated value */
PLL_ERROR_T Chip_Clock_SetPLLFreq(const PLL_SETUP_T *pSetup)
{
	/* Power off PLL during setup changes */
	Chip_SYSCON_PowerDown(SYSCON_PDRUNCFG_PD_SYS_PLL);

	/* Write PLL setup data */
	LPC_SYSCON->SYSPLLCTRL = pSetup->SYSPLLCTRL;
	LPC_SYSCON->SYSPLLNDEC = pSetup->SYSPLLNDEC;
	LPC_SYSCON->SYSPLLNDEC = pSetup->SYSPLLNDEC | PLL_NDEC_NREQ;/* latch */
	LPC_SYSCON->SYSPLLPDEC = pSetup->SYSPLLPDEC;
	LPC_SYSCON->SYSPLLPDEC = pSetup->SYSPLLPDEC | PLL_PDEC_PREQ;/* latch */
	LPC_SYSCON->SYSPLLMDEC = pSetup->SYSPLLMDEC;
	LPC_SYSCON->SYSPLLMDEC = pSetup->SYSPLLMDEC | PLL_MDEC_MREQ;	/* latch */

	/* Flags for lock or power on */
	if ((pSetup->flags & (PLL_SETUPFLAG_POWERUP | PLL_SETUPFLAG_WAITLOCK)) != 0) {
		Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_SYS_PLL);
	}
	if ((pSetup->flags & PLL_SETUPFLAG_WAITLOCK) != 0) {
		while (Chip_Clock_IsSystemPLLLocked() == false) {}
	}

	/* Update current programmed PLL rate var */
	curPllRate = pSetup->pllRate;

	return PLL_ERROR_SUCCESS;
}

/* Set System PLL clock based on the input frequency and multiplier.
	Compare with Chip_Clock_GetPllConfig() that it set up PLL based on the 
	desired output rate, this routine only support the integer multiple of the input 
	frequency that directi is 0, ndec is fixed, then, the PLL calculation and 
	configuration is a lot simpler. 
*/
void Chip_Clock_SetupSystemPLL(uint32_t multiply_by, uint32_t input_freq)
{
	uint32_t cco_freq = input_freq * multiply_by;
	uint32_t pdec = 1;
	uint32_t selr;
	uint32_t seli;
	uint32_t selp;
	uint32_t mdec, ndec;

	uint32_t directo = 1;

	while (cco_freq < PLL_MIN_CCO_FREQ_MHZ) {
		multiply_by <<= 1;	/* double value in each iteration */
		pdec <<= 1;			/* correspondingly double pdec to cancel effect of double msel */
		cco_freq = input_freq * multiply_by;
	}
	selr = 0;
	seli = (multiply_by & 0x3c) + 4;
	selp = (multiply_by >> 1) + 1;

	if (pdec > 1) {
		directo = 0;	/* use post divider */
		pdec = pdec / 2;	/* Account for minus 1 encoding */
		/* Translate P value */
		pdec = (pdec == 1)  ? 0x62 :	/* 1  * 2 */
			   (pdec == 2)  ? 0x42 :	/* 2  * 2 */
			   (pdec == 4)  ? 0x02 :	/* 4  * 2 */
			   (pdec == 8)  ? 0x0b :	/* 8  * 2 */
			   (pdec == 16) ? 0x11 :	/* 16 * 2 */
			   (pdec == 32) ? 0x08 : 0x08;	/* 32 * 2 */
	}

	/* Only support values of 2 to 16 (to keep driver simple) */
	mdec = pllEncodeM(multiply_by);
	ndec = 0x202;	/* pre divide by 2 (hardcoded) */

	/* Power off PLL during setup changes */
	Chip_SYSCON_PowerDown(SYSCON_PDRUNCFG_PD_SYS_PLL);	
	LPC_SYSCON->SYSPLLCTRL = (directo << SYSCON_SYSPLLCTRL_DIRECTO_P) | (selr << SYSCON_SYSPLLCTRL_SELR_P) |
							 (seli << SYSCON_SYSPLLCTRL_SELI_P) | (selp << SYSCON_SYSPLLCTRL_SELP_P);
	LPC_SYSCON->SYSPLLPDEC = PLL_PDEC_PREQ | pdec;	/* set Pdec value and assert preq */
	LPC_SYSCON->SYSPLLNDEC = PLL_NDEC_NREQ | ndec;	/* set Pdec value and assert preq */
	LPC_SYSCON->SYSPLLMDEC = PLL_MDEC_MREQ | mdec;	/* select non sscg MDEC value, assert mreq and select mdec value */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_SYS_PLL);
}


/* Sets up the audio PLL */
PLL_ERROR_T Chip_Clock_SetAudioPLLFreq(const AUDPLL_SETUP_T *pSetup)
{
	/* Power off PLL during setup changes */
	Chip_SYSCON_PowerDown(SYSCON_PDRUNCFG_PD_AUDPLL);

	/* Write PLL setup data */
	LPC_SYSCON->AUDPLLCTRL = pSetup->AUDPLLCTRL;
	LPC_SYSCON->AUDPLLNDEC = pSetup->AUDPLLNDEC;
	LPC_SYSCON->AUDPLLNDEC = pSetup->AUDPLLNDEC | PLL_NDEC_NREQ;/* latch */
	LPC_SYSCON->AUDPLLPDEC = pSetup->AUDPLLPDEC;
	LPC_SYSCON->AUDPLLPDEC = pSetup->AUDPLLPDEC | PLL_PDEC_PREQ;/* latch */
	LPC_SYSCON->AUDPLLMDEC = pSetup->AUDPLLMDEC;
	LPC_SYSCON->AUDPLLMDEC = pSetup->AUDPLLMDEC | PLL_MDEC_MREQ;	/* latch */
	LPC_SYSCON->AUDPLLFRAC = pSetup->AUDPLLFRAC;
	if((pSetup->AUDPLLFRAC & (1 << 23)) == 0) {
		LPC_SYSCON->AUDPLLFRAC = pSetup->AUDPLLFRAC | (1 << 22);
	}

	/* Flags for lock or power on */
	if ((pSetup->flags & (PLL_SETUPFLAG_POWERUP | PLL_SETUPFLAG_WAITLOCK)) != 0) {
		Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_AUDPLL);
	}
	if ((pSetup->flags & PLL_SETUPFLAG_WAITLOCK) != 0) {
		while (Chip_Clock_IsAudioPLLLocked() == false) {}
	}

	return PLL_ERROR_SUCCESS;
}
