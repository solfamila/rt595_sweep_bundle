/*
 * @brief LPC18xx/43xx Power Management Controller driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __PMC_18XX_43XX_H_
#define __PMC_18XX_43XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup PMC_18XX_43XX CHIP: LPC18xx/43xx Power Management Controller driver
 * @ingroup CHIP_18XX_43XX_Drivers
 * @{
 */

/**
 * @brief Power Management Controller register block structure
 */
typedef struct {						/*!< PMC Structure          */
	__IO uint32_t  PD0_SLEEP0_HW_ENA;	/*!< Hardware sleep event enable register */
	__I  uint32_t  RESERVED0[6];
	__IO uint32_t  PD0_SLEEP0_MODE;		/*!< Sleep power mode register */
} LPC_PMC_T;

/**
 * @brief Power Management Controller power modes
 * Setting this mode will not make IO loose the state
 */
#define PMC_PWR_DEEP_SLEEP_MODE         0x3000AA
#define PMC_PWR_POWER_DOWN_MODE         0x30FCBA
#define PMC_PWR_DEEP_POWER_DOWN_MODE    0x30FF7F

/**
 * @brief Power Management Controller power modes (IO powerdown)
 * Setting this mode will make the IO loose the state
 */
#define PMC_PWR_DEEP_SLEEP_MODE_NO_IO         0x3F00AA
#define PMC_PWR_POWER_DOWN_MODE_NO_IO         0x3FFCBA
#define PMC_PWR_DEEP_POWER_DOWN_MODE_NO_IO    0x3FFF7F

/*
 * @brief PMC power states
 */
typedef enum {
	PMC_DeepSleep = PMC_PWR_DEEP_SLEEP_MODE,			/*!< Deep sleep state */
	PMC_PowerDown = PMC_PWR_POWER_DOWN_MODE,			/*!< Power Down state */
	PMC_DeepPowerDown = PMC_PWR_DEEP_POWER_DOWN_MODE,	/*!< Power Down state */
} CHIP_PMC_PWR_STATE_T;

/**
 * @brief	Set to sleep power state
 * @return	Nothing
 */
void Chip_PMC_Sleep(void);

/**
 * @brief	Set to sleep power mode
 * @param	PwrState	: Power State as specified in /a CHIP_PMC_PWR_STATE_T enum
 * @return	Nothing
 */
void Chip_PMC_Set_PwrState(CHIP_PMC_PWR_STATE_T PwrState);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __PMC_18XX_43XX_H_ */
