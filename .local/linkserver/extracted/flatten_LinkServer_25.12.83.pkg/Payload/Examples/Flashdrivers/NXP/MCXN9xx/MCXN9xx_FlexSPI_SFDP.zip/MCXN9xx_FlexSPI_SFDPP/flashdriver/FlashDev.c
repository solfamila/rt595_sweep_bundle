
//*****************************************************************************
// FlashDev.c
// MCUXpresso IDE Flash driver - Flash Device settings
//
// MCXN9xx FlexSPI drivers
//
//*****************************************************************************
//
// Copyright 2022-2023 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "FlashConfig.h"
#include "lpcx_flash_driver.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS, // Driver Version, do not modify!

#if defined (MCXN9xx_SFDP_FlexSPI)
   "MCXN9xx_SFDP_FlexSPI "__DATE__" "__TIME__,
#elif defined (MCXN9xx_SFDP_FlexSPI_S)
   "MCXN9xx_SFDP_FlexSPI (Secure) "__DATE__" "__TIME__,
#else
#error "No driver defined"
#endif

   EXTSPIJ, // Device Type

   FLASH_BASE_ADDR, // Device Start Address

   0,          // Device Size ** Will be updated by call to Init() **
   0,          // Programming Page Size ** Will be updated by call to Init() **
   0,          // Reserved, must be 0
   0xFF,       // Initial Content of Erased Memory
   3000,       // Program Page Timeout
   6000,       // Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{0x0, 0},   // Sector sizes ** Will be updated by call to Init() **
   {SECTOR_END}}
};

