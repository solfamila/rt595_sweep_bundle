SST39VF3201x Flash driver for Hitex LPC1850A / LPC4350A board
=============================================================

[Updated - 16 August 2012]

This project provides all files required to build a flash driver
for the SST39Vf3201B or SST39Vf3201 4MB flash fitted onto the 
Hitex LPC1850A and LPC4350A development boards.

The code is based on the Flash driver sources provided in the
LPC18xxA Peripheral Driver Library 
[RELEASE CMSIS for REV A 20111209]
which is available from http://www.lpcware.com/
updated with the flash driver files provided with the Hitex 
LPC1850EVA-A4/ LPC4350EVA-A4 boards.

Two project configurations are provided....

Debug - produces a test version of the flash driver that can be
        run within the Code Red debug environment. This configuration
        builds the flash driver wrapped by an interface that mimics
        the interface used by the Code Red IDE when programming a
        project executable into flash.
        
FlashDriver_4MB - produces an actual flash driver (.cfx) file for use
        by Red Suite to program a project into flash.
        
