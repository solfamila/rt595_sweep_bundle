/*
 * @brief LPC17xx/40xx Comparator driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

#if defined(CHIP_LPC40XX)

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Initializes the CMP */
void Chip_CMP_Init(void)
{
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_CMP);
}

/* De-initializes the CMP */
void Chip_CMP_DeInit(void)
{
	Chip_Clock_DisablePeriphClock(SYSCTL_CLOCK_CMP);
}

#endif /* defined(CHIP_LPC40XX) */
