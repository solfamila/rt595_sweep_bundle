//*****************************************************************************
// FlashDev.c
// MCUXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "lpcx_flash_driver.h"
#include "FlashConfig.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS,              // Driver Version, do not modify!
#if defined (MIMXRT700_XSPI0_Octal) || defined (MIMXRT700_XSPI0_Octal_S)
   "iMXRT700_XSPI0_Octal Flash "__DATE__" "__TIME__,
#elif defined (MIMXRT700_XSPI1_Octal) || defined (MIMXRT700_XSPI1_Octal_S)
   "iMXRT700_XSPI1_Octal Flash "__DATE__" "__TIME__,
#else
#error "No driver defined"
#endif
   EXTSPI,                      // Device Type
   FLASH_BASE_ADDR,             // Device Start Address
   FLASH_SIZE,                  // Device Size
   FLASH_PAGE_SIZE,             // Programming Page Size
   0,                           // Reserved, must be 0
   0xFF,                        // Initial Content of Erased Memory
   1000,                        // Program Page Timeout
   3000,                        // Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{FLASH_SECTOR_SIZE, 0},           // Sector sizes
   {SECTOR_END}}
};
