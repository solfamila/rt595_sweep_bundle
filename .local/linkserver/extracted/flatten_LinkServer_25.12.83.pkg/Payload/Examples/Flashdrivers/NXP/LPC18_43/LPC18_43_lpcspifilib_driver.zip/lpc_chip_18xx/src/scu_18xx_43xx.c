/*
 * @brief LPC18xx/43xx System Control Unit (SCU) control functions
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* GPIO Interrupt Pin Select */
void Chip_SCU_GPIOIntPinSel(uint8_t PortSel, uint8_t PortNum, uint8_t PinNum)
{
	uint8_t  pinInt;
	volatile uint32_t pinSel;

	pinInt = ((PortNum & 0x7) << 5) | (PinNum & 0x1F);
	if (PortSel < 4) {
		pinSel = LPC_SCU->PINTSEL0;
		pinSel &= ~(0xFF << (PortSel * 8));
		pinSel |= (pinInt << (PortSel * 8));
		LPC_SCU->PINTSEL0 = pinSel;
	}
	else {
		pinSel = LPC_SCU->PINTSEL1;
		pinSel &= ~(0xFF << ((PortSel - 4) * 8));
		pinSel |= (pinInt << ((PortSel - 4) * 8));
		LPC_SCU->PINTSEL1 = pinSel;
	}
}
