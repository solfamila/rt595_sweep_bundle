/*
 * @brief LPC5460x OTP driver
 *
 * @note
 * Copyright 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef _OTP_5460X_H_
#define _OTP_5460X_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup OTP_5460X CHIP: LPC5460X OTP driver
 * @ingroup CHIP_5460X_Drivers
 * @{
 */

/** OTP Bank Count */
#define OTP_BANK_COUNT      4

#define OTP_AES1_BANK       1
#define OTP_AES2_BANK       2
#define OTP_ROM_BANK        3

#define OTP_ECRP_REG        0	/* Register used to contain eCRP bits */
#define OTP_SECURE_REG      1	/* Register used to contain security feature bits */

/**
 * @brief OTP register block structure
 */
typedef struct {
	__I uint32_t   OTP[OTP_BANK_COUNT][4];			/* 0x0 - OTP[0][0] .. OTP[3][3] */
} LPC_OTP_T;


/**
 * @brief	Returns the reqister value from bank[regOffset]
 * @param	bank		: Bank to read from 0-3
 * @param   regOffset	: Register offset to read 0-3
 * @return	Value at specified location.
 */
static INLINE uint32_t Chip_OTP_ReadBankRegister(uint32_t bank, uint32_t regOffset)
{
	return LPC_OTP->OTP[bank][regOffset];
}


/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* _OTP_5460X_H_ */
