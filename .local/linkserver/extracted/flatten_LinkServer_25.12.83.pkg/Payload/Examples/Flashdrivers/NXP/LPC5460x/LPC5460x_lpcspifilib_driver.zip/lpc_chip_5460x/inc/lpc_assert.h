/*
 * @brief LPC5460x Assert file
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __LPC_ASSERT_H
#define __LPC_ASSERT_H

#if defined(__CC_ARM)
	#if (__OPTIMISE_LEVEL > 0)
		#define LPC_ASSERT(cond,file,line) if(!(cond)){} /* Required to avoid unused variable warning */
	#else
		#define LPC_ASSERT(cond,file,line) if(!(cond)){__BKPT(line & 0xFF);}
	#endif
#elif defined(__ICCARM__)
	#if defined(NDEBUG)
		#define LPC_ASSERT(cond,file,line) if(!(cond)){} /* Required to avoid unused variable warning */
	#else
		#define LPC_ASSERT(cond,file,line) if(!(cond)){__BKPT(line);}
	#endif
#elif defined(__GNUC__)
	#if defined(NDEBUG)
		#define LPC_ASSERT(cond,file,line) if(!(cond)){} /* Required to avoid unused variable warning */
	#else
		#define LPC_ASSERT(cond,file,line) if(!(cond)){__BKPT(line);}
	#endif
#else
	#define LPC_ASSERT(cond,file,line) if(!(cond)){} /* Required to avoid unused variable warning */
#endif

#endif /* __LPC_ASSERT_H */

