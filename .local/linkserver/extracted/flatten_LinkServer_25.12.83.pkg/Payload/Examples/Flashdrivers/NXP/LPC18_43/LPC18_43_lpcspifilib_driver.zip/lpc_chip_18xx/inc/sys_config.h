/*
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __SYS_CONFIG_H_
#define __SYS_CONFIG_H_

/* LPC18xx chip family */
#define CHIP_LPC18XX

#endif /* __SYS_CONFIG_H_ */
