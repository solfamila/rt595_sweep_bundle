/*
 * @brief Common LPCOpen SystemInit function
 *
 * @note
 * Copyright 2013, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */
 #if defined(NO_BOARD_LIB)
 #include "chip.h"
 #else
 #include "board.h"
 #endif
/*****************************************************************************
 * Public functions
 ****************************************************************************/
#if defined(NO_BOARD_LIB)
const uint32_t ExtClockIn = 0;
//const uint32_t RTCOscRateIn = 32768;
#endif

//const uint32_t ExtClockIn = 0;

/* Set up and initialize hardware prior to call to main */
void SystemInit(void)
{
#if defined(__CODE_RED)
	extern void(*const g_pfnVectors[]) (void);
	SCB->VTOR = (uint32_t) &g_pfnVectors;
#else
	extern void *__Vectors;
	SCB->VTOR = (uint32_t) &__Vectors;
#endif

#if defined(CORE_M4)
#if defined(__FPU_PRESENT) && __FPU_PRESENT == 1
	fpuInit();
#endif
#endif

#if defined(NO_BOARD_LIB)
	/* Chip specific SystemInit */
	Chip_SystemInit();
#else
	/* Board specific SystemInit */
	Board_SystemInit();
#endif
}

