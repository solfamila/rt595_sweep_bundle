/*
 * @brief LPC18xx/43xx D/A conversion driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __DAC_18XX_43XX_H_
#define __DAC_18XX_43XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup DAC_18XX_43XX CHIP: LPC18xx/43xx D/A conversion driver
 * @ingroup CHIP_18XX_43XX_Drivers
 * @{
 */

/**
 * @brief DAC register block structure
 */
typedef struct {			/*!< DAC Structure          */
	__IO uint32_t  CR;		/*!< DAC register. Holds the conversion data. */
	__IO uint32_t  CTRL;	/*!< DAC control register.  */
	__IO uint32_t  CNTVAL;	/*!< DAC counter value register. */
} LPC_DAC_T;

/** After the selected settling time after this field is written with a
   new VALUE, the voltage on the AOUT pin (with respect to VSSA)
   is VALUE/1024 ? VREF */
#define DAC_VALUE(n)        ((uint32_t) ((n & 0x3FF) << 6))
/** If this bit = 0: The settling time of the DAC is 1 microsecond max,
 * and the maximum current is 700 microAmpere
 * If this bit = 1: The settling time of the DAC is 2.5 microsecond
 * and the maximum current is 350 microAmpere
 */
#define DAC_BIAS_EN         ((uint32_t) (1 << 16))
/** Value to reload interrupt DMA counter */
#define DAC_CCNT_VALUE(n)  ((uint32_t) (n & 0xffff))

/** DCAR double buffering */
#define DAC_DBLBUF_ENA      ((uint32_t) (1 << 1))
/** DCAR Time out count enable */
#define DAC_CNT_ENA         ((uint32_t) (1 << 2))
/** DCAR DMA access */
#define DAC_DMA_ENA         ((uint32_t) (1 << 3))
/** DCAR DACCTRL mask bit */
#define DAC_DACCTRL_MASK    ((uint32_t) (0x0F))

/**
 * @brief Current option in DAC configuration option
 */
typedef enum IP_DAC_CURRENT_OPT {
	DAC_MAX_UPDATE_RATE_1MHz = 0,	/*!< Shorter settling times and higher power consumption;
									    allows for a maximum update rate of 1 MHz */
	DAC_MAX_UPDATE_RATE_400kHz		/*!< Longer settling times and lower power consumption;
									    allows for a maximum update rate of 400 kHz */
} DAC_CURRENT_OPT_T;

/**
 * @brief	Initial DAC configuration
 *              - Maximum	current is 700 uA
 *              - Value to AOUT is 0
 * @param	pDAC	: pointer to LPC_DAC_T
 * @return	Nothing
 */
void Chip_DAC_Init(LPC_DAC_T *pDAC);

/**
 * @brief	Shutdown DAC
 * @param	pDAC	: pointer to LPC_DAC_T
 * @return	Nothing
 */
void Chip_DAC_DeInit(LPC_DAC_T *pDAC);

/**
 * @brief	Update value to DAC buffer
 * @param	pDAC		: pointer to LPC_DAC_T
 * @param	dac_value	: value 10 bit to be converted to output
 * @return	Nothing
 */
void Chip_DAC_UpdateValue(LPC_DAC_T *pDAC, uint32_t dac_value);

/**
 * @brief	Set maximum update rate for DAC
 * @param	pDAC	: pointer to LPC_DAC_T
 * @param	bias	: Using Bias value, should be:
 *              - 0 is 1MHz
 *              - 1 is 400kHz
 * @return	Nothing
 */
void Chip_DAC_SetBias(LPC_DAC_T *pDAC, uint32_t bias);

/**
 * @brief	Enables the DMA operation and controls DMA timer
 * @param	pDAC		: pointer to LPC_DAC_T
 * @param	dacFlags	: An Or'ed value of the following DAC values:
 *                  - DAC_DBLBUF_ENA :enable/disable DACR double buffering feature
 *                  - DAC_CNT_ENA    :enable/disable timer out counter
 *                  - DAC_DMA_ENA    :enable/disable DMA access
 * @return	Nothing
 * @note	Pass an Or'ed value of the DAC flags to enable those options.
 */
STATIC INLINE void Chip_DAC_ConfigDAConverterControl(LPC_DAC_T *pDAC, uint32_t dacFlags)
{
	uint32_t temp;

	temp = pDAC->CTRL & ~DAC_DACCTRL_MASK;
	pDAC->CTRL = temp | dacFlags;
}

/**
 * @brief	Set reload value for interrupt/DMA counter
 * @param	pDAC		: pointer to LPC_DAC_T
 * @param	time_out	: time out to reload for interrupt/DMA counter
 * @return	Nothing
 */
STATIC INLINE void Chip_DAC_SetDMATimeOut(LPC_DAC_T *pDAC, uint32_t time_out)
{
	pDAC->CNTVAL = DAC_CCNT_VALUE(time_out);
}

/**
 * @brief	Get status for interrupt/DMA time out
 * @param	pDAC	: pointer to LPC_DAC_T
 * @return	interrupt/DMA time out status, should be SET or RESET
 */
STATIC INLINE IntStatus Chip_DAC_GetIntStatus(LPC_DAC_T *pDAC)
{
	return (pDAC->CTRL & 0x01) ? SET : RESET;
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __DAC_18XX_43XX_H_ */
