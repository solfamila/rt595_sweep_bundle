//*****************************************************************************
// testapp.c
// MCUXpresso Flash driver test functions
//*****************************************************************************
//
// Copyright 2022-2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************
//
//#include "stdlib.h"
//#include "stdio.h"
#include "fsl_debug_console.h"
#include "string.h"
#include "lpcx_flash_driver.h"
#include "FlashConfig.h"

// Make sure this file is compiled without optimizations (due to TIMER_ macros) below
// regardless of the project-level optimization setting
#pragma GCC push_options
#pragma GCC optimize ("O0")

unsigned char buf[256] __attribute__ ((aligned (4)));

#define TESTAPP_SECTOR		2
#define TESTAPP_PAGE		3

int main(void) {
    unsigned int addr;
    unsigned int sector_addr = 0xFFFFFFFF;
    unsigned int sector_size = 0xFFFFFFFF;
    unsigned int allocated = 0;
    int idx;
    int no_blocks = 0;
    int no_sectors = 0;
    int status = 0;

    printf("Flash Driver test program starting\n");

    status = Init();
    if (status) {
        printf("Init failed 1\n");
    }

    printf("Flash driver : %s\n", FlashDevice.DevName);
    printf("Detected properties\n");
    printf("- Flash size : %d KB\n", FlashDevice.szDev / 1024);
    printf("- Flash ProgramPage size : %d bytes\n", FlashDevice.szPage);
    printf("- Flash sector size : %d bytes\n", FlashDevice.sectors[0].szSector);

    status = Init();
    if (status) {
        printf("Init failed 2\n");
    }

    // no_blocks is the number of entries in FlashDevice.sectors
    for (idx = 0;; idx++) {
        if ((FlashDevice.sectors[idx].szSector == 0xFFFFFFFF)
                && (FlashDevice.sectors[idx].AddrSector == 0xFFFFFFFF))
            break;
        no_blocks++;
    }

    // Rules check for loadable flash driver
    for (idx = 0; idx < no_blocks; idx++) {
        if ((FlashDevice.sectors[idx].AddrSector == 0xFFFFFFFF)
                && (FlashDevice.szDev - allocated)) {
            no_sectors += (FlashDevice.szDev - allocated)
                    / FlashDevice.sectors[idx - 1].szSector;
            break;
        } else if (sector_addr == 0xFFFFFFFF) {
            sector_addr = FlashDevice.sectors[idx].AddrSector;
            sector_size = FlashDevice.sectors[idx].szSector;
            if (!allocated) {
                no_sectors += (FlashDevice.szDev / sector_size);
                allocated = FlashDevice.szDev;
            }
        } else {
            allocated = FlashDevice.sectors[idx].AddrSector
                    - FlashDevice.sectors[idx - 1].AddrSector;
            no_sectors += allocated / FlashDevice.sectors[idx].szSector;
        }
    }
    // populate buffer with pattern
    srand(0x2);
    for (idx = 0; idx < sizeof(buf); idx++) {
        buf[idx] = rand();
    }

#if 1
    if (EraseChip)
    {
        printf("Erasing chip\n");
        status = EraseChip();
        if (status)
        {
            printf("Erase chip failed\n");
        }
    }
#endif

    // address of flash device
    for (idx = 0; idx < no_sectors; idx++) {
        addr = sector_addr = FlashDevice.DevAdr + sector_size * idx;
#if 1
        printf("Erase sector %d (0x%x)\n", idx, addr);
        status = EraseSectors(addr, 1);
        if (status) {
            printf("Erase sector %d (0x%x) failed. Status = %d\n", idx, addr,
                    status);
            break;
        }
#endif
        sector_addr = addr + sector_size;   // next sector address
#if 1
        do {
            for (int i = 0; i < FlashDevice.szPage; i++) {
                buf[i] = rand();
            }

            //			printf("Program sector %d at 0x%x.\n", idx, addr);
            // program sector by page
            status = ProgramPage(addr, FlashDevice.szPage, buf);
            // verify page
            if (!status) {
                status = Verify(addr, FlashDevice.szPage, buf);
            }
            if (status) {
                printf("Program sector %d failed at 0x%x.\n", idx, addr);
                break;
            }
            addr += FlashDevice.szPage;
        } while (addr < sector_addr);
#endif
        if (status)
            break;
    }

#if 0

    // Target-level benchmark
    // Please make sure the flash driver is compiled with optimizations to get relevant results

#if defined(DEBUG)
    //#error "For relevant results turn off DEBUG in order to strip away printing code from the flash driver!"
#endif

    unsigned int test_sector_addr = FlashDevice.DevAdr + sector_size * TESTAPP_SECTOR;
    addr = test_sector_addr + FlashDevice.szPage * TESTAPP_PAGE;
    uint32_t st, end, diff;

    TIMER_START(st);
    status = EraseChip();
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Erase chip             : %d\n", diff);

    // all zeros
    memset((void *)buf, 0x00, FlashDevice.szPage);

    TIMER_START(st);
    status = ProgramPage(addr, FlashDevice.szPage, buf);
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Program sector (zeros)  : %d\n", diff);

    TIMER_START(st);
    status = Verify(addr, FlashDevice.szPage, buf);
    if (status)
        printf("Verify page failed\n");
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Verify sector (zeros)   : %d\n", diff);

    TIMER_START(st);
    status = EraseSectors(test_sector_addr, 1);
    if (status)
        printf("Erase sector failed\n");
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Erase sector (ones)    : %d\n", diff);

    // all ones
    memset((void *)buf, 0xFF, FlashDevice.szPage);

    TIMER_START(st);
    status = ProgramPage(addr, FlashDevice.szPage, buf);
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Program sector (ones) : %d\n", diff);

    TIMER_START(st);
    status = Verify(addr, FlashDevice.szPage, buf);
    if (status)
        printf("Verify page failed\n");
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Verify sector (ones)  : %d\n", diff);


    TIMER_START(st);
    EraseSectors(test_sector_addr, 1);
    if (status)
        printf("Erase sector failed\n");
    TIMER_STOP(end);
    diff = TIMER_DIFF(st, end);
    printf("Erase sector (zeros)   : %d\n", diff);
#endif

    status = UnInit();
    if (status) {
        printf("UnInit failed\n");
    }

    printf("Finished\n");

    while(1);
    return 0;
}

#pragma GCC pop_options
