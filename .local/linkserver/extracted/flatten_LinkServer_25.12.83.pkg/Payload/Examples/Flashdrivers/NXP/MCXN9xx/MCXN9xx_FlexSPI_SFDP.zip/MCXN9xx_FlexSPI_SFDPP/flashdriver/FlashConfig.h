//*****************************************************************************
// FlashConfig.h
// MCUXpresso IDE Flash driver
// Config file for MCXN9xx FlexSPI driver
//*****************************************************************************
//
// Copyright 2022-2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#ifndef FLASHCONFIG_H_
#define FLASHCONFIG_H_

#include "fsl_flexspi_nor_flash.h"

extern flexspi_nor_config_t flashConfig;

#if defined (DEBUG)
#define MCXN9xx_SFDP_FlexSPI
#endif


//  MCX N1xNxxx Reference Manual - 15.4.2 FlexSPI NOR Configuration Option Block

#if defined (MCXN9xx_SFDP_FlexSPI) || defined (MCXN9xx_SFDP_FlexSPI_S)
/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 1   : max_freq (0 = Don't change FlexSPI clock setting)
 */
#define CONFIG_OPTION0  0xC0000001

/*
 * 0x0 : Single Flash connected to Port A
 */
#define CONFIG_OPTION1  0x00000000

#endif

// =====================================
// Flash Base Address Information
// =====================================
#if defined (MCXN9xx_SFDP_FlexSPI_S)
    #define USE_SECURE_FLASHADDR
    #define FLASH_BASE_ADDR 0x90000000
#else
    #define FLASH_BASE_ADDR 0x80000000
#endif

#endif /* FLASHCONFIG_H_ */
