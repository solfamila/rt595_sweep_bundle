/*
 * @brief LPC5460X IOCON register block and driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __IOCON_5460X_H_
#define __IOCON_5460X_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup IOCON_5460X CHIP: LPC5460X IOCON register block and driver
 * @ingroup CHIP_5460X_DRIVERS
 * @{
 */

/**
 * @brief LPC5460X IO Configuration Unit register block structure
 */
typedef struct {			/*!< LPC5460X IOCON Structure */
	__IO uint32_t  PIO[5][32];
} LPC_IOCON_T;

/**
 * @brief Array of IOCON pin definitions passed to Chip_IOCON_SetPinMuxing() must be in this format
 */
typedef struct {
	uint32_t port : 8;			/* Pin port */
	uint32_t pin : 8;			/* Pin number */
	uint32_t modefunc : 16;		/* Function and mode */
} PINMUX_GRP_T;

/**
 * IOCON function and mode selection definitions
 * See the User Manual for specific modes and functions supported by the
 * various LPC15XX pins.
 */
#define IOCON_FUNC0             0x0				/*!< Selects pin function 0 */
#define IOCON_FUNC1             0x1				/*!< Selects pin function 1 */
#define IOCON_FUNC2             0x2				/*!< Selects pin function 2 */
#define IOCON_FUNC3             0x3				/*!< Selects pin function 3 */
#define IOCON_FUNC4             0x4				/*!< Selects pin function 4 */
#define IOCON_FUNC5             0x5				/*!< Selects pin function 5 */
#define IOCON_FUNC6             0x6				/*!< Selects pin function 6 */
#define IOCON_FUNC7             0x7				/*!< Selects pin function 7 */
#define IOCON_FUNC8             0x8				/*!< Selects pin function 8 */
#define IOCON_FUNC9             0x9				/*!< Selects pin function 9 */
#define IOCON_FUNC10            0xA				/*!< Selects pin function 10 */
#define IOCON_FUNC11            0xB				/*!< Selects pin function 11 */
#define IOCON_FUNC12            0xC				/*!< Selects pin function 12 */
#define IOCON_FUNC13            0xD				/*!< Selects pin function 13 */
#define IOCON_FUNC14            0xE				/*!< Selects pin function 14 */
#define IOCON_FUNC15            0xF				/*!< Selects pin function 15 */
#define IOCON_MODE_INACT        (0x0 << 4)		/*!< No addition pin function */
#define IOCON_MODE_PULLDOWN     (0x1 << 4)		/*!< Selects pull-down function */
#define IOCON_MODE_PULLUP       (0x2 << 4)		/*!< Selects pull-up function */
#define IOCON_MODE_REPEATER     (0x3 << 4)		/*!< Selects pin repeater function */
#define IOCON_HYS_EN            (0x1 << 6)		/*!< Enables hysteresis */
#define IOCON_GPIO_MODE         (0x1 << 6)		/*!< GPIO Mode */
#define IOCON_I2C_SLEW          (0x1 << 6)		/*!< I2C Slew Rate Control */
#define IOCON_INV_EN            (0x1 << 7)		/*!< Enables invert function on input */
#define IOCON_ANALOG_EN         (0x0 << 8)		/*!< Enables analog function by setting 0 to bit 7 */
#define IOCON_DIGITAL_EN        (0x1 << 8)		/*!< Enables digital function by setting 1 to bit 7(default) */
#define IOCON_STDI2C_EN         (0x1 << 9)		/*!< I2C standard mode/fast-mode */
#define IOCON_FASTI2C_EN        (0x3 << 9)		/*!< I2C Fast-mode Plus and high-speed slave */
#define IOCON_INPFILT_OFF       (0x1 << 9)		/*!< Input filter Off for GPIO pins */
#define IOCON_INPFILT_ON        (0x0 << 9)		/*!< Input filter On for GPIO pins */
#define IOCON_HIGH_SPEED_EN     (0x1 << 10)     /*!< High speed enable */
#define IOCON_OPENDRAIN_EN      (0x1 << 11)		/*!< Enables open-drain function */
#define IOCON_S_MODE_0CLK       (0x0 << 12)		/*!< Bypass input filter */
#define IOCON_S_MODE_1CLK       (0x1 << 12)		/*!< Input pulses shorter than 1 filter clock are rejected */
#define IOCON_S_MODE_2CLK       (0x2 << 12)		/*!< Input pulses shorter than 2 filter clock2 are rejected */
#define IOCON_S_MODE_3CLK       (0x3 << 12)		/*!< Input pulses shorter than 3 filter clock2 are rejected */
#define IOCON_S_MODE(clks)      ((clks) << 12)	/*!< Select clocks for digital input filter mode */
#define IOCON_CLKDIV(div)       ((div) << 14)	/*!< Select peripheral clock divider for input filter sampling clock, 2^n, n=0-6 */

/**
 * @brief	Sets I/O Control pin mux
 * @param	pIOCON		: The base of IOCON peripheral on the chip
 * @param	port		: GPIO port to mux
 * @param	pin			: GPIO pin to mux
 * @param	modefunc	: OR'ed values or type IOCON_*
 * @return	Nothing
 */
__STATIC_INLINE void Chip_IOCON_PinMuxSet(LPC_IOCON_T *pIOCON, uint8_t port, uint8_t pin, uint32_t modefunc)
{
	pIOCON->PIO[port][pin] = modefunc;
}

/**
 * @brief	I/O Control pin mux
 * @param	pIOCON	: The base of IOCON peripheral on the chip
 * @param	port	: GPIO port to mux
 * @param	pin		: GPIO pin to mux
 * @param	mode	: OR'ed values or type IOCON_*
 * @param	func	: Pin function, value of type IOCON_FUNC?
 * @return	Nothing
 */
__STATIC_INLINE void Chip_IOCON_PinMux(LPC_IOCON_T *pIOCON, uint8_t port, uint8_t pin, uint16_t mode, uint8_t func)
{
	Chip_IOCON_PinMuxSet(pIOCON, port, pin, (uint32_t) (mode | func));
}

/**
 * @brief	Set all I/O Control pin muxing
 * @param	pIOCON	    : The base of IOCON peripheral on the chip
 * @param	pinArray    : Pointer to array of pin mux selections
 * @param	arrayLength : Number of entries in pinArray
 * @return	Nothing
 */
__STATIC_INLINE void Chip_IOCON_SetPinMuxing(LPC_IOCON_T *pIOCON, const PINMUX_GRP_T *pinArray, uint32_t arrayLength)
{
	uint32_t ix;

	for (ix = 0; ix < arrayLength; ix++ ) {
		Chip_IOCON_PinMuxSet(pIOCON, pinArray[ix].port, pinArray[ix].pin, pinArray[ix].modefunc);
	}
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __IOCON_5460X_H_ */
