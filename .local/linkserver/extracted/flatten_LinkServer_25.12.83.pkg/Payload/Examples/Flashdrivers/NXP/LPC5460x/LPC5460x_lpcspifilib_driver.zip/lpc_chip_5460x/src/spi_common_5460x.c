/*
 * @brief LPC5460X SPI driver
 *
 * @note
 * Copyright 2015-2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/
/* Initialize SPI Interface */
int Chip_SPI_Init(LPC_SPI_T *pSPI)
{
	int ret;
	ret = Chip_FLEXCOMM_Init(pSPI, FLEXCOMM_PERIPH_SPI);
	if (!ret) { /* Enable the FIFOs */
		Chip_SPI_SetFIFOCfg(pSPI, SPI_FIFOCFG_ENABLETX | SPI_FIFOCFG_ENABLERX);
		Chip_SPI_FlushFIFOs(pSPI);
		Chip_SPI_SetFIFOTrigLevel(pSPI, SPI_FIFOTRIG_TXLVL_DEFAULT, SPI_FIFOTRIG_RXLVL_DEFAULT);
	}
	return ret;
}

/* Setup SAPI configuration */
void Chip_SPI_ConfigureSPI(LPC_SPI_T *pSPI, SPI_CFGSETUP_T *pCFG)
{
	uint32_t reg;

	/* Get register and mask off config bits this function alters */
	reg = pSPI->CFG & ~(SPI_CFG_MASTER_EN | SPI_CFG_LSB_FIRST_EN |
						SPI_CFG_CPHA_SECOND | SPI_CFG_CPOL_HI);

	if (pCFG->master) {
		reg |= SPI_CFG_MASTER_EN;
	}
	if (pCFG->lsbFirst) {
		reg |= SPI_CFG_LSB_FIRST_EN;
	}
	reg |= (uint32_t) pCFG->mode;

	Chip_SPI_SetCFGRegBits(pSPI, reg);
}
