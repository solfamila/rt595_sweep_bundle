/*
 * @brief LPC18xx/43xx Quadrature Encoder Interface driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __QEI_18XX_43XX_H_
#define __QEI_18XX_43XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup QEI_18XX_43XX CHIP: LPC18xx/43xx Quadrature Encoder Interface driver
 * @ingroup CHIP_18XX_43XX_Drivers
 * @{
 */

/**
 * @brief Quadrature Encoder Interface register block structure
 */
typedef struct {				/*!< QEI Structure          */
	__O  uint32_t  CON;			/*!< Control register       */
	__I  uint32_t  STAT;		/*!< Encoder status register */
	__IO uint32_t  CONF;		/*!< Configuration register */
	__I  uint32_t  POS;			/*!< Position register      */
	__IO uint32_t  MAXPOS;		/*!< Maximum position register */
	__IO uint32_t  CMPOS0;		/*!< position compare register 0 */
	__IO uint32_t  CMPOS1;		/*!< position compare register 1 */
	__IO uint32_t  CMPOS2;		/*!< position compare register 2 */
	__I  uint32_t  INXCNT;		/*!< Index count register   */
	__IO uint32_t  INXCMP0;		/*!< Index compare register 0 */
	__IO uint32_t  LOAD;		/*!< Velocity timer reload register */
	__I  uint32_t  TIME;		/*!< Velocity timer register */
	__I  uint32_t  VEL;			/*!< Velocity counter register */
	__I  uint32_t  CAP;			/*!< Velocity capture register */
	__IO uint32_t  VELCOMP;		/*!< Velocity compare register */
	__IO uint32_t  FILTERPHA;	/*!< Digital filter register on input phase A (QEI_A) */
	__IO uint32_t  FILTERPHB;	/*!< Digital filter register on input phase B (QEI_B) */
	__IO uint32_t  FILTERINX;	/*!< Digital filter register on input index (QEI_IDX) */
	__IO uint32_t  WINDOW;		/*!< Index acceptance window register */
	__IO uint32_t  INXCMP1;		/*!< Index compare register 1 */
	__IO uint32_t  INXCMP2;		/*!< Index compare register 2 */
	__I  uint32_t  RESERVED0[993];
	__O  uint32_t  IEC;			/*!< Interrupt enable clear register */
	__O  uint32_t  IES;			/*!< Interrupt enable set register */
	__I  uint32_t  INTSTAT;		/*!< Interrupt status register */
	__I  uint32_t  IE;			/*!< Interrupt enable register */
	__O  uint32_t  CLR;			/*!< Interrupt status clear register */
	__O  uint32_t  SET;			/*!< Interrupt status set register */
} LPC_QEI_T;

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __QEI_18XX_43XX_H_ */
