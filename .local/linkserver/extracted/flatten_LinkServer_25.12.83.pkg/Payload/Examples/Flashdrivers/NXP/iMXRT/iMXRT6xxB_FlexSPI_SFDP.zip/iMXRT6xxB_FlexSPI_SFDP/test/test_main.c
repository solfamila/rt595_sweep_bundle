//*****************************************************************************
// test_main.c
// MCUXpresso IDE Flash driver - test code for Debug build of
//                              i.MX RT600 SFDP based drivers
//*****************************************************************************
//
// Copyright 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "bl_api.h"
#include "FlashConfig.h"
#include "lpcx_flash_driver.h"
#include <time.h>
#include <stdio.h>


/*******************************************************************************
* Definitions
******************************************************************************/

/*******************************************************************************
* Prototypes
******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/

extern uint32_t checkblank(uint32_t adr, uint32_t words, uint32_t blankval);

//FlashDriver Global data
unsigned char buf[16 * 1024]  __attribute__ ((aligned (4)));
extern Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;
char itoa_buf[32];


static uint8_t s_spififlash_program_buffer[0x400];
//static uint8_t s_spififlash_read_buffer[0x200];

int main(void)
{
    uint32_t i = 0;
    status_t status;
    uint32_t sector = 0;
    uint32_t page = 0;
    uint32_t n = 0;

	clock_t start;
	clock_t end;

    status = Init();
    if (status) {
    		printf("failed with status %x\n", status);
    		while (1);
    }


//    uint32_t FlashSize = flashConfig.memConfig.sflashA1Size
    uint32_t FlashSize = flashConfig.memConfig.sflashB1Size;

	printf("Device Size = %#10x (%u KB)\n",FlashSize, FlashSize /1024);
	printf("Sector Size = %#10x (%u KB)\n", flashConfig.sectorSize, flashConfig.sectorSize / 1024);
	printf(" Block Size = %#10x (%u KB)\n", flashConfig.blockSize, flashConfig.blockSize / 1024);
	printf("  Page Size = %#10x (%u bytes)\n", flashConfig.pageSize, flashConfig.pageSize);
	printf("Serial Clock = %d\n", flashConfig.memConfig.serialClkFreq);

	printf ("\n*** NOTE: Using blocks as sectors ***\n\n");

	for (sector = 0; sector < (FlashSize / flashConfig.blockSize); sector++) {

		printf("Sector Erase %d at address offset %x ", sector,
				sector * flashConfig.blockSize);

		status = EraseSectors (FLASH_BASE_ADDR+(sector * flashConfig.blockSize),1);

		if (status) {
			printf("failed \n");
		} else {
			printf("passed \n");
		}

		// check sector erase occurred
		status = checkblank(FLASH_BASE_ADDR + (sector * flashConfig.blockSize), flashConfig.blockSize >> 2,
					0xFFFFFFFF);
			if (status) {
				printf(" failed \n");
			} else {
				//printf(" passed \n");
			}

    	for (page = 0; page < (flashConfig.blockSize / flashConfig.pageSize); page++) {

			for (i = 0; i < sizeof(s_spififlash_program_buffer); i += 4) {

				n = (sector * flashConfig.blockSize) + (page * flashConfig.pageSize) + i;
				s_spififlash_program_buffer[i + 3] = n >> 24 & 0xFF;
				s_spififlash_program_buffer[i + 2] = n >> 16 & 0xFF;
				s_spififlash_program_buffer[i + 1] = n >> 8 & 0xFF;
				s_spififlash_program_buffer[i + 0] = (n) & 0xFF;

			}

			status = ProgramPage (FLASH_BASE_ADDR + (sector * flashConfig.blockSize) + (page * flashConfig.pageSize),
					flashConfig.pageSize,
					(void *) s_spififlash_program_buffer);

//	        if enabled, this code will take considerable time to execute
//        	printf("Page Program %d, Address %x ", page,sector * SECTOR_SIZE + (page* flashConfig.pageSize) );
			if (status) {
				printf("failed \n");
			} else {
				//printf("passed \n");
			}

			status = Verify(
					FLASH_BASE_ADDR + (page * flashConfig.pageSize)
							+ (sector * flashConfig.blockSize), flashConfig.pageSize,
					s_spififlash_program_buffer);
			if (status) {
				printf("failed page %x verify\n",
						FLASH_BASE_ADDR + (page * flashConfig.pageSize)
								+ (sector * flashConfig.blockSize));
			}
		}
	}

	printf("\nErasing Device ...");
	start = time(NULL);
	status = EraseChip();
	end = time(NULL);
	if (status) {
		printf(" failed \n");
	} else {
		printf(" passed \n");
	}
	printf("\nErased in %d seconds\n", end - start);

	printf("\nChecking erased values ...");
	status = checkblank(FLASH_BASE_ADDR, FlashSize >> 2,
			0xFFFFFFFF);
	if (status) {
		printf(" failed \n");

		for (i=FLASH_BASE_ADDR; i<FLASH_BASE_ADDR+FlashSize; i+=4) {
			if (*(uint32_t *) i != 0xFFFFFFFF) {
				printf ("failed at %x\n",i);
			}
		}

	} else {
		printf(" passed \n");
	}

	printf("\nFinished!! \n");
	/* Enter an infinite loop, just incrementing a counter. */

    while (1)
    {
    		i++;
    }
}
