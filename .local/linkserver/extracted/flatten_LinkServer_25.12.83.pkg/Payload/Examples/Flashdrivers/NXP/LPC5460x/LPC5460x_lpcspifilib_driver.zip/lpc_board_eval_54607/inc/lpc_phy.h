/*
 * @brief Common PHY functions
 *
 * @note
 * Copyright 2012, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __LPC_PHY_H_
#define __LPC_PHY_H_

#include "board.h"
#include "chip.h"

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup BOARD_PHY BOARD: Board specific PHY drivers
 * @ingroup BOARD_Common
 * The simple PHY function API provides simple non-blocking PHY status
 * monitoring and initialization support for various Ethernet PHYs.
 * To initialize the PHY, call lpc_phy_init() once. lpc_phy_init() requires
 * several standard functions from the MAC driver for interfacing to the
 * PHY via a MII link (Chip_ENET_StartMIIWrite(), Chip_ENET_IsMIIBusy(),
 * Chip_ENET_StartMIIRead(), and Chip_ENET_ReadMIIData()).
 *
 * Once initialized, just preiodically call the lpcPHYStsPoll() function
 * from the background loop or a thread and monitor the returned status
 * to determine if the PHY state has changed and the current PHY state.
 * @{
 */
#define PHY_LINK_ERROR     (1 << 0)	/*!< PHY status bit for link error */
#define PHY_LINK_BUSY      (1 << 1)	/*!< PHY status bit for MII link busy */
#define PHY_LINK_CHANGED   (1 << 2)	/*!< PHY status bit for changed state (not persistent) */
#define PHY_LINK_CONNECTED (1 << 3)	/*!< PHY status bit for connected state */
#define PHY_LINK_SPEED100  (1 << 4)	/*!< PHY status bit for 100Mbps mode */
#define PHY_LINK_FULLDUPLX (1 << 5)	/*!< PHY status bit for full duplex mode */

/**
 * @brief	Phy status update state machine
 * @return	An Or'ed value of PHY_LINK_* statuses
 * @note	This function can be called at any rate and will poll the the PHY status. Multiple
 * calls may be needed to determine PHY status.
 */
uint32_t lpcPHYStsPoll(void);

/**
 * @brief	Initialize the PHY
 * @param	rmii			: Initializes PHY for RMII mode if true, MII if false
 * @param	pDelayMsFunc	: Delay function (in mS) used for this driver
 * @return	PHY_LINK_ERROR or 0 on success
 * @note	This function initializes the PHY. It will block until complete. It will not
 * wait for the PHY to detect a connected cable and remain busy. Use lpcPHYStsPoll to
 * detect cable insertion.
 */
uint32_t lpc_phy_init(bool rmii, p_msDelay_func_t pDelayMsFunc);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __LPC_PHY_H_ */
