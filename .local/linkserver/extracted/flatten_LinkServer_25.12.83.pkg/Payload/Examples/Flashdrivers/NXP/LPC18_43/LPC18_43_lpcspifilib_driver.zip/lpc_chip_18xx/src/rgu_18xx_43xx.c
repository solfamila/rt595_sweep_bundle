/*
 * @brief LPC18xx/43xx Reset Generator Unit driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Trigger a peripheral reset for the selected peripheral */
void Chip_RGU_TriggerReset(CHIP_RGU_RST_T ResetNumber)
{
	volatile uint32_t *p;

	/* To trigger reset- write RESET_CTRLx with a 1 bit */
	p = (volatile uint32_t *) &(LPC_RGU->RESET_CTRL0);

	/* higher numbers are in RESET_CTRL1, RESET_CTRL2, etc. */
	p += ResetNumber / 32;

	/* On the LPC18xx and LPC43xx, most of the reset bits automatically clear
	   after 1 clock cycle, so set the bit and return */
	*p = (1 << (ResetNumber % 32));
}

/* Clears reset for the selected peripheral */
void Chip_RGU_ClearReset(CHIP_RGU_RST_T ResetNumber)
{
	volatile uint32_t *p;

	/* To trigger reset- write RESET_CTRLx with a 1 bit */
	p = (volatile uint32_t *) &(LPC_RGU->RESET_CTRL0);

	/* higher numbers are in RESET_CTRL1, RESET_CTRL2, etc. */
	p += ResetNumber / 32;

	/* On the LPC18xx and LPC43xx, most of the reset bits automatically clear
	   after 1 clock cycle, so set the bit and return */
	*p = 0;
}

/* Checks the reset status of a peripheral */
bool Chip_RGU_InReset(CHIP_RGU_RST_T ResetNumber)
{
	volatile uint32_t *read;

	read = (volatile uint32_t *) &(LPC_RGU->RESET_ACTIVE_STATUS0);
	read += ResetNumber / 32;

	/* Reset not asserted if bit is set */
	return (bool) ((*read & (1 << (ResetNumber % 32))) == 0);
}
