/*
 * @brief Packing macros
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __PACKING_H_
#define __PACKING_H_

#define PRE_PACK   /* Nothing */
#define POST_PACK  /* Nothing */
#define ALIGNED(n) /* Nothing */

#endif /* __PACKING_H_ */
