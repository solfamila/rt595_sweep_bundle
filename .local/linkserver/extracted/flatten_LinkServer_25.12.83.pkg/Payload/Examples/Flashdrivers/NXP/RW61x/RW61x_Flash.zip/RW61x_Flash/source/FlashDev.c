//*****************************************************************************
// FlashDev.c
// MCUXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2022-2023 NXP
//
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "lpcx_flash_driver.h"
#include "FlashConfig.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS,              // Driver Version, do not modify!
   "RW61X_FlexSPI_A_SFDP_QSPI Flash "__DATE__" "__TIME__,
   EXTSPI,                      // Device Type
   FLASH_BASE_ADDR,             // Device Start Address
   0,                           // Device Size ** Will be updated by call to Init() **
   0,                           // Programming Page Size ** Will be updated by call to Init() **
   0,                           // Reserved, must be 0
   0xFF,                        // Initial Content of Erased Memory
   1000,                        // Program Page Timeout
   3000,                        // Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{0x0, 0},                   // Sector sizes ** Will be updated by call to Init() **
   {SECTOR_END}}
};
