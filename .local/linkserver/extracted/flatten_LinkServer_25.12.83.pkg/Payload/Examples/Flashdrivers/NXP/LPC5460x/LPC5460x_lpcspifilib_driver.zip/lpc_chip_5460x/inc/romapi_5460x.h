/*
 * @brief LPC5460X ROM API declarations and functions
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __ROMAPI_5460X_H_
#define __ROMAPI_5460X_H_

#include <stdint.h>
#include "iap.h"
#include "error.h"
#include "cmsis.h"
#include "otp_rom_api.h"


#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup ROMAPI_5460X CHIP: LPC5460X ROM API declarations and functions
 * @ingroup CHIP_5460X_DRIVERS
 * @{
 */

/**
 * @brief High level ROM API structure
 */
typedef struct {
	const uint32_t usbdApiBase;				    /*!< USB API Base */
	const uint32_t reserved_clib;				/*!< Reserved */
	const uint32_t reserved_power;				/*!< Reserved */
	const uint32_t reserved_div;				/*!< Reserved */
	const uint32_t reserved_usart;				/*!< Reserved */
	const uint32_t reserved_i2cm;				/*!< Reserved */
	const uint32_t reserved_i2cs;				/*!< Reserved */
	const uint32_t reserved_i2cmon;				/*!< Reserved */
	const uint32_t reserved_spim;				/*!< Reserved */
	const uint32_t reserved_spis;				/*!< Reserved */
	const uint32_t reserved_dmaaltd;			/*!< Reserved */
	const uint32_t reserved_adcaltd;            /*!< Reserved */
	const uint32_t reserved_uartalt;            /*!< Reserved */
	const uint32_t reserved_flexcomm;           /*!< Reserved */
	const uint32_t otpApiBase;					/*!< OTP API Base */
	const uint32_t aesApiBase;					/*!< AES API Base */
	const uint32_t secureApiBase;				/*!< Secure API Base */
} LPC_ROM_API_T;

/* Pointer to ROM API function address */
#define LPC_ROM_API_BASE_LOC    0x03000200UL
#define LPC_ROM_API     (*(LPC_ROM_API_T * *) LPC_ROM_API_BASE_LOC)

/* Pointer to @ref PWRD_API_T functions in ROM */
//#define LPC_PWRD_API    ((LPC_ROM_API)->pPWRD)

/* Pointer to ROM IAP entry functions */
#define IAP_ENTRY_LOCATION        0x03000205

/**
 * @brief LPC5410x IAP_ENTRY API function type
 */
static INLINE void iap_entry(unsigned int cmd_param[5], unsigned int status_result[4])
{
	((IAP_ENTRY_T) IAP_ENTRY_LOCATION)(cmd_param, status_result);
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __ROMAPI_5460X_H_ */
