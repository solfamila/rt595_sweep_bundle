//*****************************************************************************
// FlashConfig.h
// MCUXpresso IDE Flash driver
// Config file for i.MX RT1160/RT1170/RT1180 FlexSPI SFDP based drivers
//*****************************************************************************
//
// Copyright 2018, 2020-2022, 2024-2025 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#ifndef FLASHCONFIG_H_
#define FLASHCONFIG_H_


#if defined (DEBUG)
#define MIMXRT1170_SFDP_QSPI
#endif

// HyperFlash does not support operation on blocks
// If modifying these sources to add support for a HyperFlash device
// un-comment and add the following line to the corresponding build target
// #define NO_BLOCKS


#if defined (MIMXRT1170_SFDP_QSPI) || defined (MIMXRT1170_FlexSPI2_A_SFDP_QSPI) || defined (MIMXRT1170_SFDP_MXIC_OPI) || defined (MIMXRT1170_SFDP_MICRON_OPI)
// ************************************
// Used to check silicon version - as ROM API base address is
// different between A0 and B0. Thus we need to check which
// base address to call into
// ************************************
#define INIT_VERSION_MAJOR do {versionMajor = (MEM_ReadU32(0x40C84800) & (0xF0U)) >> (4U); } while(0)
#else
#define INIT_VERSION_MAJOR do { } while(0)
#endif

#if defined (MIMXRT1170_SFDP_QSPI) || defined (MIMXRT1160_SFDP_QSPI)

// RT1170 User Manual - 10.13.2.1.12 - FlexSPI NOR flash config parameters (p338)

#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x30000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  0x08000000 // FlexSPI1 alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */
// 0xc0000007

//� QuadSPI NOR - Quad SDR Read: option0 = 0xc0000007 (133MHz)
//� QuadSPI NOR - Quad DDR Read: option0 = 0xc0100003 (60MHz)
//� HyperFLASH 1V8: option0 = 0xc0233008 (166MHz)
//� HyperFLASH 3V0: option0 = 0xc0333005 (100MHz)
//� MXIC OPI DDR (OPI DDR enabled by default): option=0xc0433007(133MHz)
//� Micron Octal DDR: option0=0xc0600005 (100MHz)
//� Micron OPI DDR: option0=0xc0603007 (133MHz), SPI->OPI DDR
//� Micron OPI DDR (DDR read enabled by default): option0 = 0xc0633007 (133MHz)
//� Adesto OPI DDR: option0=0xc0803007(133MHz)

#define CONFIG_OPTION0  0xC0000007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1170_FlexSPI2_A_SFDP_QSPI) || defined (MIMXRT1160_FlexSPI2_A_SFDP_QSPI)

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x60000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */
// 0xc0000007

//� QuadSPI NOR - Quad SDR Read: option0 = 0xc0000007 (133MHz)
//� QuadSPI NOR - Quad DDR Read: option0 = 0xc0100003 (60MHz)
//� HyperFLASH 1V8: option0 = 0xc0233008 (166MHz)
//� HyperFLASH 3V0: option0 = 0xc0333005 (100MHz)
//� MXIC OPI DDR (OPI DDR enabled by default): option=0xc0433007(133MHz)
//� Micron Octal DDR: option0=0xc0600005 (100MHz)
//� Micron OPI DDR: option0=0xc0603007 (133MHz), SPI->OPI DDR
//� Micron OPI DDR (DDR read enabled by default): option0 = 0xc0633007 (133MHz)
//� Adesto OPI DDR: option0=0xc0803007(133MHz)

#define CONFIG_OPTION0  0xC0000007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1170_SFDP_MXIC_OPI) || defined (MIMXRT1160_SFDP_MXIC_OPI)

#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x30000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  0x08000000 // FlexSPI1 alias

#define CONFIG_OPTION0  0xC0403007
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1170_SFDP_MICRON_OPI)

#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x30000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  0x08000000 // FlexSPI1 alias

#define CONFIG_OPTION0  0xC0603007
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x38000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */

#define CONFIG_OPTION0  0xC0000007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_QSPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x28000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC0000007
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 1
#define PORT_B 1
#define FLASH_BASE_ADDR      0x38000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias
/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */

#define CONFIG_OPTION0  0xC1000007

/*
 * 0x2  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_QSPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 1
#define PORT_B 1
#define FLASH_BASE_ADDR      0x28000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1000007
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x38000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 4   : device_type (4 = Macronix Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC0403007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x28000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC0403007
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x38000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 4   : device_type (6 = Micron Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC0603007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 1
#define FLASH_BASE_ADDR      0x28000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC0603007
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 1
#define PORT_B 1
#define FLASH_BASE_ADDR      0x38000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias


/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 4   : device_type (4 = Macronix Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC1403007

/*
 * 0x2  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 1
#define PORT_B 1
#define FLASH_BASE_ADDR      0x28000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1403007
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 1
#define PORT_B 1
#define FLASH_BASE_ADDR      0x38000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias


/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 4   : device_type (6 = Micron Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC1603007

/*
 * 0x2  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 1
#define PORT_B 1
#define FLASH_BASE_ADDR      0x28000000 // FlexSPI1
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1603007
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */

#define CONFIG_OPTION0  0xC0000007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC0000007
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */

#define CONFIG_OPTION0  0xC1000007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x1  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00010000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI)

// Same as above, just using the non-secure address 
#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1000007
#define CONFIG_OPTION1  0x00010000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define PORT_B 1
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias
/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */

#define CONFIG_OPTION0  0xC1000007

/*
 * 0x2  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define PORT_B 1
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1000007
#define CONFIG_OPTION1  0x20000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define PORT_B 1
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias
/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */

#define CONFIG_OPTION0  0xC1000007

/*
 * 0x2  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x1  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x20010000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define PORT_B 1
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1000007
#define CONFIG_OPTION1  0x20010000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 4   : device_type (4 = Macronix Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC0403007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC0403007
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias


/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 4   : device_type (4 = Macronix Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC1403007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00010000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1403007
#define CONFIG_OPTION1  0x00010000


#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 4   : device_type (6 = Micron Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC0603007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC0603007
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S)

// RT1180 User Manual - 11.10.2 - FlexSPI NOR flash config parameters

#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x14000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias


/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 4   : device_type (6 = Micron Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 7   : max_freq
 * The last field has a restriction that the FlexSPI clock source must be PLL480_PFD0.
 * Keep it as 0 and manually configure the FLEXSPI clock if another clock source is selected in user application.
 */


#define CONFIG_OPTION0  0xC1603007

/*
 * 0x0  : flash_connection (0 = Single Flash connected to Port A or 2 = Single Flash connected to Port B)
 * 0x00 : reserved
 * 0x0  : pin_group (0 = Primary pin group or 1 = Secondary pin group)
 * 0x00 : reserved
 * 0x00 : dummy_cycles (0 = use detected dummy cycles for read command)
 */
// Only used if option size set >0
#define CONFIG_OPTION1  0x00010000

#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI)

// Same as above, just using the non-secure address
#define FLEXSPI_NOR_INSTANCE 2
#define FLASH_BASE_ADDR      0x04000000 // FlexSPI2
#define FLASH_BASE_ADDR_CM4  FLASH_BASE_ADDR // no alias

#define CONFIG_OPTION0  0xC1603007
#define CONFIG_OPTION1  0x00010000

#else
#error "No driver defined"
#endif

// Only relevant for QSPI build targets
#if defined (MIMXRT1170_SFDP_QSPI) || defined (MIMXRT1160_SFDP_QSPI)
#define IS_FLEXSPI_ENABLED ((MEM_ReadU32(0x400cc000) & 0x2) == 0x0)
#elif defined (MIMXRT1170_FlexSPI2_A_SFDP_QSPI) || (MIMXRT1160_FlexSPI2_A_SFDP_QSPI)
#define IS_FLEXSPI_ENABLED ((MEM_ReadU32(0x400d0000) & 0x2) == 0x0)
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_QSPI) || defined (MIMXRT1180_SFDP_FlexSPI1_B_QSPI) || defined (MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S) || defined (MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S)
#define IS_FLEXSPI_ENABLED ((MEM_ReadU32(0x425e0000) & 0x2) == 0x0)
#else
#define IS_FLEXSPI_ENABLED (0)
#endif

#endif /* FLASHCONFIG_H_ */
