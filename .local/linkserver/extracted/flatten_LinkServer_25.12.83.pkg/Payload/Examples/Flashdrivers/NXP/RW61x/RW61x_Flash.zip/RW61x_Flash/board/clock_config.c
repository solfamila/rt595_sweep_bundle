/*
 * Copyright 2021-2022, 2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_power.h"
#include "fsl_clock.h"
#include "clock_config.h"
#include "board.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/

/*******************************************************************************
 * Variables
 ******************************************************************************/
const clock_avpll_config_t g_avpllConfig_BOARD_BootClockRUN = {
    .ch1Freq = kCLOCK_AvPllChFreq12p288m,
    .ch2Freq = kCLOCK_AvPllChFreq64m,
    .enableCali = true
};

/*FUNCTION**********************************************************************
 *
 * Function Name : BOARD_FlexspiClockSafeConfig
 * Description   : FLEXSPI clock source safe configuration weak function.
 *                 Called before clock source(Such as PLL, Main clock) configuration.
 * Note          : Users need override this function to change FLEXSPI clock source to stable source when executing
 *                 code on FLEXSPI memory(XIP). If XIP, the function should runs in RAM and move the FLEXSPI clock
 *source to an stable clock to avoid instruction/data fetch issue during clock updating.
 *END**************************************************************************/
__attribute__((weak)) void BOARD_FlexspiClockSafeConfig(void)
{
}

/*FUNCTION**********************************************************************
 *
 * Function Name : BOARD_SetFlexspiClock
 * Description   : This function should be overridden if executing code on FLEXSPI memory(XIP).
 *                 To Change FLEXSPI clock, should move to run from RAM and then configure FLEXSPI clock source.
 *                 After the clock is changed and stable,  move back to run on FLEXSPI.
 * Param base    : FLEXSPI peripheral base address.
 * Param src     : FLEXSPI clock source.
 * Param divider : FLEXSPI clock divider.
 *END**************************************************************************/
__attribute__((weak)) void BOARD_SetFlexspiClock(FLEXSPI_Type *base, uint32_t src, uint32_t divider)
{
    CLKCTL0->FLEXSPIFCLKSEL = CLKCTL0_FLEXSPIFCLKSEL_SEL(src);
    CLKCTL0->FLEXSPIFCLKDIV |= CLKCTL0_FLEXSPIFCLKDIV_RESET_MASK; /* Reset the divider counter */
    CLKCTL0->FLEXSPIFCLKDIV = CLKCTL0_FLEXSPIFCLKDIV_DIV(divider - 1);
    while ((CLKCTL0->FLEXSPIFCLKDIV) & CLKCTL0_FLEXSPIFCLKDIV_REQFLAG_MASK)
    {
    }
}

/*******************************************************************************
 ************************ BOARD_InitBootClocks function ************************
 ******************************************************************************/
void BOARD_InitBootClocks(void)
{
    BOARD_BootClockRUN();
}

/*******************************************************************************
 ********************** Configuration BOARD_BootClockRUN ***********************
 ******************************************************************************/
/*******************************************************************************
 * Variables for BOARD_BootClockRUN configuration
 ******************************************************************************/

/*******************************************************************************
 * Code for BOARD_BootClockRUN configuration
 ******************************************************************************/
void BOARD_BootClockRUN(void)
{
    if ((PMU->CAU_SLP_CTRL & PMU_CAU_SLP_CTRL_SOC_SLP_RDY_MASK) == 0U)
    {
        /* LPOSC not enabled, enable it */
        CLOCK_EnableClock(kCLOCK_RefClkCauSlp);
    }
    if ((SYSCTL2->SOURCE_CLK_GATE & SYSCTL2_SOURCE_CLK_GATE_REFCLK_SYS_CG_MASK) != 0U)
    {
        /* REFCLK_SYS not enabled, enable it */
        CLOCK_EnableClock(kCLOCK_RefClkSys);
    }

    if (BOARD_IS_XIP())
    {
        /* Call function BOARD_FlexspiClockSafeConfig() to move FlexSPI clock to a stable clock source to avoid
           instruction/data fetch issue when updating PLL and Main clock if XIP(execute code on FLEXSPI memory). */
        BOARD_FlexspiClockSafeConfig();
    }

    /* First let M33 run on SOSC */
    CLOCK_AttachClk(kSYSOSC_to_MAIN_CLK);
    CLOCK_SetClkDiv(kCLOCK_DivSysCpuAhbClk, 1);

    /* tcpu_mci_clk configured to 260MHz, tcpu_mci_flexspi_clk 312MHz. */
    CLOCK_InitTcpuRefClk(3120000000UL, kCLOCK_TcpuFlexspiDiv10);
    /* Enable tcpu_mci_clk 260MHz. Keep tcpu_mci_flexspi_clk gated. */
    CLOCK_EnableClock(kCLOCK_TcpuMciClk);

    /* tddr_mci_flexspi_clk 400MHz */
    CLOCK_InitTddrRefClk(kCLOCK_TddrFlexspiDiv8);
    CLOCK_EnableClock(kCLOCK_TddrMciFlexspiClk); /* 400MHz */

    /* Enable AUX0 PLL to 260MHz. */
    CLOCK_SetClkDiv(kCLOCK_DivAux0PllClk, 1U);

    /* Init AVPLL and enable both channels. */
    CLOCK_InitAvPll(&g_avpllConfig_BOARD_BootClockRUN);
    CLOCK_SetClkDiv(kCLOCK_DivAudioPllClk, 1U);

    /* Configure MainPll to 260MHz, then let CM33 run on Main PLL. */
    CLOCK_SetClkDiv(kCLOCK_DivSysCpuAhbClk, 1U);
    CLOCK_SetClkDiv(kCLOCK_DivMainPllClk, 1U);
    CLOCK_AttachClk(kMAIN_PLL_to_MAIN_CLK);

    /* Set SYSTICKFCLKDIV divider to value 1 */
    CLOCK_SetClkDiv(kCLOCK_DivSystickClk, 1U);
    CLOCK_AttachClk(kSYSTICK_DIV_to_SYSTICK_CLK);

    if (BOARD_IS_XIP())
    {
        /* Call function BOARD_SetFlexspiClock() to set clock source to tddr_mci_flexspi_clk. */
        BOARD_SetFlexspiClock(FLEXSPI, 5U, 3U);
    }

    /* Set PLL FRG clock to 20MHz. */
    CLOCK_SetClkDiv(kCLOCK_DivPllFrgClk, 13U);

    /* Measure main_clk on CLKOUT. Set CLKOUTFCLKDIV divider to value 100 */
    CLOCK_AttachClk(kMAIN_CLK_to_CLKOUT);
    SOCCTRL->TST_TSTBUS_CTRL2 = (SOCCTRL->TST_TSTBUS_CTRL2 &
	    ~(SOCCIU_TST_TSTBUS_CTRL2_CLK_OUT_PAGE_SEL_MASK | SOCCIU_TST_TSTBUS_CTRL2_CLK_OUT_SEL_MASK)) |
            SOCCIU_TST_TSTBUS_CTRL2_CLK_OUT_PAGE_SEL(3) | SOCCIU_TST_TSTBUS_CTRL2_CLK_OUT_SEL(14);
    CLOCK_SetClkDiv(kCLOCK_DivClockOut, 100U);

    /* Set SystemCoreClock variable. */
    SystemCoreClock = BOARD_BOOTCLOCKRUN_CORE_CLOCK;
}
