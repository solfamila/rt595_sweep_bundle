/*
 * @brief LPC18xx/43xx Reset Generator Unit driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __RGU_18XX_43XX_H_
#define __RGU_18XX_43XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup RGU_18XX_43XX CHIP: LPC18xx/43xx Reset Generator Unit (RGU) driver
 * @ingroup CHIP_18XX_43XX_Drivers
 * @{
 */

/**
 * @brief RGU reset enumerations
 */
typedef enum CHIP_RGU_RST {
	RGU_CORE_RST,
	RGU_PERIPH_RST,
	RGU_MASTER_RST,
	RGU_WWDT_RST = 4,
	RGU_CREG_RST,
	RGU_BUS_RST = 8,
	RGU_SCU_RST,
	RGU_M0SUB_RST = 12,
	RGU_M3_RST,
	RGU_LCD_RST = 16,
	RGU_USB0_RST,
	RGU_USB1_RST,
	RGU_DMA_RST,
	RGU_SDIO_RST,
	RGU_EMC_RST,
	RGU_ETHERNET_RST,
	RGU_FLASHA_RST = 25,
	RGU_EEPROM_RST = 27,
	RGU_GPIO_RST,
	RGU_FLASHB_RST,
	RGU_TIMER0_RST = 32,
	RGU_TIMER1_RST,
	RGU_TIMER2_RST,
	RGU_TIMER3_RST,
	RGU_RITIMER_RST,
	RGU_SCT_RST,
	RGU_MOTOCONPWM_RST,
	RGU_QEI_RST,
	RGU_ADC0_RST,
	RGU_ADC1_RST,
	RGU_DAC_RST,
	RGU_UART0_RST = 44,
	RGU_UART1_RST,
	RGU_UART2_RST,
	RGU_UART3_RST,
	RGU_I2C0_RST,
	RGU_I2C1_RST,
	RGU_SSP0_RST,
	RGU_SSP1_RST,
	RGU_I2S_RST,
	RGU_SPIFI_RST,
	RGU_CAN1_RST,
	RGU_CAN0_RST,
#ifdef CHIP_LPC43XX
	RGU_M0APP_RST,
	RGU_SGPIO_RST,
	RGU_SPI_RST,
	RGU_ADCHS_RST = 60,
#endif
	RGU_LAST_RST = 63,
} CHIP_RGU_RST_T;

/**
 * @brief RGU register structure
 */
typedef struct {							/*!< RGU Structure          */
	__I  uint32_t  RESERVED0[64];
	__O  uint32_t  RESET_CTRL0;				/*!< Reset control register 0 */
	__O  uint32_t  RESET_CTRL1;				/*!< Reset control register 1 */
	__I  uint32_t  RESERVED1[2];
	__IO uint32_t  RESET_STATUS0;			/*!< Reset status register 0 */
	__IO uint32_t  RESET_STATUS1;			/*!< Reset status register 1 */
	__IO uint32_t  RESET_STATUS2;			/*!< Reset status register 2 */
	__IO uint32_t  RESET_STATUS3;			/*!< Reset status register 3 */
	__I  uint32_t  RESERVED2[12];
	__I  uint32_t  RESET_ACTIVE_STATUS0;	/*!< Reset active status register 0 */
	__I  uint32_t  RESET_ACTIVE_STATUS1;	/*!< Reset active status register 1 */
	__I  uint32_t  RESERVED3[170];
	__IO uint32_t  RESET_EXT_STAT[RGU_LAST_RST + 1];/*!< Reset external status registers */
} LPC_RGU_T;

/**
 * @brief	Trigger a peripheral reset for the selected peripheral
 * @param	ResetNumber	: Peripheral reset number to trigger
 * @return	Nothing
 */
void Chip_RGU_TriggerReset(CHIP_RGU_RST_T ResetNumber);

/**
 * @brief	Checks the reset status of a peripheral
 * @param	ResetNumber	: Peripheral reset number to trigger
 * @return	true if the periperal is still being reset
 */
bool Chip_RGU_InReset(CHIP_RGU_RST_T ResetNumber);

/**
 * @brief	Clears reset for the selected peripheral
 * @param	ResetNumber	: Peripheral reset number to trigger
 * @return	Nothing
 * Almost all peripherals will auto clear the reset bit. Only a few peripherals
 * like the Cortex M0 Core in LPC43xx will not auto clear the reset and require
 * this function to clear the reset bit.
 */
void Chip_RGU_ClearReset(CHIP_RGU_RST_T ResetNumber);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __RGU_18XX_43XX_H_ */
