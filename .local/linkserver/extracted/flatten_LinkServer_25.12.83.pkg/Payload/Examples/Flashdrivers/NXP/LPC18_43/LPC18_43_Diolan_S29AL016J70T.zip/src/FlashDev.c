// Copyright 2013 Code Red Technologies Limited
// Copyright 2019 NXP
/***********************************************************************
 *                                                                     *
 *  FlashDev.C: Device Description for the S29AL016J70T flash driver   *
 *              for use with Diolan LPC1850 / LPC4350 DB1 boards       *
 *                                                                     *
 ***********************************************************************/

#include "crt_flash_if.h"

struct FlashDevice const FlashDevice  =  {
   FLASH_DRV_VERS,             // Driver Version, do not modify!
   "LPC18/43 S29AL016JT Diolan 2MB @0x1C000000 ("__DATE__" "__TIME__")",
   EXT16BIT,                   // Device Type
   0x1C000000,                  // Device Start Address
   0x200000,                   // Device Size in Bytes (2MB)
   8*1024,                       // Programming Page Size
   0,                          // Reserved, must be 0
   0xFF,                       // Initial Content of Erased Memory
   1000,                        // Program Page Timeout
   5000,                        // Erase Sector Timeout
// Specify Size and Address of Sectors
   {{0x10000,     0x000000},      // Sector Size 64kB (31 Sectors)
   {0x08000,     0x1F0000},      // Sector Size 32kB (1 Sector)
   {0x02000,     0x1F8000},      // Sector Size  8kB (2 Sectors)
   {0x04000,     0x1FC000},      // Sector Size 16kB (1 Sector)
   {SECTOR_END}}
};







