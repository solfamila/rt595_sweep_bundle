//*****************************************************************************
// FlashPrg.c
//
// MCUXpresso IDE flash driver - Flash Programming Functions
//
// MCXN9xx FlexSPI SFDP based drivers
//
//*****************************************************************************
//
// Copyright 2022-2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include <stdint.h>
#include <string.h> // For memcmp used in Verify()

#include "pin_mux.h"
#include "fsl_flexspi_nor_flash.h"
#include "fsl_common.h"
#include "fsl_cache.h"
#include "clock_config.h"

#include "lpcx_flash_driver.h"
#include "FlashConfig.h"


Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;

uint32_t SystemCoreClock;

flexspi_nor_config_t flashConfig;
serial_nor_config_option_t configOption;

// ************************************
// Flash driver functions
// ************************************

/*
 *  Disable GDET for MCXN5xx/MCXN9xx parts to avoid flash initialization issues
 */
static void Disable_GDET(void)
{
    // SYSCON->DEVICE_TYPE is at 0x40000ff4
    // SYSCON->DEVICE_TYPE[15:0] is DEVICE_TYPE_NUM
    // DEVICE_TYPE_NUM info from "SYSTEM SOC v1.5.xml"
    // [15:12]:
    //  0001b: Nxxx
    //  0010b: Axxx
    //  0011b: Lxxx
    //  ...
    // [11:0]: 3 digital of the part number.
    // For example:
    //   N346: 0x1346
#if 1
    // Use CMSIS Peripheral Access Layer
    // skip non-N5xx/N9xx
    if (((SYSCON->DEVICE_TYPE & 0xff00) != 0x1500) &&
        ((SYSCON->DEVICE_TYPE & 0xff00) != 0x1900))
        return;

    /* Disable aGDET trigger the CHIP_RESET */
    ITRC0->OUT_SEL[4][0] = (ITRC0->OUT_SEL[4][0] & ~ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn(0x2));
    ITRC0->OUT_SEL[4][1] = (ITRC0->OUT_SEL[4][1] & ~ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn(0x2));
    /* Disable aGDET interrupt and reset */
    SPC0->ACTIVE_CFG |= SPC_ACTIVE_CFG_GLITCH_DETECT_DISABLE_MASK;
    SPC0->GLITCH_DETECT_SC &= ~SPC_GLITCH_DETECT_SC_LOCK_MASK;
    SPC0->GLITCH_DETECT_SC = 0x3C;
    SPC0->GLITCH_DETECT_SC |= SPC_GLITCH_DETECT_SC_LOCK_MASK;

    /* Disable dGDET trigger the CHIP_RESET */
    ITRC0->OUT_SEL[4][0] = (ITRC0->OUT_SEL[4][0] & ~ ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn(0x2));
    ITRC0->OUT_SEL[4][1] = (ITRC0->OUT_SEL[4][1] & ~ ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn(0x2));
    GDET0->GDET_ENABLE1 = 0;
    GDET1->GDET_ENABLE1 = 0;
#else
    // Use direct memory access to peripherals
    // skip non-N5xx/N9xx
    //if (((SYSCON->DEVICE_TYPE & 0xff00) != 0x1500) &&
    //    ((SYSCON->DEVICE_TYPE & 0xff00) != 0x1900))
    if ((((*(uint32_t *)0x40000ff4) & 0xff00) != 0x1500) &&
        (((*(uint32_t *)0x40000ff4) & 0xff00) != 0x1900))
        return;

    /* Disable aGDET trigger the CHIP_RESET */
    //ITRC0->OUT_SEL[4][0] = (ITRC0->OUT_SEL[4][0] & ~ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn(0x2));
    *(uint32_t *)0x40026028 = (*(uint32_t *)0x40026028 & ~0xc0000) | 0x80000;
    //ITRC0->OUT_SEL[4][1] = (ITRC0->OUT_SEL[4][1] & ~ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN9_SELn(0x2));
    *(uint32_t *)0x4002602c = (*(uint32_t *)0x4002602c & ~0xc0000) | 0x80000;

    /* Disable aGDET interrupt and reset */
    //SPC0->ACTIVE_CFG |= SPC_ACTIVE_CFG_GLITCH_DETECT_DISABLE_MASK;
    *(uint32_t *)0x40045100 |= 0x1000;
    //SPC0->GLITCH_DETECT_SC &= ~SPC_GLITCH_DETECT_SC_LOCK_MASK;
    *(uint32_t *)0x40045144 &= ~0x10000;
    //SPC0->GLITCH_DETECT_SC = 0x3C;
    *(uint32_t *)0x40045144 = 0x3C;
    //SPC0->GLITCH_DETECT_SC |= SPC_GLITCH_DETECT_SC_LOCK_MASK;
    *(uint32_t *)0x40045144 |= 0x10000;

    /* Disable dGDET trigger the CHIP_RESET */
    //ITRC0->OUT_SEL[4][0] = (ITRC0->OUT_SEL[4][0] & ~ ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn(0x2));
    *(uint32_t *)0x40026028 = (*(uint32_t *)0x40026028 & ~0x3) | 0x2;
    //ITRC0->OUT_SEL[4][1] = (ITRC0->OUT_SEL[4][1] & ~ ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn_MASK) | (ITRC_OUTX_SEL_OUTX_SELY_OUT_SEL_IN0_SELn(0x2));
    *(uint32_t *)0x4002602c = (*(uint32_t *)0x4002602c & ~0x3) | 0x2;
    // GDET0->GDET_ENABLE1 = 0;
    *(uint32_t *)0x40024008 = 0;
    //GDET1->GDET_ENABLE1 = 0;
    *(uint32_t *)0x40025008 = 0;
#endif
}

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  !=0 - Failed
 */
uint32_t Init (void)
{
    status_t status;

    Disable_GDET();

    // ****************
    BOARD_InitPins();
    BOARD_BootClockPLL150M();

    /* Note: SDK team found that ROM FLash API works with
       - FRO_HF as FLEXSPI clock source for EVK boards (N9xx/N5xx)
       - PLL0 as FLEXSPI clock source for BRK board
         //FlexSPI frequency 150MHz / 2 = 75MHz
         //CLOCK_SetClkDiv(kCLOCK_DivFlexspiClk, 2U);
         //CLOCK_AttachClk(kPLL0_to_FLEXSPI);
       SDK will ask ROM team to see why the clock source
       has impact to ROM Flash API */

    /* FlexSPI frequency 48MHz */
    CLOCK_SetClkDiv(kCLOCK_DivFlexspiClk, 1U);
    CLOCK_AttachClk(kFRO_HF_to_FLEXSPI); /*!< Switch FLEXSPI to FRO_HF */

    // ****************
    // Disable cache
    if (CACHE64_CTRL0->CCR & CACHE64_CTRL_CCR_ENCACHE_MASK)
        CACHE64_DisableCache(CACHE64_CTRL0);

    // ****************
    configOption.option0.U = CONFIG_OPTION0;
    configOption.option1.U = CONFIG_OPTION1;
    memset((void *)&flashConfig, 0U, sizeof(flexspi_nor_config_t));

    status = FLEXSPI_NorFlash_GetConfig(0, &flashConfig, &configOption);
    if (status) {
        return (status);
    }

    status = FLEXSPI_NorFlash_Init(0, &flashConfig);
    if (status) {
        return (status);
    }

    // **********************************
    // Now updated the FlashDevice table using the settings for the
    // detected SPIFI device. These new values will be read back by
    // the debugger upon return from Init()
    // **********************************

    // Update FlashDevice device size
    FlashDevice.szDev = flashConfig.memConfig.sflashA1Size;

    // Update FlashDevice sector size - currently hard wired
    // Note: SPIFI devices are assumed to only support a single size
    //FlashDevice.sectors[0].szSector = config.sectorSize;
    FlashDevice.sectors[0].szSector = flashConfig.blockSize;

    // Update FlashDevice page size
    // Note that this is not the true page size from the detected SPIFI device, but
    // is actually the size of a single buffer of data that the debugger will send
    // down to the flash driver. This will normally be 16KB (limited by the available
    // RAM on the device) but cannot be larger than a single sector.

    if (FlashDevice.sectors[0].szSector < 16 * 1024)
        FlashDevice.szPage = FlashDevice.sectors[0].szSector;
    else
        FlashDevice.szPage = 16 * 1024; // use 16KB pseudo pages for now

    // Now use the flash driver mailbox to transfer info on the
    // updated device back to the host debugger.

#ifdef NDEBUG
    // Address of flash driver mailbox created by linker script
    // Note that this is skipped for debug builds of the driver
    extern unsigned int _b_mailbox;
    unsigned int *MAILBOX_PTR = &_b_mailbox;
    // Use mailbox 'status' word to pass address of message block
    *(MAILBOX_PTR+4) = (uint32_t)&Mailbox_Init_DynInfo;
#endif
    // Address of FlashDevice structure within driver
    Mailbox_Init_DynInfo.dyn_dev = &FlashDevice;

    // Pointer to string containing name of identified device

    // Ideally this should be the JEDEC ID, but no obvious way to get this
    Mailbox_Init_DynInfo.devname = "JEDEC_FlexSPI_Device";

    // Unused - partID information
    Mailbox_Init_DynInfo.partid_bytes = 0;
    Mailbox_Init_DynInfo.partid = 0;

    // **********************************
    return 0; // Finished without Errors
}

uint32_t UnInit(void)
{
    return 0; // Finished without Errors
}


#if !defined(DONT_PROVIDE_ERASECHIP)
/*  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseChip(void)
{
    status_t status = 0;
    status = FLEXSPI_NorFlash_EraseAll(0, &flashConfig);
    return (status);
}

#endif


uint32_t EraseSectors(uint32_t adr, uint32_t numsecs)
{
    status_t status = 0;

    // compute base address
    if (adr >= FLASH_BASE_ADDR)
        adr -= FLASH_BASE_ADDR;

#if defined (ERASE_IN_ONE)
    // Make single call to erase all of the required sectors (blocks).
    // Simpler, but actually appears to be slower than erasing by block
    status =  FLEXSPI_NorFlash_Erase(0, &flashConfig,
                    adr, (numsecs * flashConfig.blockSize));
#else
    while (numsecs) {
        status = FLEXSPI_NorFlash_EraseBlock(0, &flashConfig, adr);
        if (status) {
            break;
        }
        numsecs--;
        adr += flashConfig.blockSize;
    }
#endif

    return status;
}


/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf)
{
    status_t status = 0;
    uint32_t page = 0;

    // compute base address
    if (adr >=  FLASH_BASE_ADDR)
        adr -= FLASH_BASE_ADDR;

    while (sz) {
        status =  FLEXSPI_NorFlash_ProgramPage(0, &flashConfig,
                    adr, (void *)(buf + (page * flashConfig.pageSize)));
        if (status) {
            return (status);
        }

        sz = sz - flashConfig.pageSize;   // Decrease remaining size by page
        adr = adr + flashConfig.pageSize; // Update adr base by page
        page ++;                          // Next page
    }

    return (status);
}


#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t adr, uint32_t sz, uint8_t *buf)
{
    uint32_t status = 0;

#if defined (USE_SECURE_FLASHADDR)
    // Mask out bit 28 when calling ROM flash routines for programming in
    // secure flash address range
    adr &= ~(1UL << 28);
#endif

    status = memcmp((void *) adr, buf, sz);

    return (status);
}
#if defined (USE_SMALL_MEMCMP)
int memcmp(const void *a, const void *b, size_t n)
{
    const unsigned char *ac = (const unsigned char *)a,
    *bc = (const unsigned char *)b;
    while (n-- > 0) {
        unsigned char c1,c2; /* unsigned cmp seems more intuitive */
        if ((c1 = *ac++) != (c2 = *bc++)) return c1 - c2;
    }
    return 0;
}
#endif // USE_SMALL_MEMCMP
#endif // DONT_PROVIDE_VERIFY
