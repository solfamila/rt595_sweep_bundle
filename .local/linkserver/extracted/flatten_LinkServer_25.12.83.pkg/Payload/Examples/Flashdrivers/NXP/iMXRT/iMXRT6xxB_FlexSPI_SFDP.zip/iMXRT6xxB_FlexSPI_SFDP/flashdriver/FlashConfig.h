//*****************************************************************************
// FlashConfig.h
// MCUXpresso IDE Flash driver
// Config file for i.MX RT600 (rev B0) FlexSPI SFDP based drivers
//*****************************************************************************
//
// Copyright 2020-2021, 2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#ifndef FLASHCONFIG_H_
#define FLASHCONFIG_H_

#include "bl_api.h"

extern flexspi_nor_config_t flashConfig;

#if defined (DEBUG)
#define MIMXRT600_FlexSPI_B_MXIC_OPI
#endif


// RT6xx User Manual - 41.5.1.5.2 - FlexSPI NOR flash config parameters

#if defined (MIMXRT600_FlexSPI_B_MXIC_OPI) || defined (MIMXRT600_FlexSPI_B_MXIC_OPI_S)
/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 5   : device_type (5 = Macronix Octal SDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 3   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 5   : misc_mode (5 = select FlexSPI data sample source as internal loop back)
 * 1   : max_freq
 */
// 0xc1503051 - but changed to single bit mode, not octal
#define CONFIG_OPTION0  0xC1500051

/*
 * 0x2 : flash_connection (2 = Single Flash connected to Port B)
 *  ~
 * 14  : Dummy cycles for read command
 */
#define CONFIG_OPTION1  0x20000014

#define FLEXSPI_PORTB

#elif (MIMXRT600_FlexSPI_A_MXIC_OPI) || defined (MIMXRT600_FlexSPI_A_MXIC_OPI_S)

/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 5   : device_type (5 = Macronix Octal SDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 3   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 5   : misc_mode (5 = select FlexSPI data sample source as internal loop back)
 * 1   : max_freq
 */
// 0xc0503001 - but changed to single bit mode, not octal
#define CONFIG_OPTION0  0xC0500001

/*
 * 0x0 : Single Flash connected to Port A
 */
#define CONFIG_OPTION1  0x00000000

#elif defined (MIMXRT600_FlexSPI_B_SFDP_QSPI) || defined (MIMXRT600_FlexSPI_B_SFDP_QSPI_S)
/*
 * 0xC : tag
 * 1   : option_size (1 = option1 is specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 5   : misc_mode (5 = select FlexSPI data sample source as internal loop back)
 * 1   : max_freq
 */
#define CONFIG_OPTION0  0xC1000051

/*
 * 0x2 : Single Flash connected to Port B
 *  ~
 * 0x6 : Dummy cycles for read command
 */
#define CONFIG_OPTION1  0x20000006

#define FLEXSPI_PORTB

#elif defined (MIMXRT600_FlexSPI_A_SFDP_QSPI) || defined (MIMXRT600_FlexSPI_A_SFDP_QSPI_S)
/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode (0 = not enabled)
 * 1   : max_freq
 */
#define CONFIG_OPTION0  0xC0000001

/*
 *  0x0 : Single Flash connected to Port A
 */
#define CONFIG_OPTION1  0x00000000

#endif

// =====================================
// Flash Base Address Information
// =====================================

#define TRUE_FLASH_BASE_ADDR 0x08000000

#if defined (MIMXRT600_FlexSPI_A_MXIC_OPI_S) || defined (MIMXRT600_FlexSPI_B_MXIC_OPI_S) || \
	defined (MIMXRT600_FlexSPI_A_SFDP_QSPI_S) || defined (MIMXRT600_FlexSPI_B_SFDP_QSPI_S)
#define USE_SECURE_FLASHADDR
#define FLASH_BASE_ADDR 0x18000000
#else
#define FLASH_BASE_ADDR 0x08000000
#endif


#endif /* FLASHCONFIG_H_ */
