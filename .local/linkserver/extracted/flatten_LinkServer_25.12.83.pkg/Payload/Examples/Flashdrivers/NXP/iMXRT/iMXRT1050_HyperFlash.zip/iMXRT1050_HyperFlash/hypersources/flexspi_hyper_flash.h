// Copyright 2018-2019 NXP
/*
 * flexspi_hyperflash.h
 *
 * This file defines the page sizes and other configuration options used
 * in the flash driver system.
 *
 *
 */
#include "fsl_flexspi.h"
//#include "fsl_debug_console.h"

#include "pin_mux.h"
#include "board.h"
#include "clock_config.h"
#include "fsl_common.h"

#define EXAMPLE_FLEXSPI FLEXSPI
#define FLASH_SIZE 0x10000
#define EXAMPLE_FLEXSPI_AMBA_BASE FlexSPI_AMBA_BASE
#define FLASH_PAGE_SIZE 512
#define EXAMPLE_SECTOR 1
#define EXAMPLE_FLEXSPI_CLOCK kCLOCK_FlexSpi

// Additional defines for flash driver
#define SECTOR_SIZE 0x40000
#define PSEUDO_PAGE_SIZE (16 * 1024)
#define DEVICE_SIZE 0x04000000
#define SECTOR_NUMBER DEVICE_SIZE/SECTOR_SIZE		// 512Mb = 64MB

#define HYPERFLASH_CMD_LUT_SEQ_IDX_READDATA 0
#define HYPERFLASH_CMD_LUT_SEQ_IDX_WRITEDATA 1
#define HYPERFLASH_CMD_LUT_SEQ_IDX_READSTATUS 2
#define HYPERFLASH_CMD_LUT_SEQ_IDX_WRITEENABLE 4
#define HYPERFLASH_CMD_LUT_SEQ_IDX_ERASESECTOR 6
#define HYPERFLASH_CMD_LUT_SEQ_IDX_PAGEPROGRAM 10
#define CUSTOM_LUT_LENGTH 48

/*******************************************************************************
* Prototypes
*****************************************************************************/
status_t flexspi_nor_hyperbus_read(FLEXSPI_Type *base, uint32_t addr, uint32_t *buffer, uint32_t bytes);
status_t flexspi_nor_hyperbus_write(FLEXSPI_Type *base, uint32_t addr, uint32_t *buffer, uint32_t bytes);
status_t flexspi_nor_write_enable(FLEXSPI_Type *base, uint32_t baseAddr);
status_t flexspi_nor_wait_bus_busy(FLEXSPI_Type *base);
status_t flexspi_nor_flash_erase_sector(FLEXSPI_Type *base, uint32_t address);
status_t flexspi_nor_flash_page_program(FLEXSPI_Type *base, uint32_t address, const uint32_t *src);
status_t flexspi_nor_hyperflash_cfi(FLEXSPI_Type *base);
status_t hyper_init(void);
