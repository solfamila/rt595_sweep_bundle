/*
 * Copyright 2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef XSPI_OCTAL_FLASH_OPS_H_
#define XSPI_OCTAL_FLASH_OPS_H_

status_t xspi_nor_flash_erase_sector(XSPI_Type *base, uint32_t address);
status_t xspi_nor_flash_program(XSPI_Type *base, uint32_t dstAddr, const uint32_t *src, uint32_t length);
status_t xspi_nor_get_vendor_id(XSPI_Type *base, uint8_t *vendorId);
status_t xspi_nor_get_sfdp(XSPI_Type *base, uint32_t *sfdp);
status_t xspi_nor_erase_chip(XSPI_Type *base);
void xspi_nor_flash_init(XSPI_Type *base);
status_t xspi_nor_enable_octal_mode(XSPI_Type *base);
status_t xspi_nor_flash_read(XSPI_Type *base, uint32_t dstAddr, const uint32_t *src, uint32_t length);

#endif /* XSPI_OCTAL_FLASH_OPS_H_ */
