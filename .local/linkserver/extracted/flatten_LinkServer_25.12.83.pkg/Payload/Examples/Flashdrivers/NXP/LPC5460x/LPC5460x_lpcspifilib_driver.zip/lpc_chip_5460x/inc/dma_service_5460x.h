/*
 * @brief LPC5460X DMA service driver declarations and functions
 *
 * @note
 * Copyright 2015-2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __DMA_SERVICE_5460X_H
#define __DMA_SERVICE_5460X_H

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup DMA_SERVICE_5460X CHIP: LPC5460X DMA Service driver
 * @ingroup CHIP_5460X_DRIVERS
 * @{
 */

typedef void (* dma_callback_t)(int32_t);

typedef struct {
	uint32_t channel;
	volatile uint32_t *register_location;
	uint32_t width;
	uint32_t src_increment;
	uint32_t dst_increment;
	bool     write;
} dma_peripheral_context_t;

typedef struct {
   DMA_CHDESC_T  descr[2];
} dma_dual_descriptor_t;  // Note this type must be 16 byte aligned for it to work correctly!

/**
 * @brief	Initialize DMA service
 * @param	base	: The base address where the DMA descriptors will be stored
 * @return	Nothing
 */
void Chip_DMASERVICE_Init(DMA_CHDESC_T * base);

/**
 * @brief	DMA service interrupt handler
 * @param	None
 * @return	Nothing
 * @Note    Must be called from DMA_IRQHandler
 */
void Chip_DMASERVICE_Isr(void);

/**
 * @brief	Register callback function
 * @param	pContext Pointer to peripheral channel context
 * @param	pCallback Pointer to callback function
 * @return	Nothing
 */
void Chip_DMASERVICE_RegisterCb(const dma_peripheral_context_t * pContext,dma_callback_t pCallback);

/**
 * @brief	Use Single buffer mechanism
 * @param	pContext Pointer to peripheral channel context
 * @param	pMem Pointer to data memory
 * @param	length Data memory length
 * @return	Nothing
 */
void Chip_DMASERVICE_SingleBuffer(const dma_peripheral_context_t * pContext, uint32_t  pMem, uint32_t length);

/**
 * @brief	Use double buffer mechanism
 * @param	pContext Pointer to peripheral channel context
 * @param	pMem Pointer to data memory
 * @param	length Data memory length
 * @param   pD Pointer to dma dual descriptor
 * @return	Nothing
 */
void Chip_DMASERVICE_DoubleBuffer(const dma_peripheral_context_t * pContext, uint32_t  pMem, uint32_t length,dma_dual_descriptor_t * pD);

#ifdef __cplusplus
}
#endif

#endif /* __DMA_SERVICE_5460X_H */
