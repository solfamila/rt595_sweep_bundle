//*****************************************************************************
// FlashConfig.h
// MCUXpresso IDE Flash driver - config file for i.MX RT SFDP based drivers
//*****************************************************************************
//
// Copyright 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#ifndef FLASHCONFIG_H_
#define FLASHCONFIG_H_

#include "fsl_common.h"

// EcoXiP size definitions
#define FLASH_PAGE_SIZE  (0x100)
#define FLASH_SECTOR_SIZE (0x1000) //4096, spelling changed by NXP for MCUXpresso IDE flash driver
#define FLASH_SIZE (0x00400000U) //4MB

#define PSEUDO_PAGE_SIZE (4 * 1024) // LinkServer programming acceleration, must be <= FLASH_SECTOR_SIZE

status_t flash_init(void);

#endif /* FLASHCONFIG_H_ */
