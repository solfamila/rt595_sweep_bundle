/*
 * @brief LPC5460x Ethernet driver
 *
 * @note
 * Copyright 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/* Saved address for PHY and clock divider */
STATIC uint32_t phyCfg;

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

STATIC INLINE void reset(LPC_ENET_T *pENET)
{
	Chip_SYSCON_PeriphReset(RESET_ETHERNET);
	/* Reset ethernet peripheral */
	Chip_ENET_Reset(pENET);
}

STATIC uint32_t Chip_ENET_CalcMDCClock(void)
{
	uint32_t val = SystemCoreClock / 1000000UL;

	if (val >= 20 && val < 35)
		return 2;
	if (val >= 35 && val < 60)
		return 3;
	if (val >= 60 && val < 100)
		return 0;
	if (val >= 100 && val < 150)
		return 1;
	if (val >= 150 && val < 250)
		return 4;
	if (val >= 250 && val < 300)
		return 5;

	/* Code should never reach here
	   unless there is BUG in frequency settings
	*/
	return 0;
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Basic Ethernet interface initialization */
void Chip_ENET_Init(LPC_ENET_T *pENET, uint32_t phyAddr)
{
	uint16_t i;
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_ETHERNET);

	reset(pENET);

	/* Setup MII link divider to /102 and PHY address 1 */
	Chip_ENET_SetupMII(pENET, Chip_ENET_CalcMDCClock(), phyAddr);

	/* Enhanced descriptors, burst length = 1 */
	for( i = 0; i < 2; i++) {
		pENET->DMA_CHANNEL[i].DMA_CHx_TX_CTRL = DMA_TXCTL_PBL(1);
		pENET->DMA_CHANNEL[i].DMA_CHx_RX_CTRL = DMA_RXCTL_PBL(1);
		if(i < 1) {
			pENET->MTL_QUEUEx[i].MTL_TXQx_OP_MODE = MTL_TXQx_MODE_TQS(2048/256 - 1) | MTL_TXQx_MODE_TTC(1) | MTL_TXQx_MODE_QEN(MTL_QUEUE_ENABLE) | MTL_TXQx_MODE_TSF | MTL_TXQx_MODE_FTQ;
		}
		else {
			/* Fix for bug in hardware */
			pENET->MTL_QUEUEx[i].MTL_TXQx_OP_MODE = MTL_TXQx_MODE_TQS(2048/256 - 1) | MTL_TXQx_MODE_TTC(1) | MTL_TXQx_MODE_TSF | MTL_TXQx_MODE_FTQ;
		}
		pENET->MTL_QUEUEx[i].MTL_RXQx_OP_MODE = MTL_RXQx_MODE_RQS(2048/256 - 1) | MTL_RXQx_MODE_FUP;
		Chip_ENET_SetDescRingLength(pENET, i, 4, 4);
		pENET->DMA_CHANNEL[i].DMA_CHx_INT_EN = 0;
	}

	/* Initial MAC configuration for checksum offload, full duplex,
	   100Mbps, disable receive own in half duplex, inter-frame gap
	   of 64-bits */
	pENET->MAC_CFG = MAC_CFG_BL(0) | MAC_CFG_DM | MAC_CFG_ECRSFD | MAC_CFG_FES | MAC_CFG_PS | MAC_CFG_IPG(0);

	/* Setup default filter */
	pENET->MAC_PKT_FILTER = MAC_PF_SAF;

	/* Enable Channel 0 Rx Queue */
	Chip_ENET_EnableRxQueue(pENET, 0);

	pENET->MTL_RXQ_DMA_MAP = MTL_RxDMAP_DACH(0) | MTL_RxDMAP_DACH(1);
}

/* Ethernet interface shutdown */
void Chip_ENET_DeInit(LPC_ENET_T *pENET)
{
	uint8_t i;
	/* Disable packet reception */
	pENET->MAC_CFG = 0;

	/* Flush transmit FIFO */
	for( i = 0; i < 2; i++) {
		pENET->MTL_QUEUEx[i].MTL_TXQx_OP_MODE = (pENET->MTL_QUEUEx[i].MTL_TXQx_OP_MODE & ~MTL_TXQx_MODE_QEN(3)) | MTL_TXQx_MODE_FTQ;
	}

	Chip_ENET_DisableRxQueue(pENET, 0);
	Chip_ENET_DisableRxQueue(pENET, 1);

	Chip_Clock_DisablePeriphClock(SYSCON_CLOCK_ETHERNET);
}

/* Sets up the PHY link clock divider and PHY address */
void Chip_ENET_SetupMII(LPC_ENET_T *pENET, uint32_t div, uint8_t addr)
{
	/* Save clock divider and PHY address in MII address register */
	phyCfg = MAC_MIIA_PA(addr) | MAC_MIIA_CR(div);
}

/* Starts a PHY write via the MII */
void Chip_ENET_StartMIIWrite(LPC_ENET_T *pENET, uint8_t reg, uint16_t data)
{
	/* Write value at PHY address and register */
	pENET->MAC_MDIO_ADDR = phyCfg | MAC_MIIA_GR(reg) | MAC_MIIA_GOC(MAC_MIIA_WR);
	pENET->MAC_MDIO_DATA = (uint32_t) data;
	pENET->MAC_MDIO_ADDR |= MAC_MIIA_GB;
}

/*Starts a PHY read via the MII */
void Chip_ENET_StartMIIRead(LPC_ENET_T *pENET, uint8_t reg)
{
	/* Read value at PHY address and register */
	pENET->MAC_MDIO_ADDR = phyCfg | MAC_MIIA_GR(reg) | MAC_MIIA_GOC(MAC_MIIA_RD);
	pENET->MAC_MDIO_ADDR |= MAC_MIIA_GB;
}

/* Sets full or half duplex for the interface */
void Chip_ENET_SetDuplex(LPC_ENET_T *pENET, bool full)
{
	if (full) {
		pENET->MAC_CFG |= MAC_CFG_DM;
	}
	else {
		pENET->MAC_CFG &= ~MAC_CFG_DM;
	}
}

/* Sets speed for the interface */
void Chip_ENET_SetSpeed(LPC_ENET_T *pENET, bool speed100)
{
	if (speed100) {
		pENET->MAC_CFG |= MAC_CFG_FES | MAC_CFG_PS;
	}
	else {
		pENET->MAC_CFG = (pENET->MAC_CFG & ~MAC_CFG_FES) | MAC_CFG_PS;
	}
}

