
//*****************************************************************************
// FlashDev.c
// MCUXpresso IDE Flash driver - Flash Device settings
//
// i.MX RT1160/RT1170/RT1180 FlexSPI SFDP based drivers
//
//*****************************************************************************
//
// Copyright 2020-2025 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "FlashConfig.h"
#include "lpcx_flash_driver.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS,				// Driver Version, do not modify!

#if defined (MIMXRT1170_SFDP_QSPI)
   "iMXRT1170_SFDP_FlexSPI1_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1170_SFDP_MXIC_OPI)
   "iMXRT1170_SFDP_FlexSPI1_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1170_SFDP_MICRON_OPI)
   "iMXRT1170_SFDP_FlexSPI1_MICRON_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1160_SFDP_QSPI)
   "iMXRT1160_SFDP_FlexSPI1_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1160_SFDP_MXIC_OPI)
   "iMXRT1160_SFDP_FlexSPI1_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1170_FlexSPI2_A_SFDP_QSPI)
   "iMXRT1170_SFDP_FlexSPI2_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1160_FlexSPI2_A_SFDP_QSPI)
   "iMXRT1160_SFDP_FlexSPI2_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_QSPI)
   "RT1180_FlexSPI1_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_QSPI)
   "RT1180_FlexSPI1_B_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI)
   "RT1180_FlexSPI1_A_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI)
   "RT1180_FlexSPI1_B_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI)
   "RT1180_FlexSPI1_A_MICRON_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI)
   "RT1180_FlexSPI1_B_MICRON_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S)
   "RT1180_FlexSPI1_A_QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S)
   "RT1180_FlexSPI1_B_QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S)
   "RT1180_FlexSPI1_A_MXIC_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI_S)
   "RT1180_FlexSPI1_B_MXIC_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S)
   "RT1180_FlexSPI1_A_MICRON_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI_S)
   "RT1180_FlexSPI1_B_MICRON_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI)
   "RT1180_FlexSPI2_PriGr_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI_S)
   "RT1180_FlexSPI2_PriGr_A_QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI)
   "RT1180_FlexSPI2_PriGr_B_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI_S)
   "RT1180_FlexSPI2_PriGr_B_QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI)
   "RT1180_FlexSPI2_Pri_AB_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S)
   "RT1180_FlexSPI2_Pri_AB_MXIC_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI)
   "RT1180_FlexSPI2_Pri_AB_MICRON_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S)
   "RT1180_FlexSPI2_Pri_AB_MICRON_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI)
   "RT1180_FlexSPI2_SecGr_A_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI_S)
   "RT1180_FlexSPI2_SecGr_A_QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI)
   "RT1180_FlexSPI2_SecGr_B_QSPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI_S)
   "RT1180_FlexSPI2_SecGr_B_QSPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI)
   "RT1180_FlexSPI2_Sec_AB_MXIC_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S)
   "RT1180_FlexSPI2_Sec_AB_MXIC_OPI (Secure) "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI)
   "RT1180_FlexSPI2_Sec_AB_MICRON_OPI "__DATE__" "__TIME__,
#elif defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S)
   "RT1180_FlexSPI2_Sec_AB_MICRON_OPI (Secure) "__DATE__" "__TIME__,
#else
#error "No driver defined"
#endif

   EXTSPIJ,    // Device Type
   0,          // Device Start Address ** Will be updated by call to Init() **
   0x1000000,  // Device Size ** Will be updated by call to Init() **
   0x100,      // Programming Page Size ** Will be updated by call to Init() **
   0,          // Reserved, must be 0
   0xFF,       // Initial Content of Erased Memory
   3000,       // Program Page Timeout
   6000,       // Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{0x10000, 0},   // Sector sizes ** Will be updated by call to Init() **
   {SECTOR_END}}
};


