/*
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __SYS_CONFIG_H_
#define __SYS_CONFIG_H_

/* Build for 407x/8x chip family */
#define CHIP_LPC40XX

/* For the LPC4074, the __FPU_PRESENT definition should be set to 0 */
// #define __FPU_PRESENT 0

/* Enable DMA in SDC driver */
#define SDC_DMA_ENABLE

#endif /* __SYS_CONFIG_H_ */
