/*
 * @brief LPC5460X Miscellaneous chip specific functions
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/* System Clock Frequency (Core Clock) */
uint32_t SystemCoreClock;

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Update system core clock rate, should be called if the system has
   a clock rate change */
void SystemCoreClockUpdate(void)
{
	/* CPU core speed (main clock speed adjusted by system clock divider) */
	SystemCoreClock = Chip_Clock_GetSystemClockRate();
}

void Chip_USB0_Init(void)
{
	uint32_t div = 1;
	/* Turn ON FRO */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_FRO);

	/* Turn ON FRO HF and let it adjust TRIM value based on USB SOF */
	LPC_SYSCON->FROCTRL = (LPC_SYSCON->FROCTRL & ~SYSCON_FROCTRL_MASK) |
		SYSCON_FROCTRL_HSPDCLK | SYSCON_FROCTRL_USBCLKADJ;

	/* If we are running at 96 MHz we must use USBCLKDIV to
	 * bring frequency down to 48MHz */
	if (Chip_Clock_GetFROHFRate() == SYSCON_FRO96MHZ_FREQ) {
		div = 2;
	}

	/* Set the USB Clock source to 96 MHz FRO */
	Chip_Clock_SetUSB0ClockSource(SYSCON_USB0CLKSRC_FROHF, div);

	/* Enable USB Peripheral clock */
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_USBD0);

	/* Enable waking-up of MCU from USB */
	Chip_SYSCON_EnableWakeup(SYSCON_STARTER_USB0);

	/* Power on USB PHY */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_USB_PHY);

	/* Reset the USB peripheral */
	Chip_SYSCON_PeriphReset(RESET_USB);
}

void Chip_USB1_Init(void)
{
	/* enable USB main clock */
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_USBD1);
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_USB1_RAM);
		
	/* VD2_ANA needs to be powered up too. According to the design team, it's powered up at chip reset. */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_VD2_ANA);
	
	/* When PLL is used, VD3 needs to be powered up. */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_VD3);	
	
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_SYSOSC);
	
	/* USB PLL and USB1 PHY need to be powered up. */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_VD5);
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_USB1PHY);
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_USBPLL);
	
	Chip_Clock_SetupUSBPLL();
	Chip_Clock_SetUSB1ClockSource(SYSCON_USB1CLKSRC_USBPLL, 1);

	/* Enable waking-up of MCU from USB */
	Chip_SYSCON_EnableWakeup(SYSCON_STARTER_USB1);
	
	/* Release the USB reset */
	Chip_SYSCON_PeriphReset(RESET_USBD1);
}
