/*
 * @brief LPC5460x USB host register block
 *
 * @note
 * Copyright 2012, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __USBH_5460X_H_
#define __USBH_5460X_H_

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
**************************************************************************************************************
*                                  OHCI OPERATIONAL REGISTER FIELD DEFINITIONS
**************************************************************************************************************
*/

                                            /* ------------------ HcControl Register ---------------------  */
#define  OR_CONTROL_CLE                 0x00000010
#define  OR_CONTROL_BLE                 0x00000020
#define  OR_CONTROL_HCFS                0x000000C0
#define  OR_CONTROL_HC_OPER             0x00000080
                                            /* ----------------- HcCommandStatus Register ----------------- */
#define  OR_CMD_STATUS_HCR              0x00000001
#define  OR_CMD_STATUS_CLF              0x00000002
#define  OR_CMD_STATUS_BLF              0x00000004
                                            /* --------------- HcInterruptStatus Register ----------------- */
#define  OR_INTR_STATUS_WDH             0x00000002
#define  OR_INTR_STATUS_UE              (0x1<<4)
#define  OR_INTR_STATUS_RHSC            0x00000040
                                            /* --------------- HcInterruptEnable Register ----------------- */
#define  OR_INTR_ENABLE_WDH             0x00000002
#define  OR_INTR_ENABLE_UE              (0x1<<4)
#define  OR_INTR_ENABLE_RHSC            0x00000040
#define  OR_INTR_ENABLE_MIE             0x80000000
                                            /* ---------------- HcRhDescriptorA Register ------------------ */
#define  OR_RH_STATUS_LPSC              0x00010000
#define  OR_RH_STATUS_DRWE              0x00008000
                                            /* -------------- HcRhPortStatus[1:NDP] Register -------------- */
#define  OR_RH_PORT_CCS                 0x00000001
#define  OR_RH_PORT_PRS                 0x00000010
#define  OR_RH_PORT_CSC                 0x00010000
#define  OR_RH_PORT_PRSC                0x00100000


/*
**************************************************************************************************************
*                                               FRAME INTERVAL
**************************************************************************************************************
*/

#define  FI                     0x2EDF           /* 12000 bits per frame (-1)                               */
#define  DEFAULT_FMINTERVAL     ((((6 * (FI - 210)) / 7) << 16) | FI)

/*
**************************************************************************************************************
*                                       TRANSFER DESCRIPTOR CONTROL FIELDS
**************************************************************************************************************
*/

#define  TD_ROUNDING        (uint32_t)(0x00040000)        /* Buffer Rounding                             */
#define  TD_SETUP           (uint32_t)(0)                  /* Direction of Setup Packet                   */
#define  TD_IN              (uint32_t)(0x00100000)         /* Direction In                                */
#define  TD_OUT             (uint32_t)(0x00080000)         /* Direction Out                               */
#define  TD_DELAY_INT(x)    (uint32_t)((x) << 21)          /* Delay Interrupt                             */
#define  TD_TOGGLE_0        (uint32_t)(0x02000000)         /* Toggle 0                                    */
#define  TD_TOGGLE_1        (uint32_t)(0x03000000)         /* Toggle 1                                    */
#define  TD_CC              (uint32_t)(0xF0000000)         /* Completion Code                             */

/*
**************************************************************************************************************
*                                       TYPE DEFINITIONS
**************************************************************************************************************
*/
typedef volatile struct
{
  __I  uint32_t Revision;             /* USB Host Registers                 */
  __IO uint32_t Control;
  __IO uint32_t CommandStatus;
  __IO uint32_t InterruptStatus;
  __IO uint32_t InterruptEnable;
  __IO uint32_t InterruptDisable;
  __IO uint32_t HCCA;
  __I  uint32_t PeriodCurrentED;
  __IO uint32_t ControlHeadED;
  __IO uint32_t ControlCurrentED;
  __IO uint32_t BulkHeadED;
  __IO uint32_t BulkCurrentED;
  __I  uint32_t DoneHead;
  __IO uint32_t FmInterval;
  __I  uint32_t FmRemaining;
  __I  uint32_t FmNumber;
  __IO uint32_t PeriodicStart;
  __IO uint32_t LSTreshold;
  __IO uint32_t RhDescriptorA;
  __IO uint32_t RhDescriptorB;
  __IO uint32_t RhStatus;
  __IO uint32_t RhPortStatus1;
  __IO uint32_t RhPortStatus2;
       uint32_t RESERVED0[40];
  __I  uint32_t Module_ID;
} USBH_REGS_T;

typedef USBH_REGS_T LPC_USBH0_T;

typedef struct hcEd {                       /* ----------- HostController EndPoint Descriptor ------------- */
    volatile  uint32_t  Control;              /* Endpoint descriptor control                              */
    volatile  uint32_t  TailTd;               /* Physical address of tail in Transfer descriptor list     */
    volatile  uint32_t  HeadTd;               /* Physcial address of head in Transfer descriptor list     */
    volatile  uint32_t  Next;                 /* Physical address of next Endpoint descriptor             */
} HCED;

typedef struct hcTd {                       /* ------------ HostController Transfer Descriptor ------------ */
    volatile  uint32_t  Control;              /* Transfer descriptor control                              */
    volatile  uint32_t  CurrBufPtr;           /* Physical address of current buffer pointer               */
    volatile  uint32_t  Next;                 /* Physical pointer to next Transfer Descriptor             */
    volatile  uint32_t  BufEnd;               /* Physical address of end of buffer                        */
} HCTD;

typedef struct hcca {                       /* ----------- Host Controller Communication Area ------------  */
    volatile  uint32_t  IntTable[32];         /* Interrupt Table                                          */
    volatile  uint32_t  FrameNumber;          /* Frame Number                                             */
    volatile  uint32_t  DoneHead;             /* Done Head                                                */
    volatile  uint8_t  Reserved[116];        /* Reserved for future use                                  */
    volatile  uint8_t  Unknown[4];           /* Unused                                                   */
} HCCA;

/*
**************************************************************************************************************
*                                     EXTERN DECLARATIONS
**************************************************************************************************************
*/

extern  volatile  HCED     *EDBulkIn;        /* BulkIn endpoint descriptor  structure                    */
extern  volatile  HCED     *EDBulkOut;       /* BulkOut endpoint descriptor structure                    */
extern  volatile  HCTD     *TDHead;          /* Head transfer descriptor structure                       */
extern  volatile  HCTD     *TDTail;          /* Tail transfer descriptor structure                       */
extern  volatile  uint8_t  *TDBuffer;        /* Current Buffer Pointer of transfer descriptor            */
extern  volatile  uint8_t  *FATBuffer;       /* Buffer used by FAT file system                           */
extern  volatile  uint8_t  *UserBuffer;      /* Buffer used by application                               */

typedef volatile struct {
	uint32_t  CAPLENGTH_CHIPID; /*!< This register contains the offset value towards the start of the operational register space and the version number of the IP block */
	uint32_t  HCSPARAMS;        /*!< Host Controller Structural Parameters */
	uint32_t  HCCPARAMS;        /*!< Host Controller Capability Parameters */
	uint32_t  FLADJ_FRINDEX;    /*!< Frame Length Adjustment */
	uint32_t  ATL_PTD_BASE;     /*!< Memory base address where ATL PTD0 is stored */
	uint32_t  ISO_PTD_BASE;     /*!< Memory base address where ISO PTD0 is stored */
	uint32_t  INT_PTD_BASE;     /*!< Memory base address where INT PTD0 is stored */
	uint32_t  DATA_PLD_BASE;    /*!< Memory base address that indicates the start of the data payload buffers */
	uint32_t  USBCMD;           /*!< USB Command register */
	uint32_t  USBSTS;           /*!< USB Interrupt Status register */
	uint32_t  USBINTR;          /*!< USB Interrupt Enable register */
	uint32_t  PORTSC1;          /*!< Port Status and Control register */
	uint32_t  ATL_PTD_DONE;     /*!< Done map for each ATL PTD */
	uint32_t  ATL_PTD_SKIP;     /*!< Skip map for each ATL PTD */
	uint32_t  ISO_PTD_DONE;     /*!< Done map for each ISO PTD */
	uint32_t  ISO_PTD_SKIP;     /*!< Skip map for each ISO PTD */
	uint32_t  INT_PTD_DONE;     /*!< Done map for each INT PTD */
	uint32_t  INT_PTD_SKIP;     /*!< Skip map for each INT PTD */
	uint32_t  LAST_PTD;         /*!< Marks the last PTD in the list for ISO, INT and ATL */
	uint32_t  UTMI_ULPI_DBG;    /*!< Register to read/write registers in the attached USB PHY */
} USB1_HOST_REGS_T;

typedef USB1_HOST_REGS_T LPC_USBH1_T;

/*
**************************************************************************************************************
*                                  EHCI OPERATIONAL REGISTER FIELD DEFINITIONS
**************************************************************************************************************
*/

                                            /* ------------------ HcControl Register ---------------------  */
#define  ER_CONTROL_CLE                 0x00000010
#define  ER_CONTROL_BLE                 0x00000020
#define  ER_CONTROL_HCFS                0x000000C0
#define  ER_CONTROL_HC_OPER             0x00000080
                                            /* ----------------- HcCommandStatus Register ----------------- */
#define  ER_CMD_STATUS_HCR              0x00000001
#define  ER_CMD_STATUS_CLF              0x00000002
#define  ER_CMD_STATUS_BLF              0x00000004
                                            /* --------------- HcInterruptStatus Register ----------------- */
#define  ER_INTR_STATUS_PCD             (0x1<<2)
#define  ER_INTR_STATUS_FLR             (0x1<<3)
#define  ER_INTR_STATUS_ATL             (0x1<<16)
#define  ER_INTR_STATUS_ISO             (0x1<<17)
#define  ER_INTR_STATUS_INT             (0x1<<18)
#define  ER_INTR_STATUS_SOF             (0x1<<19)
                                            /* --------------- HcInterruptEnable Register ----------------- */
#define  ER_INTR_ENABLE_PCD             (0x1<<2)
#define  ER_INTR_ENABLE_FLR             (0x1<<3)
#define  ER_INTR_ENABLE_ATL             (0x1<<16)
#define  ER_INTR_ENABLE_ISO             (0x1<<17)
#define  ER_INTR_ENABLE_INT             (0x1<<18)
#define  ER_INTR_ENABLE_SOF             (0x1<<19)
                                            /* ---------------- HcRhDescriptorA Register ------------------ */
#define  ER_RH_STATUS_LPSC              0x00010000
#define  ER_RH_STATUS_DRWE              0x00008000
                                            /* -------------- HcRPortSC1 Register -------------- */
#define  ER_PORTSC1_CCS                 (0x1<<0)
#define  ER_PORTSC1_CSC                 (0x1<<1)
#define  ER_PORTSC1_PED                 (0x1<<2)
#define  ER_PORTSC1_PEDC                (0x1<<3)
#define  ER_PORTSC1_OCA                 (0x1<<4)
#define  ER_PORTSC1_OCC                 (0x1<<5)
#define  ER_PORTSC1_FPR                 (0x1<<6)
#define  ER_PORTSC1_SUSP                (0x1<<7)
#define  ER_PORTSC1_PR                  (0x1<<8)
#define  ER_PORTSC1_SUS_L1              (0x1<<9)
#define  ER_PORTSC1_LS                  (0x3<<10)
#define  ER_PORTSC1_PP                  (0x1<<12)

#define  ER_PORTSC1_PIC_OFF             (0x0<<14)
#define  ER_PORTSC1_PIC_AMBER           (0x1<<14)
#define  ER_PORTSC1_PIC_GREEN           (0x2<<14)
#define  ER_PORTSC1_PTC                 (0xF<<16)
#define  ER_PORTSC1_PSPD_LS             (0x0<<20)
#define  ER_PORTSC1_PSPD_FS             (0x1<<20)
#define  ER_PORTSC1_PSPD_HS             (0x2<<20)
#define  ER_PORTSC1_WOO                 (0x1<<22)
#define  ER_PORTSC1_SUS_STAT_ACK        (0x0<<23)
#define  ER_PORTSC1_SUS_STAT_NYET       (0x1<<23)
#define  ER_PORTSC1_SUS_STAT_ERR        (0x3<<23)
#define  ER_PORTSC1_DEV_ADD             (0x7F<<25)

#ifdef __cplusplus
}
#endif

#endif /* __USBH_5460X_H_ */
