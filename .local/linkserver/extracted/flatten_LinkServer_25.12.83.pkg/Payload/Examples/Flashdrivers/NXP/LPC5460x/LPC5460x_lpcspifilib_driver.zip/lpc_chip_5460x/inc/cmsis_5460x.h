/*
 * @brief Basic CMSIS include file for LPC5460x M4 core
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __CMSIS_5460X_H_
#define __CMSIS_5460X_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup CMSIS_5460X_M4 CHIP: LPC5460X M4 core CMSIS include file
 * @ingroup CHIP_5460X_CMSIS_DRIVERS
 * @{
 */

#if defined(__ARMCC_VERSION)
// Kill warning "#pragma push with no matching #pragma pop"
  #pragma diag_suppress 2525
  #pragma push
  #pragma anon_unions
#elif defined(__CWCC__)
  #pragma push
  #pragma cpp_extensions on
#elif defined(__GNUC__)
/* anonymous unions are enabled by default */
#elif defined(__IAR_SYSTEMS_ICC__)
//  #pragma push // FIXME not usable for IAR
  #pragma language=extended
#else
  #error Not supported compiler type
#endif

/*
 * ==========================================================================
 * ---------- Interrupt Number Definition -----------------------------------
 * ==========================================================================
 */

#if !defined(CORE_M4)
#error "CORE_M4 is not defined"
#endif

/** @defgroup CMSIS_5460X_M4_IRQ CHIP_5460X: LPC5460X M4 core peripheral interrupt numbers
 * @{
 */

typedef enum {
	/******  Cortex-M4 Processor Exceptions Numbers ***************************************************/
	Reset_IRQn                    = -15,    /*!< 1  Reset Vector, invoked on Power up and warm reset */
	NonMaskableInt_IRQn           = -14,    /*!< 2  Non maskable Interrupt, cannot be stopped or preempted */
	HardFault_IRQn                = -13,    /*!< 3  Hard Fault, all classes of Fault */
	MemoryManagement_IRQn         = -12,    /*!< 4  Memory Management, MPU mismatch, including Access Violation and No Match */
	BusFault_IRQn                 = -11,    /*!< 5  Bus Fault, Pre-Fetch-, Memory Access Fault, other address/memory related Fault */
	UsageFault_IRQn               = -10,    /*!< 6  Usage Fault, i.e. Undef Instruction, Illegal State Transition */
	SVCall_IRQn                   =  -5,    /*!< 11  System Service Call via SVC instruction */
	DebugMonitor_IRQn             =  -4,    /*!< 12  Debug Monitor                    */
	PendSV_IRQn                   =  -2,    /*!< 14  Pendable request for system service */
	SysTick_IRQn                  =  -1,    /*!< 15  System Tick Timer                */

	/******  LPC5460X Specific Interrupt Numbers ********************************************************/
	WDTBOD_IRQn,        /*!< 0  WWDT                                             */
	DMA_IRQn,           /*!< 1  DMA                                              */
	GINT0_IRQn,         /*!< 2  GINT0                                            */
	GINT1_IRQn,         /*!< 3  GINT1                                            */
	PIN_INT0_IRQn,      /*!< 4  PININT0                                          */
	PIN_INT1_IRQn,      /*!< 5  PININT1                                          */
	PIN_INT2_IRQn,      /*!< 6  PININT2                                          */
	PIN_INT3_IRQn,      /*!< 7  PININT3                                          */
	UTICK_IRQn,         /*!< 8  Micro-tick Timer interrupt                       */
	MRT_IRQn,           /*!< 9  Multi-rate timer interrupt                       */
	CT32B0_IRQn,        /*!< 10 CTMR0                                            */
	CT32B1_IRQn,        /*!< 11 CTMR1                                            */
	SCT0_IRQn,          /*!< 12 SCT                                              */
	CT32B3_IRQn,        /*!< 13 CTMR3                                            */
	FLEXCOMM0_IRQn,     /*!< 14 FLEXCOMM0                                        */
	FLEXCOMM1_IRQn,     /*!< 15 FLEXCOMM1                                        */
	FLEXCOMM2_IRQn,     /*!< 16 FLEXCOMM2                                        */
	FLEXCOMM3_IRQn,     /*!< 17 FLEXCOMM3                                        */
	FLEXCOMM4_IRQn,     /*!< 18 FLEXCOMM4                                        */
	FLEXCOMM5_IRQn,     /*!< 19 FLEXCOMM5                                        */
	FLEXCOMM6_IRQn,     /*!< 20 FLEXCOMM6                                        */
	FLEXCOMM7_IRQn,     /*!< 21 FLEXCOMM7                                        */
	ADC_SEQA_IRQn,      /*!< 22 ADC0 sequence A completion                       */
	ADC_SEQB_IRQn,      /*!< 23 ADC0 sequence B completion                       */
	ADC_THCMP_IRQn,     /*!< 24 ADC0 threshold compare and error                 */
	DMIC_IRQn,          /*!< 25 Digital Mic                                      */
	HWVAD_IRQn,         /*!< 26 Hardware Voice acitivity detect                  */
	USB0ACT_IRQn,       /*!< 27 USB Activity                                     */
	USB0_IRQn,          /*!< 28 USB                                              */
	RTC_IRQn,           /*!< 29 RTC alarm and wake-up interrupts                 */
	Reserved_IRQn,      /*!< 30 Reserved Interrupt                               */
	WAKEUP_IRQn,        /*!< 31 FIXME: what is wakeup (is this reserved?)        */
	PIN_INT4_IRQn,      /*!< 32 External Interrupt 4                             */
	PIN_INT5_IRQn,      /*!< 33 External Interrupt 5                             */
	PIN_INT6_IRQn,      /*!< 34 External Interrupt 6                             */
	PIN_INT7_IRQn,      /*!< 35 External Interrupt 7                             */
	CT32B2_IRQn,        /*!< 36 CTMR2                                            */
	CT32B4_IRQn,        /*!< 37 CTMR4                                            */
	RITIMER_IRQn,       /*!< 38 OSTIMER Interrupt                                */
	SPIFI_IRQn,         /*!< 39 SPI Flash interface                              */
	FLEXCOMM8_IRQn,     /*!< 40 Flexcomm8 interrupt                              */
	FLEXCOMM9_IRQn,     /*!< 41 Flexcomm9 interrupt                              */
	SDIO_IRQn,          /*!< 42 SDIO Interrupt                                   */
	CAN0_0_IRQn,        /*!< 43 CAN0 Interrupt0                                  */
	CAN0_1_IRQn,        /*!< 44 CAN0 Interrupt1                                  */
	Reserved1_IRQn,     /*!< 45 FIXME: Is this really CAN1_0_IRQn (?)            */
	Reserved2_IRQn,     /*!< 46 FIXME: Is this really CAN1_1_IRQn (?)            */
	USB1_IRQn,          /*!< 47 USB1 Interrupt                                   */
	USB1ACT_IRQn,       /*!< 48 USB1 Activity interrupt                          */
	ETH_IRQn,           /*!< 49 Ethernet Interrupt handler                       */
	ETH_PMT_IRQn,       /*!< 50 FIXME: What is this (?)                          */
	ETH_MACLP_IRQn,     /*!< 51 FIXME: Check what this is!                       */
	EEPROM_IRQn,        /*!< 52 EEPROM Interrupt                                 */
	LCD_IRQn,           /*!< 53 LCD Controller Interrupt                         */
	SHA_IRQn,           /*!< 54 Hash engine interrupt                            */
	SMARTCARD0_IRQn,    /*!< 55 Smart card-0 interrupt                           */
	SMARTCARD1_IRQn,    /*!< 56 Smart card-1 interrupt                           */
} LPC5460X_IRQn_Type;

/**
 * @}
 */

/*
 * ==========================================================================
 * ----------- Processor and Core Peripheral Section ------------------------
 * ==========================================================================
 */

/** @defgroup CMSIS_5460X_M4_COMMON CHIP: LPC5460X M4 core Cortex CMSIS definitions
 * @{
 */

/* Configuration of the Cortex-M4 Processor and Core Peripherals */
#define __CM4_REV                 0x0001	/*!< Cortex-M4 Core Revision                          */
#define __MPU_PRESENT             1			/*!< MPU present or not                               */
#define __NVIC_PRIO_BITS          3			/*!< Number of Bits used for Priority Levels          */
#define __Vendor_SysTickConfig    0			/*!< Set to 1 if different SysTick Config is used     */
#define __FPU_PRESENT             1

/** @brief interrupt Alias */
#define TIMER0_IRQn CT32B0_IRQn
#define TIMER1_IRQn CT32B1_IRQn
#define TIMER2_IRQn CT32B2_IRQn
#define TIMER3_IRQn CT32B3_IRQn
#define TIMER4_IRQn CT32B4_IRQn
#define SCT_IRQn SCT0_IRQn
#define ADC0_SEQA_IRQn ADC_SEQA_IRQn
#define ADC0_SEQB_IRQn ADC_SEQB_IRQn
#define ADC0_THCMP_IRQn ADC_THCMP_IRQn

/** @brief	Interrupt handler Alias */
#define TIMER0_IRQHandler CT32B0_IRQHandler
#define TIMER1_IRQHandler CT32B1_IRQHandler
#define TIMER2_IRQHandler CT32B2_IRQHandler
#define TIMER3_IRQHandler CT32B3_IRQHandler
#define TIMER4_IRQHandler CT32B4_IRQHandler
#define SCT_IRQHandler SCT0_IRQHandler
#define ADC0_SEQA_IRQHandler ADC_SEQA_IRQHandler
#define ADC0_SEQB_IRQHandler ADC_SEQB_IRQHandler
#define ADC0_THCMP_IRQHandler ADC_THCMP_IRQHandler

/**
 * @}
 */

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __CMSIS_5460X_H_ */
