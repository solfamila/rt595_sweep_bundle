//*****************************************************************************
// FlashDev.c
// LPCXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2014-2015, 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "lpcx_flash_driver.h"
#include <FlashConfig.h>
#include "fsl_common.h"

FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS,				// Driver Version, do not modify!
   "MIMXRT1050_EcoXiP_Flash_4MB "__DATE__" "__TIME__,
   EXTSPI,     			// Device Type
   FlexSPI_AMBA_BASE, 	// Device Start Address
   FLASH_SIZE,   		// Device Size
   PSEUDO_PAGE_SIZE,	// Programming Page Size
   0,          			// Reserved, must be 0
   0xFF,       			// Initial Content of Erased Memory
   3000,       			// Program Page Timeout
   6000,      			// Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{FLASH_SECTOR_SIZE, 0},   // Sector sizes
   {SECTOR_END}}
};



