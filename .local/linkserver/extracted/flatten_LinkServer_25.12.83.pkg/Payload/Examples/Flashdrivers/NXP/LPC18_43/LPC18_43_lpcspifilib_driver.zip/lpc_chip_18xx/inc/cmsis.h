/*
 * @brief LPC11xx selective CMSIS inclusion file
 *
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __CMSIS_H_
#define __CMSIS_H_

#include "lpc_types.h"
#include "sys_config.h"

/* Select correct CMSIS include file based on CHIP_* definition */
#if defined(CHIP_LPC43XX)

#ifdef CORE_M4
#include "cmsis_43xx.h"

#elif defined(CORE_M0)
#if defined(LPC43XX_CORE_M0APP)
#include "cmsis_43xx_m0app.h"

#elif (defined(LPC43XX_CORE_M0SUB))
#include "cmsis_43xx_m0sub.h"

#else
#error "LPC43XX_CORE_M0APP or LPC43XX_CORE_M0SUB must be defined"
#endif

#else
#error "CORE_M0 or CORE_M4 must be defined for CHIP_LPC43XX"
#endif

#elif defined(CHIP_LPC18XX)
#include "cmsis_18xx.h"

#else
#error "No CHIP_* definition is defined"
#endif

#endif /* __CMSIS_H_ */
