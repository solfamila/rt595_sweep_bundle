//*****************************************************************************
// FlashDev.c
// LPCXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2014-2016, 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "lpcx_flash_driver.h"

#if defined (SPIFI_GENERIC)
FLASHDEV_SECTION
FlashDeviceV_t FlashDevice  =  {
   FLASH_DRV_VERS,				// Driver Version, do not modify!
   "LPC5460x Generic SPIFI "__DATE__" "__TIME__,
   EXTSPI,     // Device Type
   0x10000000, // Device Start Address
   0x4000000,  // Device Size ** Will be updated by call to Init() **
   0x100,      // Programming Page Size ** Will be updated by call to Init() **
   0,          // Reserved, must be 0
   0xFF,       // Initial Content of Erased Memory
   3000,       // Program Page Timeout
   6000,       // Erase Sector Timeout
   // Specify Size and Address of Sectors
   {{0x10000, 0},   // Sector sizes ** Will be updated by call to Init() **
   {SECTOR_END}}
};

#else
#error "Flash configuration not defined"
#endif


