//*****************************************************************************
// LPCXpresso IDE flash driver - FlashPrg.c
//
// * Flash Programming Functions for SPIFI Flash
//*****************************************************************************
//
// Copyright 2014-2017, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include <stdint.h>
// For memcmp used in Verify()
#include <string.h>
#include "lpcx_flash_driver.h"

#include "chip.h"
#include "spifilib_api.h"

//#ifndef SPIFLASH_BASE_ADDRESS
//#define SPIFLASH_BASE_ADDRESS (0x28000000)
//#endif

#define SPIFLASH_BASE_ADDRESS (0x10000000)

//#define SCU_MODE_FUNC5 (5)
//#define SCU_MODE_INACT (0)
//#define SCU_MODE_HIGHSPEEDSLEW (1 << 9)
//#define SCU_PINIO_FAST (SCU_MODE_INACT | SCU_MODE_HIGHSPEEDSLEW)

//STATIC const PINMUX_GRP_T spifipinmuxing[] = {
//	{0x0, 22,  (SCU_PINIO_FAST | SCU_MODE_FUNC5)},	/* SPIFI CLK */
//	{0x0, 16,  (SCU_PINIO_FAST | SCU_MODE_FUNC5)},	/* SPIFI D3 */
//	{0x0, 15,  (SCU_PINIO_FAST | SCU_MODE_FUNC5)},	/* SPIFI D2 */
//	{0x0, 17,  (SCU_PINIO_FAST | SCU_MODE_FUNC5)},	/* SPIFI D1 */
//	{0x0, 18,  (SCU_PINIO_FAST | SCU_MODE_FUNC5)},	/* SPIFI D0 */
//	{0x2, 7,  (SCU_PINIO_FAST | SCU_MODE_FUNC5)}	/* SPIFI CS/SSEL */
//};

/* Local memory, 32-bit aligned that will be used for driver context (handle) */
static uint32_t lmem[21];

static SPIFI_HANDLE_T *pSpifiHandle;

Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;

// ************************************
// Flash driver functions
// ************************************

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t Init (void)
{
	uint32_t maxSpifiClock;
	uint32_t spifiBaseClockRate;
	SPIFI_ERR_T errCode;
	uint32_t memSize;

#ifdef NDEBUG
	Chip_SystemInit();
#endif

	/* Setup SPIFI FLASH pin muxing (QUAD) */

	//	Chip_SCU_SetPinMuxing(spifipinmuxing,
	//			sizeof(spifipinmuxing) / sizeof(PINMUX_GRP_T));
	// Best match for SCU_PINIO_FAST, no setting to enable input buffer, Bit 10 selects Fast Slew mode
	// IOCON clock left on, this is needed is CLKIN is used. - SET IN sysinit_5460?
    Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_IOCON);

	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 23, (IOCON_FUNC6 | IOCON_INPFILT_OFF | IOCON_DIGITAL_EN )); //SPIFI_CSN
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 24, (IOCON_FUNC6 | IOCON_INPFILT_OFF | IOCON_DIGITAL_EN | (1 << 10))); //SPIFI_IO0
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 25, (IOCON_FUNC6 | IOCON_INPFILT_OFF | IOCON_DIGITAL_EN | (1 << 10))); //SPIFI_IO1
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 26, (IOCON_FUNC6 | IOCON_INPFILT_OFF | IOCON_DIGITAL_EN | (1 << 10))); //SPIFI_CLK
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 27, (IOCON_FUNC6 | IOCON_INPFILT_OFF | IOCON_DIGITAL_EN | (1 << 10))); //SPIFI_IO3
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 28, (IOCON_FUNC6 | IOCON_INPFILT_OFF | IOCON_DIGITAL_EN | (1 << 10))); //SPIFI_IO2

// First implementation from early LPCOpen drop
// Does later LPCOpen have better support for this?
//SPIFICLKSEL and SPIFICLKDIV
//4.5.33 SPIFI clock select register - set to main clock
	*(uint32_t*) (LPC_SYSCON_BASE + 0x2A0) = 0;
//4.5.53 SPIFI clock divider register = div by 2
	*(uint32_t*) (LPC_SYSCON_BASE + 0x390) = 1;
// Best guess - sets SPIFI clock from system clock - AHBCLKCTRL0 offset 0x220
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_SPIFI);
// Best guess - resets and enables the SPIFI peripheral
	Chip_SYSCON_PeriphReset(RESET_SPIFI);

	// Sets spifiBaseClock to be the same as Main clock
	spifiBaseClockRate = Chip_Clock_GetMainClockRate();

//	/* SPIFI base clock will be based on the main PLL rate and a divider */
//	spifiBaseClockRate = Chip_Clock_GetClockInputHz(CLKIN_MAINPLL);
//
//	/* Setup SPIFI clock to run around 1Mhz. Use divider E for this, as it allows
//	 higher divider values up to 256 maximum) */
//	Chip_Clock_SetDivider(CLK_IDIV_E, CLKIN_MAINPLL,
//			((spifiBaseClockRate / 1000000) + 1));
//	Chip_Clock_SetBaseClock(CLK_BASE_SPIFI, CLKIN_IDIVE, true, false);

	/* Initialize LPCSPIFILIB library, reset the interface */
	spifiInit(LPC_SPIFI_BASE, true);

	/* register support for the family(s) we may want to work with */

	spifiRegisterFamily(spifi_REG_FAMILY_CommonCommandSet);

	/* Get required memory for detected device, this may vary per device family */
	memSize = spifiGetHandleMemSize(LPC_SPIFI_BASE);
	if (memSize == 0) {
		/* No device detected, error */
		return (SPIFI_ERR_NODEVICE);
	}
	/* Initialize and detect a device and get device context
	 * NOTE: Since we don't have malloc enabled we are just supplying
	 * a chunk of memory that we know is large enough. It would be
	 * better to use malloc if it is available. */

	pSpifiHandle = spifiInitDevice(&lmem, sizeof(lmem), LPC_SPIFI_BASE,
	SPIFLASH_BASE_ADDRESS);
	if (pSpifiHandle == NULL) {
		return (SPIFI_ERR_GEN);
	}

	/* Get some info needed for the application */
	maxSpifiClock = spifiDevGetInfo(pSpifiHandle, SPIFI_INFO_MAXCLOCK);

	/* Setup SPIFI clock to at the maximum interface rate the detected device
	 * can use. This should be done after device init. */

	//	Chip_Clock_SetSPIFIClockDiv(2);		// done earlier in the code

	/* start by unlocking the device */
	errCode = spifiDevUnlockDevice(pSpifiHandle);
	if (errCode != SPIFI_ERR_NONE) {
		return (errCode);
	}

	/* Now updated the FlashDevice table using the settings for the
	 detected SPIFI device. These new values will be read back by
	 the debugger upon return from Init()  */

	// Update FlashDevice device size
	FlashDevice.szDev = spifiDevGetInfo(pSpifiHandle, SPIFI_INFO_DEVSIZE);

	// Update FlashDevice sector size
	// Note: SPIFI devices are assumed to only support a single size
	FlashDevice.sectors[0].szSector = spifiDevGetInfo(pSpifiHandle, SPIFI_INFO_ERASE_BLOCKSIZE);

	/* Update FlashDevice page size
	 * Note that this is not the true page size from the detected SPIFI device, but
	 * is actually the size of a single buffer of data that the debugger will send
	 * down to the flash driver. This will normally be 16KB (limited by the available
	 * RAM on the device) but cannot be larger than a single sector.
	 */

	if (FlashDevice.sectors[0].szSector < 16 * 1024)
		FlashDevice.szPage = FlashDevice.sectors[0].szSector;
	else
		FlashDevice.szPage = 16 * 1024; // use 16KB pseudo pages for now

	/* Now use the flash driver mailbox to transfer info on the
	 * updated device back to the host debugger.
	 */

#ifdef NDEBUG
	// Address of flash driver mailbox created by linker script
	// Note that this is skipped for debug builds of the driver
	extern unsigned int _b_mailbox;
	unsigned int *MAILBOX_PTR = &_b_mailbox;
	// Use mailbox 'status' word to pass address of message block
	*(MAILBOX_PTR+4) = (uint32_t)&Mailbox_Init_DynInfo;
#endif
	// Address of FlashDevice structure within driver
	Mailbox_Init_DynInfo.dyn_dev = &FlashDevice;
	// Pointer to string containing name of identified device
	Mailbox_Init_DynInfo.devname = pSpifiHandle->pInfoData->pDeviceData->pDevName;
	// Unused - partID information
	Mailbox_Init_DynInfo.partid_bytes = 0;
	Mailbox_Init_DynInfo.partid = 0;

	// **********************************


	/* turn on memmode on for default */
	spifiDevSetMemMode(pSpifiHandle, true);

	return 0; // Finished without Errors

}

// ************************************

/*  De-Initialize Flash Programming Functions
 *    Parameter:      fnc:  Function Code (1 - Erase, 2 - Program, 3 - Verify)
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t UnInit(void) {

	/* Done, de-init will enter memory mode */
	spifiDevDeInit(pSpifiHandle);

	return 0;                                  // Finished without Errors
}

// ************************************

#if !defined(DONT_PROVIDE_ERASECHIP)
/*  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed */
uint32_t EraseChip(void) {

	SPIFI_ERR_T errCode;
	spifiDevSetMemMode(pSpifiHandle, false);
	errCode = spifiDevEraseAll(pSpifiHandle);
	if (errCode != SPIFI_ERR_NONE)
		return (errCode);

	spifiDevSetMemMode(pSpifiHandle, true);

	return (0);
}
#endif


extern uint32_t checkblank(uint32_t adr, uint32_t words, uint32_t blankval);

// ************************************

/*  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseSectors(uint32_t adr, uint32_t numsecs) {

	SPIFI_ERR_T errCode;
#if !defined (DONT_BLANKCHECK_BEFORE_ERASING)
		uint8_t ch = FlashDevice.valEmpty;
		uint32_t chw = ch | (ch << 8) | (ch << 16) | (ch << 24);
		if  (checkblank(adr,(numsecs * (FlashDevice.sectors[0].szSector/4)), chw ) == 0)
			return (0); // sector blank, so no need to erase
#endif

	spifiDevSetMemMode(pSpifiHandle, false);
	errCode = spifiEraseByAddr(pSpifiHandle, adr, adr + (FlashDevice.sectors[0].szSector * (numsecs -1)));
	if (errCode != SPIFI_ERR_NONE)
		return (errCode);

	spifiDevSetMemMode(pSpifiHandle, true);

	return (0);
}

/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */
// The SPIFI implementation of ProgramPage is really a
// ProgramBufferFull routine. The host debugger will send down
// a buffer full of data (of size FlashDevice.szPage as set up
// in Init() routine, and the spifiProgram() routine will then
// program each page from the buffer in turn. Doing this
// dramatically improves download performance compared to sending
// just a single true page of data at a time to the ProgramPage()
// routine - particularly given the small size of SPIFI flash pages.
uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf) {

	SPIFI_ERR_T errCode;
	spifiDevSetMemMode(pSpifiHandle, false);
	errCode = spifiProgram(pSpifiHandle, adr, (uint32_t *) buf, sz);
	if (errCode != SPIFI_ERR_NONE) return (errCode);

	spifiDevSetMemMode(pSpifiHandle, true);

	return (0);
}

// ************************************
/*
 *  Verify Flash Contents
 *    Parameter:      adr:  Start Address
 *                    sz:   Size (in bytes)
 *                    buf:  Data
 *    Return Value:   0 - OK, Failed - Address
 */
#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t adr,   // Verify Function
		uint32_t sz, uint8_t *buf) {

	uint32_t status = 0;

	if (adr == FlashDevice.DevAdr)		// ignore CRP word
			{
		status = memcmp((void *) adr, buf, 28);
		if (!status)
			status = memcmp((void *) adr + 32, buf + 32, sz - 32);
	} else
		status = memcmp((void *) adr, buf, sz);

	return (status ? IAP_COMPARE_ERROR : 0);

}
#if defined (USE_SMALL_MEMCMP)
int memcmp(const void *a, const void *b, size_t n)
{	const unsigned char *ac = (const unsigned char *)a,
	*bc = (const unsigned char *)b;
	while (n-- > 0)
	{	unsigned char c1,c2; /* unsigned cmp seems more intuitive */
		if ((c1 = *ac++) != (c2 = *bc++)) return c1 - c2;
	}
	return 0;
}
#endif // USE_SMALL_MEMCMP
#endif // DONT_PROVIDE_VERIFY

