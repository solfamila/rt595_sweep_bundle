//*****************************************************************************
// FlashPrg.c
// MCUXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "FlashConfig.h"
#include "lpcx_flash_driver.h"

#include "board.h"
#include "pin_mux.h"

#include "app.h"
#include "xspi_octal_flash_ops.h"

xspi_device_config_t deviceconfig = {
    .flashA1Size          = FLASH_SIZE / 1024,
    .CSHoldTime           = 3,
    .enableDdr            = true,
    .sampleTimeRef        = kXSPI_2xFlashHalfClock,
    .CSSetupTime          = 3,
    .enableWordAddress    = 0,
    .AWRSeqIndex          = 0,
    .ARDSeqIndex          = NOR_CMD_LUT_SEQ_IDX_READ,
    .dllConfig.dllMode    = kXSPI_AutoUpdateMode,
    .xspiRootClk          = 400000000,
};

const uint32_t customLUT[CUSTOM_LUT_LENGTH] = {
    /*Read*/
    [5 * NOR_CMD_LUT_SEQ_IDX_READ] =
        XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0xEE, kXSPI_Command_DDR, kXSPI_8PAD, 0x11),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ + 1] =
        XSPI_LUT_SEQ(kXSPI_Command_RADDR_DDR, kXSPI_8PAD, 0x20, kXSPI_Command_DUMMY_SDR, kXSPI_8PAD, 0x12),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ + 2] =
        XSPI_LUT_SEQ(kXSPI_Command_DUMMY_SDR, kXSPI_8PAD, 0x2, kXSPI_Command_READ_DDR, kXSPI_8PAD, 0x4),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ + 3] =
        XSPI_LUT_SEQ(kXSPI_Command_STOP, kXSPI_8PAD, 0x0, 0, 0, 0),

    /*Read status SPI*/
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_STATUS] =
        XSPI_LUT_SEQ(kXSPI_Command_SDR, kXSPI_1PAD, 0x05, kXSPI_Command_READ_SDR, kXSPI_1PAD, 0x04),

    /* Read Status OPI */
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_STATUS_OPI] =
        XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0x05, kXSPI_Command_DDR, kXSPI_8PAD, 0xFA),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_STATUS_OPI + 1] =
        XSPI_LUT_SEQ(kXSPI_Command_RADDR_DDR, kXSPI_8PAD, 0x20, kXSPI_Command_DUMMY_SDR, kXSPI_8PAD, 0x12),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_STATUS_OPI + 2] =
        XSPI_LUT_SEQ(kXSPI_Command_DUMMY_SDR, kXSPI_8PAD, 0x2, kXSPI_Command_READ_DDR, kXSPI_8PAD, 0x4),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_STATUS_OPI + 3] =
        XSPI_LUT_SEQ(kXSPI_Command_STOP, kXSPI_8PAD, 0x0, 0, 0, 0),

    /*Write enable*/
    [5 * NOR_CMD_LUT_SEQ_IDX_WRITE_ENABLE] =
        XSPI_LUT_SEQ(kXSPI_Command_SDR, kXSPI_1PAD, 0x06, kXSPI_Command_STOP, kXSPI_1PAD, 0x04),

    /* Write Enable - OPI */
    [5 * NOR_CMD_LUT_SEQ_IDX_WRITE_ENABLE_OPI] =
        XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0x06, kXSPI_Command_DDR, kXSPI_8PAD, 0xF9),

    /* Read ID */
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_ID_OPI + 0] = XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0x9F, kXSPI_Command_DDR, kXSPI_8PAD, 0x60),
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_ID_OPI + 1] = XSPI_LUT_SEQ(kXSPI_Command_RADDR_DDR, kXSPI_8PAD, 0x20, kXSPI_Command_DUMMY_SDR, kXSPI_8PAD, 0x04), /*address is 0x00,0x00,0x00,0x00*/
    [5 * NOR_CMD_LUT_SEQ_IDX_READ_ID_OPI + 2] = XSPI_LUT_SEQ(kXSPI_Command_READ_DDR, kXSPI_8PAD, 0x04, kXSPI_Command_STOP, kXSPI_1PAD, 0x0),

    /* Erase Sector */
    [5 * NOR_CMD_LUT_SEQ_IDX_ERASE_SECTOR] =
        XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0x21, kXSPI_Command_DDR, kXSPI_8PAD, 0xDE),
    [5 * NOR_CMD_LUT_SEQ_IDX_ERASE_SECTOR + 1] =
        XSPI_LUT_SEQ(kXSPI_Command_RADDR_DDR, kXSPI_8PAD, 0x20, kXSPI_Command_STOP, kXSPI_8PAD, 0x0),

    /* Enable OPI DDR mode */
    [5 * NOR_CMD_LUT_SEQ_IDX_ENTER_OPI] =
        XSPI_LUT_SEQ(kXSPI_Command_SDR, kXSPI_1PAD, 0x72, kXSPI_Command_SDR, kXSPI_1PAD, 0x00),
    [5 * NOR_CMD_LUT_SEQ_IDX_ENTER_OPI + 1] =
        XSPI_LUT_SEQ(kXSPI_Command_SDR, kXSPI_1PAD, 0x00, kXSPI_Command_SDR, kXSPI_1PAD, 0x00),
    [5 * NOR_CMD_LUT_SEQ_IDX_ENTER_OPI + 2] =
        XSPI_LUT_SEQ(kXSPI_Command_SDR, kXSPI_1PAD, 0x00, kXSPI_Command_WRITE_SDR,  kXSPI_1PAD, 0x01),

    /* Page program */
    [5 * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_OCTAL] =
        XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0x12, kXSPI_Command_DDR, kXSPI_8PAD, 0xED),
    [5 * NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM_OCTAL + 1] =
        XSPI_LUT_SEQ(kXSPI_Command_RADDR_DDR, kXSPI_8PAD, 0x20, kXSPI_Command_WRITE_DDR, kXSPI_8PAD, 0x4),

    /* Erase Chip */
    [5 * NOR_CMD_LUT_SEQ_IDX_ERASE_CHIP] =
        XSPI_LUT_SEQ(kXSPI_Command_DDR, kXSPI_8PAD, 0x60, kXSPI_Command_DDR, kXSPI_8PAD, 0x9F),
};

uint8_t membuf[FLASH_PAGE_SIZE];

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t Init (void)
{
    status_t status;

    // Check these bits to see if Init() has already run
    if (!(SLEEPCON0->RUNCFG & (SLEEPCON0_RUNCFG_PLLLDO_PD_MASK | SLEEPCON0_RUNCFG_PLLANA_PD_MASK)))
        return 0;

    BOARD_InitBootPins();
    BOARD_InitBootClocks();

#if defined (MIMXRT700_XSPI0_Octal) || defined (MIMXRT700_XSPI0_Octal_S)
    BOARD_InitNorFlash0Pins();
    CLOCK_AttachClk(kMAIN_PLL_PFD1_to_XSPI0);
    CLOCK_SetClkDiv(kCLOCK_DivXspi0Clk, 1u);     /*400MHz*/
#elif defined (MIMXRT700_XSPI1_Octal) || defined (MIMXRT700_XSPI1_Octal_S)
    BOARD_InitNorFlash1Pins();
    CLOCK_AttachClk(kMAIN_PLL_PFD2_to_XSPI1);
    CLOCK_SetClkDiv(kCLOCK_DivXspi1Clk, 2u);     /*264MHz*/
#endif
    xspi_nor_flash_init(FLASH_XSPI);

    status = xspi_nor_enable_octal_mode(FLASH_XSPI);
    if (status) return status;

    return 0;
}

/*
 * De-Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  other - failure code
 */

uint32_t UnInit(void)
{
    return 0;
}

/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  other - failure code
 */
#if !defined(DONT_PROVIDE_ERASECHIP)
uint32_t EraseChip(void)
{
    return xspi_nor_erase_chip(FLASH_XSPI);
}
#endif // DONT_PROVIDE_ERASECHIP

/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t EraseSectors(uint32_t addr, uint32_t numsecs)
{
    addr = addr - FLASH_BASE_ADDR;
    for (uint32_t i = 0; i < numsecs; i++) {
        status_t status = xspi_nor_flash_erase_sector(FLASH_XSPI, addr + i * FLASH_SECTOR_SIZE);
        if (status) return status;
    }

    return 0;
}

/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t ProgramPage(uint32_t addr, uint32_t sz, uint8_t *buf)
{
    // This should not happen at least when invoked by IDE, but it could happen when used from cmtool
    if (addr + sz > FLASH_BASE_ADDR + FLASH_SIZE)
    {
        sz = FLASH_SIZE + FLASH_BASE_ADDR - addr;
    }

    addr = addr - FLASH_BASE_ADDR;
    for (uint32_t offset = 0; offset < sz; offset += FLASH_PAGE_SIZE) {
        size_t length = sz - offset > FLASH_PAGE_SIZE ? FLASH_PAGE_SIZE : sz - offset;
        status_t status = xspi_nor_flash_program(FLASH_XSPI, addr + offset, (uint32_t*)(buf + offset), length);
        if (status) return status;
    }

    return 0;
}

/*
 *  Verify Flash Contents
 *    Parameter:      adr:  Start Address
 *                    sz:   Size (in bytes)
 *                    buf:  Data
 *    Return Value:   0 - OK, Failed - Address
 */
#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t addr, uint32_t sz, uint8_t *buf_expected)
{
    for (uint32_t offset = 0; offset < sz; offset += sizeof(membuf)) {
        uint32_t nread = sz - offset >= sizeof(membuf) ? sizeof(membuf) : sz - offset;
        status_t status = xspi_nor_flash_read(FLASH_XSPI, addr - FLASH_BASE_ADDR + offset, (uint32_t*)membuf, nread);
        if (status) return status;

        if (memcmp(membuf, buf_expected + offset, nread)) {
            return -1;
        }
    }
    return 0;
}
#endif // DONT_PROVIDE_VERIFY

/*
 *  Checksum Sector Contents in Flash Memory
 *    Parameter:      adr:  Sector Address
 *                    numsecs: Number of sectors
 *                    data:  checksum data
 *    Return Value:   0 - OK,  1 - Failed
 *
 * 32 bit Fowler/Noll/Vo FNV-1a hash code
    http://en.wikipedia.org/wiki/Fowler_Noll_Vo_hash
 */
#define FNV1_32_INIT    0x811c9dc5
#define FNV1_32_PRIME   0x01000193
uint32_t ChecksumSectors(uint32_t adr, uint32_t numsecs, ChecksumData_t *data)
{
    uint32_t *results = (uint32_t *)&data->results;
    data->algID = FCHECKSUM_FNV1A_32;

    for (uint32_t i = 0; i < numsecs; i++)
    {
        uint32_t hash = FNV1_32_INIT;
        uint32_t size = FLASH_SECTOR_SIZE;
        uint32_t read_adr = adr - FLASH_BASE_ADDR + i * size;
        uint8_t *p = membuf;

        while (size > 0)
        {
            if ((uint32_t)(p - membuf) % sizeof(membuf) == 0)
            {
                // buffer exhausted - read a new one
                if (xspi_nor_flash_read(FLASH_XSPI, read_adr, (uint32_t*)membuf, sizeof(membuf)))
                {
                    return 1;
                }
                p = (uint8_t *)membuf;
                read_adr += sizeof(membuf);
            }

            hash ^= (uint32_t)*p++;
            hash *= FNV1_32_PRIME;
            size--;
        }
        results[i] = hash;
    }

    return 0;
}
