MIMXRT1050-EcoXiP_ATXP032 Flash Driver LinkServer/CMSIS-DAP Flash Driver
========================================================================

This MCUXpresso IDE LinkServer/CMSIS-DAP flash driver example 
is based on the 'evkbimxrt1050_flexspi_nor_polling_transfer' example
from the SDK v2.4.0 EVKB-MIMXRT1050 package with the addition of code
supplied by Adesto.

July 2018:

Initial implementation creates a single driver
'MIMXRT1050-EcoXiP_ATXP032.cfx' compatible with the ATXP032 device.

Requirements for Building
=========================

The use of MCUXpresso IDE v10.2.0 or later is required for building
this project.

The project is created for a Generic (Cortex) M7 MCU and so generated
code will be compatible with the iMXRT MCUs. This also removes any
requirement for a specific SDK to be installed for use.

The LPCXFlashDriverLib project must also be imported into the flash
driver project's workspace. For correct linkage ensure that both debug
and release variants of this project must be manually pre-built.

This driver project uses example and board support code from the SDK
EVKB-IMXRT1050. If an iMXRT10xx flash driver is required for a different
board, then appropriate board files will need to be updated. 


Build Configurations
==================== 
 
There are two build configurations within the project:

'Debug'
-------
This build configuration can be used to generate a test
version of the flash driver that can be run within the MCUXPresso IDE
debug environment. This configuration builds the flash driver wrapped by
an interface that mimics the interface used by MCUXpresso IDE when
programming a project executable/binary into flash.

This configuration can be very useful when adding support for a new
flash device, to ensure that basic operation works, before trying out
the full flash driver.

'MIMXRT1050-EcoXiP_ATXP032'
---------------------------
This creates the actual driver 'MIMXRT1050-EcoXiP_ATXP032.cfx' in a 
project directory called 'builds'

Linker Scripts
==============

This project forgoes the use of automatic managed linkerscript
generation due its special requirements for image layout.

Instead a directory containing a linker script per build configuration
is supplied. These linker scripts builds link both configurations to use
on-chip SRAM RAM at 0x20000000 and assume 64KB is available.

Launch Configurations
=====================

As supplied a single launch configuration is included for the debug
build configuration. This file contains a single non default setting
within the 'additional options' entry of '--nopacked'. This setting is
required to ensure the debug interface on this MCU is accessed
appropriately, without this, printf characters may not display correctly
within the console output. Should this launch configuration be deleted,
a new one will be re-generated automatically on the next debug
operation. However, the '--nopacked' must be manually added.



