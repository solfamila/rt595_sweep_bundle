/*
 * @brief NXP LPCXpresso LPC54607 board file
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __BOARD_H_
#define __BOARD_H_

#include "chip.h"
/* board_api.h is included at the bottom of this file after DEBUG setup */

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup BOARD_LPCXPRESSO_54607 LPC54607 LPCXpresso LQFP board support software API functions
 * @ingroup LPCOPEN_5410X_BOARD_LPCXPRESSO_54607
 * The board support software API functions provide some simple abstracted
 * functions used across multiple LPCOpen board examples. See @ref BOARD_COMMON_API
 * for the functions defined by this board support layer.<br>
 * @{
 */

/** @defgroup BOARD_LPCXPRESSO_54607_OPTIONS BOARD: LPC54607 LPCXpresso LQFP board build options
 * This board has options that configure its operation at build-time.<br>
 * @{
 */

/** Define DEBUG_ENABLE to enable IO via the DEBUGSTR, DEBUGOUT, and
    DEBUGIN macros. If not defined, DEBUG* functions will be optimized
    out of the code at build time.
 */
#define DEBUG_ENABLE

/* Use RMII for ethernet */
#define USE_RMII

/** Define DEBUG_SEMIHOSTING along with DEBUG_ENABLE to enable IO support
    via semihosting. You may need to use a C library that supports
    semihosting with this option.
 */
// #define DEBUG_SEMIHOSTING

/** Board UART used for debug output and input using the DEBUG* macros. This
    is also the port used for Board_UARTPutChar, Board_UARTGetChar, and
    Board_UARTPutSTR functions. Although you can setup multiple UARTs here,
    the board code only supports UART0 in the Board_UART_Init() function,
    so be sure to change it there too if not using UART0.
 */
#define DEBUG_UART                      LPC_USART0
#define USART0_FLEXCOMM                 0

/** Bit rate for the debug UART in Hz */
#define DEBUGBAUDRATE       (115200)

/** Main system clock rate in Hz for this board. Select a clock rate between
    1500000Hz and 150000000Hz for the main system (CPU) clock for this board. */
#define BOARD_MAINCLOCKRATE     (96000000)

/**
 * @brief	Default power mode for the board to operate at
 * @note When frequency is > 48MHz set it to #POWER_HIGH_PERFORMANCE, when
 * frequency is 12 MHz #POWER_LOW_POWER_MODE can be used, for 48MHz use
 * #POWER_BALANCED_MODE.
 */
#define BOARD_POWERMODE         POWER_HIGH_PERFORMANCE

/** External clock rate on the CLKIN pin in Hz for this board. If not used,
    set this to 0. Otherwise, set it to the exact rate in Hz this pin is
    being driven at. */
#define BOARD_EXTCLKINRATE      (0)

/** Set the BOARD_USECLKINSRC definition to (1) to use the external clock
    input pin as the PLL source. The BOARD_ECTCLKINRATE definition must
    be setup with the correct rate in the CLKIN pin. Set this to (0) to
    use the IRC for the PLL source. */
#define BOARD_USECLKINSRC       (0)

/**
 * @brief	Initialize the LCD Controller pin muxes
 * @return	Nothing
 */
void Board_LCD_Init(void);

/**
 * @brief	Initialize the SDIO controller pin muxes
 * @return	Nothing
 */
void Board_SDIO_Init(void);

#define Board_SDMMC_Init   Board_SDIO_Init

/**
 * @brief	Initialize the Ethernet pin muxes
 * @return	Nothing
 */
void Board_Ethernet_Init(void);

/**
 * @brief	Initialize the Touch Controller
 * @return	Nothing
 */
void Board_InitTouchController(void);

/**
 * @brief	Get Touch position, if there is no touch 0 is returned
 * @param 	x	:The X coordinate of touch
 * @param 	y	:The Y coordinate of touch
 * @return	Nothing
 */
void Board_GetTouchPos(int16_t *x, int16_t *y);
/**
 * @}
 */

/* Board name */
#define BOARD_NXP_EVAL_54607

/** Board version definition, supports LQFP version of the board */
#define BOARD_REV1_LQFP

/**
 * Default LCD configuration for this board
 */
extern const LCD_CONFIG_T RK043_LCD;

#define BOARD_LCD      RK043_LCD

/**
 * @}
 */

#include "board_api.h"

#ifdef __cplusplus
}
#endif

#endif /* __BOARD_H_ */
