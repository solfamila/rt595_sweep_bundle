// Copyright 2012 Code Red Technologies Limited
// Copyright 2020, 2021 NXP
/***********************************************************************
 * $Id: type.h 8313 2011-10-14 22:30:17Z nxp21346 $
 *
 * Project: LPC18xx Common
 *
 * Description:
 *	Type definition Header file for NXP LPC1800 Family
 *  Microprocessors
 *
 ***********************************************************************
 * SPDX-License-Identifier: BSD-3-Clause
 **********************************************************************/

#ifndef __TYPE_H__
#define __TYPE_H__

#ifndef NULL
#define NULL    ((void *)0)
#endif

#ifndef FALSE
#define FALSE   (0)
#endif

#ifndef TRUE
#define TRUE    (1)
#endif

#define ABS(value)	(value<0 ? -value : value)

/**
 * @brief Flag Status and Interrupt Flag Status type definition
 */
typedef enum {RESET = 0, SET = !RESET} FlagStatus, IntStatus, SetState;
#define PARAM_SETSTATE(State) ((State==RESET) || (State==SET))

/**
 * @brief Functional State Definition
 */
typedef enum {DISABLE = 0, ENABLE = !DISABLE} FunctionalState;
#define PARAM_FUNCTIONALSTATE(State) ((State==DISABLE) || (State==ENABLE))

/**
 * @ Status type definition
 */
typedef enum {ERROR = 0, SUCCESS = !ERROR} Status;

typedef unsigned char  BYTE;
typedef unsigned short WORD;
typedef unsigned long  DWORD;
typedef unsigned int   BOOL;

typedef union _BITS
{
	unsigned char value;
	struct _bits
	{
		unsigned char bit0:1;
		unsigned char bit1:1;
		unsigned char bit2:1;
		unsigned char bit3:1;
		unsigned char bit4:1;
		unsigned char bit5:1;
		unsigned char bit6:1;
		unsigned char bit7:1;
	}bits;
}BITS;

#endif  /* __TYPE_H__ */
