/*
 * @brief FPU init code
 *
 * @note
 * Copyright 2012, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __FPU_INIT_H_
#define __FPU_INIT_H_

/**
 * @defgroup CHIP_FPU_CMX CHIP: FPU initialization
 * @ingroup CHIP_Common
 * Cortex FPU initialization
 * @{
 */

/**
 * @brief	Early initialization of the FPU
 * @return	Nothing
 */
void fpuInit(void);

/**
 * @}
 */

#endif /* __FPU_INIT_H_ */
