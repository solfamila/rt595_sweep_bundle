/*
 * @brief RTC tick to (a more) Universal Time
 * Adds conversion functions to use an RTC that only provides a
 * seconds capability to provide "struct tm" support.
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __RTC_UT_H_
#define __RTC_UT_H_

#include "chip.h"
#include <stdlib.h>
#include <time.h>

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup RTC_UT CHIP: RTC tick to (a more) Universal Time conversion functions
 * @ingroup CHIP_Common
 * This driver converts between a RTC 1-second tick value and
 * a Universal time format in a structure of type 'struct tm'.
 * @{
 */

/* Starting year and starting day of week for the driver */
#define TM_YEAR_BASE    (1900)
#define TM_DAYOFWEEK    (1)

/**
 * @brief	Converts a RTC tick time to Universal time
 * @param	rtcTick	: Current RTC time value
 * @param	pTime	: Pointer to time structure to fill
 * @return	Nothing
 * @note	When setting time, the 'tm_wday', 'tm_yday', and 'tm_isdst'
 * fields are not used.
 */
void ConvertRtcTime(uint32_t rtcTick, struct tm *pTime);

/**
 * @brief	Converts a Universal time to RTC tick time
 * @param	pTime	: Pointer to time structure to use
 * @param	rtcTick	: Pointer to RTC time value to fill
 * @return	Nothing
 * @note	When converting time, the 'tm_isdst' field is not
 * populated by the conversion function.
 */
void ConvertTimeRtc(const struct tm *pTime, uint32_t *rtcTick);

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __RTC_UT_H_ */
