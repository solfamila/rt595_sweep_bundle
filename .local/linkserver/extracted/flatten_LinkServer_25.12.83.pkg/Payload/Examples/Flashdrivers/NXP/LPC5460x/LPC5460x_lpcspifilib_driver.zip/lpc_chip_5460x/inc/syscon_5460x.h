/*
 * @brief LPC5460X System & Control driver inclusion file
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __SYSCON_5460X_H_
#define __SYSCON_5460X_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup SYSCON_5460X CHIP: LPC5460X System and Control Driver
 * @ingroup CHIP_5460X_DRIVERS
 * @{
 */

/**
 * @brief LPC5460X Main system configuration register block structure
 */
typedef struct {
	__I  uint32_t RESERVED0[4];
	__IO uint32_t AHBMATPRIO;           /*!< AHB Martix priority register */
	__I  uint32_t RESERVED1[11];
	__IO uint32_t SYSTCKCAL;			/*!< System Tick Calibration register */
	__I  uint32_t RESERVED2[1];
	__IO uint32_t NMISRC;				/*!< NMI Source select register */
	__IO uint32_t ASYNCAPBCTRL;			/*!< Asynch APB chiplet control register */
	__I  uint32_t RESERVED3[28];
	__I  uint32_t PIOPORCAP[2];         /*!< Power on Reset; port capture register */
	__I  uint32_t RESERVED4[2];
	__I  uint32_t PIORESCAP[2];         /*!< Reset; port capture register */
	__I  uint32_t RESERVED5[10];
	__IO uint32_t PRESETCTRL[3];		/*!< Peripheral Reset control */
	__I  uint32_t RESERVED6[5];
	__O  uint32_t PRESETCTRLSET[3];     /*!< Peripheral Reset Control set */
	__I  uint32_t RESERVED7[5];
	__O  uint32_t PRESETCTRLCLR[3];     /*!< Peripheral Reset Control set */
	__I  uint32_t RESERVED8[41];
	__IO uint32_t SYSRSTSTAT;			/*!< System Reset Stat register */
	__I  uint32_t RESERVED9[3];
	__IO uint32_t AHBCLKCTRL[3];        /*!< AHB Peripheral Clk Enable register */
	__I  uint32_t RESERVED10[5];
	__O  uint32_t AHBCLKCTRLSET[3];     /*!< AHB Peripheral Clk Enable Set register */
	__I  uint32_t RESERVED11[5];
	__O  uint32_t AHBCLKCTRLCLR[3];     /*!< AHB Peripheral Clk Enable Clr register */
	__I  uint32_t RESERVED12[13];
	__IO uint32_t MAINCLKSELA;			/*!< Main Clk sel Source Sel A register */
	__IO uint32_t MAINCLKSELB;			/*!< Main Clk sel Source Sel B register */
	__IO uint32_t CLKOUTSELA;			/*!< Clk Out Sel Source B register */
	__I  uint32_t RESERVED13;
	__IO uint32_t SYSPLLCLKSEL;			/*!< System PLL Clk Selregister */
	__I  uint32_t RESERVED14[1];
	__IO uint32_t AUDPLLCLKSEL;			/*!< Audio PLL Clk Selregister */
	__I  uint32_t RESERVED15[1];
	__IO uint32_t SPIFICLKSEL;          /*!< SPIFI clock selection register */
	__IO uint32_t ADCCLKSEL;			/*!< ADC Async Clk Sel register */
	__IO uint32_t USB0CLKSEL;			/*!< USB0 Clk Sel register */
	__IO uint32_t USB1CLKSEL;           /*!< USB1 Clock select register */
	__IO uint32_t FXCOMCLKSEL[10];       /*!< FlexCOM CLK sel register */
	__I  uint32_t RESERVED16[2];
	__IO uint32_t MCLKCLKSEL;           /*!< MCLK Clock select register */
	__I  uint32_t RESERVED16A;
	__IO uint32_t FRGCLKSEL;            /*!< FRG Clock select register */
	__IO uint32_t DMICCLKSEL;           /*!< DMIC Clock select register */
	__IO uint32_t SCTCLKSEL;            /*!< SCT Clock select register */
	__IO uint32_t LCDCLKSEL;            /*!< LCD Controller clock select register */
	__IO uint32_t SDIOCLKSEL;           /*!< SDIO Clock select register */
	__I  uint32_t RESERVED17;
	__IO uint32_t SYSTICKCLKDIV;		/*!< Systick Clock divider register */
    __IO uint32_t ARMTRCLKDIV;	    	/*!< ARM Trace Clock divider register */
    __IO uint32_t CAN0CLKDIV;		    /*!< CAN0 Clock divider register */
    __IO uint32_t CAN1CLKDIV;		    /*!< CAN1 Clock divider register */
    __IO uint32_t SC0CLKDIV;		    /*!< Smart Card 0 Clock divider register */
    __IO uint32_t SC1CLKDIV;		    /*!< Smart Card 1 Clock divider register */
	__I  uint32_t RESERVED18[26];
	__IO uint32_t AHBCLKDIV;            /*!< AHB Clock divider */
	__IO uint32_t CLKOUTDIV;            /*!< CLKOUT divider */
    __IO uint32_t FROHFCLKDIV;          /*!< FRO HF Clock divider */
	__I  uint32_t RESERVED19[1];
	__IO uint32_t SPIFICLKDIV;          /*!< SPIFI clock divider register */
	__IO uint32_t ADCCLKDIV;            /*!< ADC Clock divider register */
	__IO uint32_t USB0CLKDIV;           /*!< USB 0 Clock divider register */
	__IO uint32_t USB1CLKDIV;           /*!< USB 1 Clock divider register */
	__IO uint32_t FRGCTRL;				/*!< Fraction Rate Generator Ctrl register */
	__I  uint32_t RESERVED21;
	__IO uint32_t DMICCLKDIV;            /*!< DMIC Clock divider register */
	__IO uint32_t MCLKDIV;               /*!< I2S MClock divider register */
	__IO uint32_t LCDCLKDIV;             /*!< LCD Controller Clock divide */
	__IO uint32_t SCTCLKDIV;             /*!< SCT/PWM Clock divide */
	__IO uint32_t EMCCLKDIV;             /*!< EMC Clock divide */
	__IO uint32_t SDIOCLKDIV;            /*!< SDIO Clock Divide */
	__I  uint32_t RESERVED22[16];
	__IO uint32_t FLASHCFG;              /*!< Flash wait state configuration register */
	__I  uint32_t RESERVED23[2];
	__IO uint32_t USB0CLKCTRL;           /*!< USB Clock control register */
	__IO uint32_t USB0CLKSTAT;           /*!< USB Clock Status register */
	__I  uint32_t RESERVED24;
	__IO uint32_t FREQMECTRL;            /*!< Frequency measure register */
	__I  uint32_t RESERVED25;
	__IO uint32_t MCLKIO;                /*!< MCLK Input Output register */
  __IO uint32_t USB1CLKCTRL;           /*!< USB1 Clock Control register */
  __IO uint32_t USB1CLKSTAT;           /*!< USB1 Clock Status register */
	__I  uint32_t RESERVED261[6];
    __IO uint32_t EMCSYSCTRL;            /*!< EMC System Control register */
    __IO uint32_t EMCDLYCTRL;            /*!< EMC Clock Delay Control register */
    __IO uint32_t EMCDLYCAL;             /*!< EMC Clock Delay Chain Calibration register */
    __IO uint32_t ETHPHYSEL;             /*!< Ethernet Phy Selection register */
    __IO uint32_t ETHSBDCTRL;            /*!< Ethernet SBD Flow Control register */
    __I  uint32_t RESERVED262[2];
    __IO uint32_t SDIOCLKCTRL;           /*!< SDIO Clock Control register */
    __I  uint32_t RESERVED263[39];
	__IO uint32_t FROCTRL;               /*!< FRO oscillator control register */
	__IO uint32_t SYSOSCCTRL;            /*!< System oscillator control register */
	__IO uint32_t WDTOSCCTRL;            /*!< Watchdog Oscillator control */
	__IO uint32_t RTCOSCCTRL;            /*!< RTC Oscillator control register */
	__I  uint32_t RESERVED28[3];
	__IO uint32_t USBPLLCTRL;            /*!< USB PLL control register */
	__I  uint32_t USBPLLSTAT;            /*!< USB PLL status register */
	__I  uint32_t RESERVED29[23];
	__IO uint32_t SYSPLLCTRL;            /*!< System PLL control register */
	__I  uint32_t SYSPLLSTAT;            /*!< System PLL status register */
	__IO uint32_t SYSPLLNDEC;            /*!< System PLL N-DEC register */
	__IO uint32_t SYSPLLPDEC;            /*!< System PLL P-DEC register */
	__IO uint32_t SYSPLLMDEC;
	__I  uint32_t RESERVED30[3];
	__IO uint32_t AUDPLLCTRL;            /*!< Audio PLL control register */
	__I  uint32_t AUDPLLSTAT;            /*!< Audio PLL status register */
	__IO uint32_t AUDPLLNDEC;            /*!< Audio PLL N-DEC register */
	__IO uint32_t AUDPLLPDEC;            /*!< Audio PLL P-DEC register */
	__IO uint32_t AUDPLLMDEC;       	 /*!< Audio PLL M-DEC register */
	__IO uint32_t AUDPLLFRAC;      		 /*!< Audio PLL Fractional divider control register */
	__I  uint32_t RESERVED31[22];
	__IO uint32_t PDRUNCFG[2];           /*!< Power Down configuration registers */
	__I  uint32_t RESERVED32[2];
	__O  uint32_t PDRUNCFGSET[2];        /*!< Power down configuartion set register */
	__I  uint32_t RESERVED33[2];
	__O  uint32_t PDRUNCFGCLR[2];        /*!< Power down configuartion clear register */
	__I  uint32_t RESERVED34[18];
	__IO uint32_t STARTERP[2];           /*!< Start logic wakeup enable register */
	__I  uint32_t RESERVED35[6];
	__O  uint32_t STARTERPSET[2];        /*!< Start logic wakeup enable set register */
	__I  uint32_t RESERVED36[6];
	__O  uint32_t STARTERPCLR[2];        /*!< Start logic wakeup enable clear register */
	__I  uint32_t RESERVED37[46];
	__IO uint32_t HWWAKE;                /*!< Special Hardware Wake register */
	__I  uint32_t RESERVED38[540];
	__I  uint32_t JTAGIDCODE;            /*!< JTAG ID Code register */
	__I  uint32_t DEVICE_ID[2];           /*!< Device ID Registers */
} LPC_SYSCON_T;

/**
 * @brief LPC5460X Asynchronous system configuration register block structure
 */
typedef struct {
	__IO uint32_t AYSNCPRESETCTRL;		/*!< peripheral reset register */
	__O  uint32_t ASYNCPRESETCTRLSET;	/*!< peripheral reset Set register */
	__O  uint32_t ASYNCPRESETCTRLCLR;	/*!< peripheral reset Clr register */
	__I  uint32_t RESERVED0;
	__IO uint32_t ASYNCAPBCLKCTRL;		/*!< clk enable register */
	__IO uint32_t ASYNCAPBCLKCTRLSET;	/*!< clk enable Set register */
	__IO uint32_t ASYNCAPBCLKCTRLCLR;	/*!< clk enable Clr register */
	__I  uint32_t RESERVED1;
	__IO uint32_t ASYNCAPBCLKSELA;		/*!< clk source mux A register */
} LPC_ASYNC_SYSCON_T;


/**
 * @brief	FROCTRL register bits
 */
#define SYSCON_FROCTRL_MASK            ((1 << 15) | (0xF << 26))  /**< MASK for reserved bits in FROCTRL register */
#define SYSCON_FROCTRL_WRTRIM          (1UL << 31)   /**< Enable Writes to FROCTRL register */
#define SYSCON_FROCTRL_HSPDCLK         (1UL << 30)   /**< High speed clock (FROHF) enable bit */
#define SYSCON_FROCTRL_USBMODCHG       (1UL << 25)   /**< When set Trim value is pending to be set by SOF from USB */
#define SYSCON_FROCTRL_USBCLKADJ       (1UL << 24)   /**< Automatically adjust FRO trim value based on SOF from USB */
#define SYSCON_FROCTRL_SEL96MHZ        (1UL << 14)   /**< When set FROHF will be 96MHz; else FROHF will be 48MHz */


/**
 * @brief	Set System tick timer calibration value
 * @param	sysCalVal	: System tick timer calibration value
 * @return	Nothing
 */
__STATIC_INLINE void Chip_SYSCON_SetSYSTCKCAL(uint32_t sysCalVal)
{
	LPC_SYSCON->SYSTCKCAL = sysCalVal;
}

/**
 * Non-Maskable Interrupt Enable/Disable value
 */
#define SYSCON_NMISRC_M0_ENABLE   ((uint32_t) 1 << 30)	/*!< Enable the Non-Maskable Interrupt M0 (NMI) source */
#define SYSCON_NMISRC_M4_ENABLE   ((uint32_t) 1 << 31)	/*!< Enable the Non-Maskable Interrupt M4 (NMI) source */

/**
 * @brief	Set source for non-maskable interrupt (NMI)
 * @param	intsrc	: IRQ number to assign to the NMI
 * @return	Nothing
 * @note	The NMI source will be disabled upon exiting this function. Use the
 * Chip_SYSCON_EnableNMISource() function to enable the NMI source.
 */
void Chip_SYSCON_SetNMISource(uint32_t intsrc);

/**
 * @brief	Enable interrupt used for NMI source
 * @return	Nothing
 */
void Chip_SYSCON_EnableNMISource(void);

/**
 * @brief	Disable interrupt used for NMI source
 * @return	Nothing
 */
void Chip_SYSCON_DisableNMISource(void);

/**
 * @brief	Enable or disable asynchronous APB bridge and subsystem
 * @param	enable	: true to enable, false to disable
 * @return	Nothing
 * @note	This bridge must be enabled to access peripherals on the
 * associated bridge.
 */
void Chip_SYSCON_Enable_ASYNC_Syscon(bool enable);

/**
 * @brief	Set UART Fractional divider value
 * @param	fmul	: Fractional multiplier value
 * @param	fdiv	: Fractional divider value (Must always be 0xFF)
 * @return	Nothing
 */
__STATIC_INLINE void Chip_SYSCON_SetUSARTFRGCtrl(uint8_t fmul, uint8_t fdiv)
{
	LPC_SYSCON->FRGCTRL = ((uint32_t) fmul << 8) | fdiv;
}

/**
 * System reset status values
 */
#define SYSCON_RST_POR    (1 << 0)	/*!< POR reset status */
#define SYSCON_RST_EXTRST (1 << 1)	/*!< External reset status */
#define SYSCON_RST_WDT    (1 << 2)	/*!< Watchdog reset status */
#define SYSCON_RST_BOD    (1 << 3)	/*!< Brown-out detect reset status */
#define SYSCON_RST_SYSRST (1 << 4)	/*!< software system reset status */

/**
 * @brief	Get system reset status
 * @return	An Or'ed value of SYSCON_RST_*
 * @note	This function returns the detected reset source(s).
 */
__STATIC_INLINE uint32_t Chip_SYSCON_GetSystemRSTStatus(void)
{
	return LPC_SYSCON->SYSRSTSTAT;
}

/**
 * @brief	Clear system reset status
 * @param	reset	: An Or'ed value of SYSCON_RST_* status to clear
 * @return	Nothing
 * @note	This function clears the specified reset source(s).
 */
__STATIC_INLINE void Chip_SYSCON_ClearSystemRSTStatus(uint32_t reset)
{
	LPC_SYSCON->SYSRSTSTAT = reset;
}

/**
 * Peripheral reset identifiers
 */
typedef enum {
	/* Peripheral reset enables for PRESETCTRL0 */
	RESET_FLASH = 7,                /*!< Flash Controller */
	RESET_FMC,                      /*!< Flash Accelerator */
	RESET_EEPROM,                   /*!< EEPROM */
	RESET_SPIFI = 10,               /*!< SPIFI Reset */
	RESET_MUX,                      /*!< IO MUX Reset */
	RESET_IOCON = 13,               /*!< IOCON Reset */
	RESET_GPIO0,                    /*!< GPIO Port-0 Reset */
	RESET_GPIO1,                    /*!< GPIO Port-1 Reset */
	RESET_GPIO2,                    /*!< GPIO Port-2 Reset */
	RESET_GPIO3,                    /*!< GPIO Port-3 Reset */
	RESET_PINT = 18,                /*!< Pin Interrupt Reset */
	RESET_GINT,                     /*!< Group Interrupt Reset */
	RESET_DMA,                      /*!< DMA Reset */
	RESET_CRC,                      /*!< CRC Engine Reset */
	RESET_WWDT,                     /*!< Windowed watchdog timer */
	RESET_ADC = 27,                 /*!< ADC Reset */
	RESET_ADC0 = 27,                /*!< ADC Reset */

	/* Peripheral reset enables for PRESETCTRL1 */
	RESET_MRT = 32,                 /*!< Multirate Timer */
	RESET_OSTIMER,                  /*!< OSTimer Reset */
	RESET_SCT0,                     /*!< State configurable Timer */
	RESET_CAN0 = 32 + 7,            /*!< CAN0 Reset */
	RESET_CAN1,                     /*!< CAN1 Reset */
	RESET_UTICK = 32 + 10,          /*!< Micro Tick Timer */
	RESET_FLEXCOMM0,                /*!< FlexComm 0 */
	RESET_FLEXCOMM1,                /*!< FlexComm 1 */
	RESET_FLEXCOMM2,                /*!< FlexComm 2 */
	RESET_FLEXCOMM3,                /*!< FlexComm 3 */
	RESET_FLEXCOMM4,                /*!< FlexComm 4 */
	RESET_FLEXCOMM5,                /*!< FlexComm 5 */
	RESET_FLEXCOMM6,                /*!< FlexComm 6 */
	RESET_FLEXCOMM7,                /*!< FlexComm 7 */
	RESET_DMIC,                     /*!< Digital MIC */
	RESET_TIMER2 = 32 + 22,         /*!< Timer2 Reset */
	RESET_USBD0 = 32 + 25,                    /*!< USB0 Device Reset */
	RESET_TIMER0,                   /*!< Timer0 Reset */
	RESET_TIMER1,                   /*!< Timer1 Reset */

	/* Peripheral clock enables for SYSAHBCLKCTRL2 */
	RESET_LCD = 64 + 2,          /*!< LCD Controller Reset */
	RESET_SDIO,                  /*!< SDIO Reset */
	RESET_USB1_HOST,             /*!< USB1 Host Reset */
	RESET_USBD1,                 /*!< USB1 Device Reset */
	RESET_USB1_RAM,              /*!< USB1 RAM Reset */
	RESET_EMC,                   /*!< External Memory Controller Reset */
	RESET_ETHERNET,              /*!< Ethernet Reset */
	RESET_GPIO4,                 /*!< GPIO4 Reset */
	RESET_GPIO5,                 /*!< GPIO5 Reset */
	RESET_AES,                   /*!< AES Reset */
	RESET_OTP,                   /*!< OTP Reset */
	RESET_RNG,                   /*!< Random number generator Reset */
	RESET_FLEXCOMM8,             /*!< Flexcomm 8 Reset */
	RESET_FLEXCOMM9,             /*!< Flexcomm 9 Reset */
	RESET_USB0_HOST_M,           /*!< USB0 Host Reset */
	RESET_USB0_HOST_S,           /*!< USB0 Host Reset */
	RESET_HASH,                  /*!< HASH engine Reset */
	RESET_SMARTCARD0,            /*!< Smartcard 0 Reset */
	RESET_SMARTCARD1,            /*!< Smartcard 1 Reset */

	/* Async peripheral reset enables for ASYNCPRESETCTRL */
	RESET_TIMER3 = 128 + 13,		/*!< TIMER0 */
	RESET_TIMER4,					/*!< TIMER4 Reset*/
} CHIP_SYSCON_PERIPH_RESET_T;

#define RESET_SCT    RESET_SCT0
#define RESET_USB    RESET_USBD0

/**
 * @brief	Resets a peripheral
 * @param	periph	:	Peripheral to reset (See #CHIP_SYSCON_PERIPH_RESET_T)
 * @return	Nothing
 * Will assert and de-assert reset for a peripheral.
 */
__STATIC_INLINE void Chip_SYSCON_PeriphReset(CHIP_SYSCON_PERIPH_RESET_T periph)
{
	uint32_t val = (uint32_t) periph;
	if (val < 128) {
		LPC_SYSCON->PRESETCTRLSET[val >> 5] = 1 << (val & 31);
	} else {
		LPC_ASYNC_SYSCON->ASYNCPRESETCTRLSET = 1 << (val - 128);
	}

	__NOP();
	__NOP();
	__NOP();
	__NOP();

	if (val < 128) {
		LPC_SYSCON->PRESETCTRLCLR[val >> 5] = 1 << (val & 31);
	} else {
		LPC_ASYNC_SYSCON->ASYNCPRESETCTRLCLR = 1 << (val - 128);
	}
}

/**
 * @brief	Read POR captured PIO status
 * @param	port	: 0 for port 0 pins, 1 for port 1 pins, 2 for port 2 pins, etc.
 * @return	captured Power-On-Reset (POR) PIO status
 */
__STATIC_INLINE uint32_t Chip_SYSCON_GetPORPIOStatus(uint8_t port)
{
	return LPC_SYSCON->PIOPORCAP[port];
}

/**
 * @brief	Read reset captured PIO status
 * @param	port	: 0 for port 0 pins, 1 for port 1 pins, 2 for port 2 pins, etc.
 * @return	captured reset PIO status
 * @note	Used when reset other than a Power-On-Reset (POR) occurs.
 */
__STATIC_INLINE uint32_t Chip_SYSCON_GetResetPIOStatus(uint8_t port)
{
	return LPC_SYSCON->PIORESCAP[port];
}

/**
 * @brief	Starts a frequency measurement cycle
 * @return	Nothing
 * @note	This function is meant to be used with the Chip_INMUX_SetFreqMeasRefClock()
 * and Chip_INMUX_SetFreqMeasTargClock() functions.
 */
__STATIC_INLINE void Chip_SYSCON_StartFreqMeas(void)
{
	LPC_SYSCON->FREQMECTRL = 0;
	LPC_SYSCON->FREQMECTRL = (1UL << 31);
}

/**
 * @brief	Indicates when a frequency measurement cycle is complete
 * @return	true if a measurement cycle is active, otherwise false
 */
__STATIC_INLINE bool Chip_SYSCON_IsFreqMeasComplete(void)
{
	return (bool) ((LPC_SYSCON->FREQMECTRL & (1UL << 31)) == 0);
}

/**
 * @brief	Returns the raw capture value for a frequency measurement cycle
 * @return	raw cpature value (this is not a frequency)
 */
__STATIC_INLINE uint32_t Chip_SYSCON_GetRawFreqMeasCapval(void)
{
	return LPC_SYSCON->FREQMECTRL & 0x3FFF;
}

/**
 * @brief	Returns the computed value for a frequency measurement cycle
 * @param	refClockRate	: Reference clock rate used during the frequency measurement cycle
 * @return	Computed cpature value
 */
uint32_t Chip_SYSCON_GetCompFreqMeas(uint32_t refClockRate);

/**
 * @brief FLASH Access time definitions
 */
typedef enum {
	SYSCON_FLASH_1CYCLE = 0,	/*!< Flash accesses use 1 CPU clock */
	FLASHTIM_20MHZ_CPU = SYSCON_FLASH_1CYCLE,
	SYSCON_FLASH_2CYCLE,		/*!< Flash accesses use 2 CPU clocks */
	SYSCON_FLASH_3CYCLE,		/*!< Flash accesses use 3 CPU clocks */
	SYSCON_FLASH_4CYCLE,		/*!< Flash accesses use 4 CPU clocks */
	SYSCON_FLASH_5CYCLE,		/*!< Flash accesses use 5 CPU clocks */
	SYSCON_FLASH_6CYCLE,		/*!< Flash accesses use 6 CPU clocks */
	SYSCON_FLASH_7CYCLE,		/*!< Flash accesses use 7 CPU clocks */
	SYSCON_FLASH_8CYCLE,		/*!< Flash accesses use 8 CPU clocks */
	SYSCON_FLASH_9CYCLE,		/*!< Flash accesses use 9 CPU clocks */
	SYSCON_FLASH_10CYCLE		/*!< Flash accesses use 10 CPU clocks */
} SYSCON_FLASHTIM_T;

/**
 * @brief	Set FLASH memory access time in clocks
 * @param	clks	: Clock cycles for FLASH access
 * @return	Nothing
 */
__STATIC_INLINE void Chip_SYSCON_SetFLASHAccess(SYSCON_FLASHTIM_T clks)
{
	uint32_t tmp;

	tmp = LPC_SYSCON->FLASHCFG & ~(0xF << 12);

	/* Don't alter lower bits */
	LPC_SYSCON->FLASHCFG = tmp | ((uint32_t) clks << 12);
}

/**
 * Power control definition bits (0 = powered, 1 = powered down)
 */
#define SYSCON_PDRUNCFG_PD_FRO           (1 << 4)		/*!< FRO oscillator */
#define SYSCON_PDRUNCFG_PD_FLASH         (1 << 5)		/*!< Flash memory */
#define SYSCON_PDRUNCFG_PD_TS            (1 << 6)		/*!< Temperature Sensor */
#define SYSCON_PDRUNCFG_PD_BOD_RST       (1 << 7)		/*!< Brown-out Detect reset */
#define SYSCON_PDRUNCFG_PD_BOD_INTR      (1 << 8)		/*!< Brown-out Detect interrupt */
#define SYSCON_PDRUNCFG_PD_VD2_ANA       (1 << 9)		/*!< Analog supply for analog modules */
#define SYSCON_PDRUNCFG_PD_ADC0          (1 << 10)		/*!< ADC0 */
#define SYSCON_PDRUNCFG_PD_SRAMX         (1 << 13)		/*!< SRAMX */
#define SYSCON_PDRUNCFG_PD_SRAM0         (1 << 14)		/*!< SRAM0 */
#define SYSCON_PDRUNCFG_PD_SRAM1         (1 << 15)		/*!< SRAM1 */
#define SYSCON_PDRUNCFG_PD_USB_RAM       (1 << 16)		/*!< USB RAM */
#define SYSCON_PDRUNCFG_PD_ROM           (1 << 17)		/*!< ROM */
#define SYSCON_PDRUNCFG_PD_VDDA_ENA      (1 << 19)		/*!< Vdda to the ADC, must be enabled for the ADC to work */
#define SYSCON_PDRUNCFG_PD_WDT_OSC       (1 << 20)		/*!< Watchdog oscillator */
#define SYSCON_PDRUNCFG_PD_USB_PHY       (1 << 21)      /*!< USB Phy */
#define SYSCON_PDRUNCFG_PD_SYS_PLL       (1 << 22)		/*!< PLL0 */
#define SYSCON_PDRUNCFG_PD_VREFP         (1 << 23)		/*!< Vrefp to the ADC, must be enabled for the ADC to work */
#define SYSCON_PDRUNCFG_PD_32K_OSC       (1 << 24)		/*!< 32 kHz RTC oscillator */
#define SYSCON_PDRUNCFG_PD_FLASH_BG      (1 << 25)
#define SYSCON_PDRUNCFG_PD_VD3           (1 << 26)
#define SYSCON_PDRUNCFG_PD_VD4           (1 << 27)
#define SYSCON_PDRUNCFG_PD_VD5           (1 << 28)
#define SYSCON_PDRUNCFG_PD_VD6           (1 << 29)

#define SYSCON_PDRUNCFG_PD_USB1PHY       ((uint64_t)1 << (32 + 0))		/*!< USB1 PHY */
#define SYSCON_PDRUNCFG_PD_USBPLL        ((uint64_t)1 << (32 + 1))		/*!< USB PLL */
#define SYSCON_PDRUNCFG_PD_AUDPLL        ((uint64_t)1 << (32 + 2))		/*!< Audio PLL */
#define SYSCON_PDRUNCFG_PD_SYSOSC        ((uint64_t)1 << (32 + 3))		/*!< Sys Osc */
#define SYSCON_PDRUNCFG_PD_EEPROM        ((uint64_t)1 << (32 + 5))		/*!< EEPROM */
#define SYSCON_PDRUNCFG_PD_RNG	         ((uint64_t)1 << (32 + 7))		/*!< Random Number Generator */

/* FIXME: above 64 bit is not preferred definition, but, some APIs have been using it. Fix later. */
#define SYSCON_PDRUNCFG1_PD_USB1PHY      (1 << 0)		/*!< USB1 PHY */
#define SYSCON_PDRUNCFG1_PD_USBPLL       (1 << 1)		/*!< USB PLL */
#define SYSCON_PDRUNCFG1_PD_AUDPLL       (1 << 2)		/*!< Audio PLL */
#define SYSCON_PDRUNCFG1_PD_SYSOSC       (1 << 3)		/*!< Sys Osc */
#define SYSCON_PDRUNCFG1_PD_EEPROM       (1 << 5)		/*!< EEPROM */
#define SYSCON_PDRUNCFG1_PD_RNG	         (1 << 7)		/*!< Random Number Generator */

/**
 * @brief	Power up one or more blocks or peripherals
 * @return	OR'ed values of SYSCON_PDRUNCFG_* values
 * @note	A high state indicates the peripheral is powered down.
 */
__STATIC_INLINE uint32_t Chip_SYSCON_GetPowerStates(void)
{
	return LPC_SYSCON->PDRUNCFG[0];
}

/**
 * @brief	Power down one or more blocks or peripherals
 * @param	powerdownmask	: OR'ed values of SYSCON_PDRUNCFG_* values
 * @return	Nothing
 */
__STATIC_INLINE void Chip_SYSCON_PowerDown(uint64_t powerdownmask)
{
	/* Disable peripheral states by setting high */
	LPC_SYSCON->PDRUNCFGSET[0] = powerdownmask;
	LPC_SYSCON->PDRUNCFGSET[1] = powerdownmask >> 32;
}

/**
 * @brief	Power up one or more blocks or peripherals
 * @param	powerupmask	: OR'ed values of SYSCON_PDRUNCFG_* values
 * @return	Nothing
 */
void Chip_SYSCON_PowerUp(uint64_t powerupmask);

/**
 * Start enable enumerations - for enabling and disabling peripheral wakeup
 */
typedef enum {
	SYSCON_STARTER_WWDT_BOD = 0,
	SYSCON_STARTER_DMA,
	SYSCON_STARTER_GINT0,
	SYSCON_STARTER_GINT1,
	SYSCON_STARTER_PINT0,
	SYSCON_STARTER_PINT1,
	SYSCON_STARTER_PINT2,
	SYSCON_STARTER_PINT3,
	SYSCON_STARTER_UTICK,
	SYSCON_STARTER_MRT,
	SYSCON_STARTER_TIMER0,
	SYSCON_STARTER_TIMER1,
	SYSCON_STARTER_SCT0,
	SYSCON_STARTER_TIMER3,
	SYSCON_STARTER_FLEXCOMM0,
	SYSCON_STARTER_FLEXCOMM1,
	SYSCON_STARTER_FLEXCOMM2,
	SYSCON_STARTER_FLEXCOMM3,
	SYSCON_STARTER_FLEXCOMM4,
	SYSCON_STARTER_FLEXCOMM5,
	SYSCON_STARTER_FLEXCOMM6,
	SYSCON_STARTER_FLEXCOMM7,
	SYSCON_STARTER_ADC0_SEQA,
	SYSCON_STARTER_ADC0_SEQB,
	SYSCON_STARTER_ADC0_THCMP,
	SYSCON_STARTER_DMIC,
	SYSCON_STARTER_HWVAD,
	SYSCON_STARTER_USB0NEEDCLK,
	SYSCON_STARTER_USB0,
	SYSCON_STARTER_RTC,
	SYSCON_STARTER_RESERVED0,
	SYSCON_STARTER_MAILBOX,
	SYSCON_STARTER_PINT4 = 32,
	SYSCON_STARTER_PINT5,
	SYSCON_STARTER_PINT6,
	SYSCON_STARTER_PINT7,
	SYSCON_STARTER_TIMER2,
	SYSCON_STARTER_TIMER4,
	SYSCON_STARTER_FLEXCOMM8 = 40,
	SYSCON_STARTER_FLEXCOMM9,
	SYSCON_STARTER_USB1 = 47,
	SYSCON_STARTER_USB1NEEDCLK,
	SYSCON_STARTER_ENET1,
	SYSCON_STARTER_ENET2,
	SYSCON_STARTER_ENET0,
	SYSCON_STARTER_SC0 = 55,
	SYSCON_STARTER_SC1,
} CHIP_SYSCON_WAKEUP_T;

/**
 * @brief	Enables a pin's (PINT) wakeup logic
 * @param	periphId	: Peripheral identifier (See #CHIP_SYSCON_WAKEUP_T)
 * @return	Nothing
 */
__STATIC_INLINE void Chip_SYSCON_EnableWakeup(CHIP_SYSCON_WAKEUP_T periphId)
{
	LPC_SYSCON->STARTERPSET[(uint32_t) periphId >> 5] = 1 << ((uint32_t) periphId & 31);
}

/**
 * @brief	Disables peripheral's wakeup logic
 * @param	periphId	: Peripheral identifier
 * @return	Nothing
 */
__STATIC_INLINE void Chip_SYSCON_DisableWakeup(CHIP_SYSCON_WAKEUP_T periphId)
{
	LPC_SYSCON->STARTERPCLR[(uint32_t) periphId >> 5] = 1 << ((uint32_t) periphId & 31);
}

/**
 * @brief	Return the pointer to device ID registers
 * @return	Pointer to device ID registers
 */
__STATIC_INLINE uint32_t Chip_SYSCON_GetDeviceID(void)
{
	return LPC_SYSCON->DEVICE_ID[0];
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __SYSCON_5460X_H_ */
