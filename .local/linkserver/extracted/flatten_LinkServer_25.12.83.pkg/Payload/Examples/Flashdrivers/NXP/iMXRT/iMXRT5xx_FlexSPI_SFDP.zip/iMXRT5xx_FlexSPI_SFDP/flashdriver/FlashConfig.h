//*****************************************************************************
// FlashConfig.h
// MCUXpresso IDE Flash driver
// Config file for i.MX RT500 (rev A0 & B0) FlexSPI SFDP based drivers
//*****************************************************************************
//
// Copyright 2020-2021, 2024 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#ifndef FLASHCONFIG_H_
#define FLASHCONFIG_H_

#include "bl_api.h"

extern flexspi_nor_config_t flashConfig;

#if defined (DEBUG)
#define MIMXRT500_SFDP_MXIC_OSPI
#endif


// RT500 User Manual
// Chapter 18 : Non-Secure Boot ROM
// 18.6.1 : Serial NOR Flash through FlexSPI
// 18.6.1.3 : FlexSPI NOR Configuration Option Block

#if defined (MIMXRT500_SFDP_MXIC_OSPI) || defined (MIMXRT500_SFDP_MXIC_OSPI_S)
/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 4   : device_type (4 = Macronix Octal DDR)
 * 0   : query_pads (0 = 1 data pad during query)
 * 3   : cmd_pads (3 = 8 data pads during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 4   : max_freq
 */
// 0xc0403004 - but changed to single bit mode, not octal
#define CONFIG_OPTION0  0xc0400004

#elif defined (MIMXRT500_SFDP_QSPI) || defined (MIMXRT500_SFDP_QSPI_S)
/*
 * 0xC : tag
 * 0   : option_size (0 = option1 not specified)
 * 0   : device_type (0 = Read SFDP for SDR commands)
 * 0   : query_pads (0 = 1 data pad during query)
 * 0   : cmd_pads (0 = 1 data pad during flash access)
 * 0   : quad_mode_setting (0 = not configured)
 * 0   : misc_mode
 * 4   : max_freq
 */
#define CONFIG_OPTION0  0xc0000000

#else
#error #error "No driver defined"
#endif

#define CONFIG_OPTION1  0x0


// =====================================
// Flash Base Address Information
// =====================================

#define TRUE_FLASH_BASE_ADDR 0x08000000

#if defined (MIMXRT500_SFDP_MXIC_OSPI_S) || defined (MIMXRT500_SFDP_QSPI_S)
#define USE_SECURE_FLASHADDR
#define FLASH_BASE_ADDR 0x18000000
#else
#define FLASH_BASE_ADDR 0x08000000
#endif


#endif /* FLASHCONFIG_H_ */
