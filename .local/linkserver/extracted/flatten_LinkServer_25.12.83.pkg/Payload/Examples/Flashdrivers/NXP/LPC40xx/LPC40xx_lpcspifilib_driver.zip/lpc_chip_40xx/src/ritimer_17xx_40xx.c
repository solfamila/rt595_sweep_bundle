/*
 * @brief LPC17xx/40xx RITimer driver
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

#if defined(CHIP_LPC175X_6X)

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Initialize the RIT */
void Chip_RIT_Init(LPC_RITIMER_T *pRITimer)
{
	Chip_Clock_EnablePeriphClock(SYSCTL_CLOCK_RIT);
	pRITimer->COMPVAL = 0xFFFFFFFF;
	pRITimer->MASK  = 0x00000000;
	pRITimer->CTRL  = 0x0C;
	pRITimer->COUNTER   = 0x00000000;
}

/* DeInitialize the RIT */
void Chip_RIT_DeInit(LPC_RITIMER_T *pRITimer)
{
	Chip_RIT_Init(pRITimer);
	Chip_Clock_DisablePeriphClock(SYSCTL_CLOCK_RIT);
}

/* Set timer interval value */
void Chip_RIT_SetTimerInterval(LPC_RITIMER_T *pRITimer, uint32_t time_interval)
{
	uint32_t cmp_value;

	/* Determine aapproximate compare value based on clock rate and passed interval */
	cmp_value = (Chip_Clock_GetPeripheralClockRate(SYSCTL_PCLK_RIT) / 1000) * time_interval;

	/* Set timer compare value */
	Chip_RIT_SetCOMPVAL(pRITimer, cmp_value);

	/* Set timer enable clear bit to clear timer to 0 whenever
	   counter value equals the contents of RICOMPVAL */
	Chip_RIT_EnableCTRL(pRITimer, RIT_CTRL_ENCLR);
}

/* Check whether interrupt is pending */
IntStatus Chip_RIT_GetIntStatus(LPC_RITIMER_T *pRITimer)
{
	uint8_t result;

	if ((pRITimer->CTRL & RIT_CTRL_INT) == 1) {
		result = SET;
	}
	else {
		return RESET;
	}

	return (IntStatus) result;
}

#endif /* defined(CHIP_LPC175X_6X) */
