/*
 * @brief LPC5460X Chip specific SystemInit
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/* Sets the best FLASH clock arte for the passed frequency */
static void setupFlashClocks(uint32_t freq)
{
	if (freq <= 12000000) {
		Chip_SYSCON_SetFLASHAccess(SYSCON_FLASH_1CYCLE);
	}
	else if (freq <= 30000000) {
		Chip_SYSCON_SetFLASHAccess(SYSCON_FLASH_2CYCLE);
	}
	else if (freq <= 60000000) {
		Chip_SYSCON_SetFLASHAccess(SYSCON_FLASH_3CYCLE);
	}
	else if (freq <= 85000000) {
		Chip_SYSCON_SetFLASHAccess(SYSCON_FLASH_4CYCLE);
	} 
	else if (freq <= 100000000) {
		Chip_SYSCON_SetFLASHAccess(SYSCON_FLASH_5CYCLE);
	} 
	else {
		/* from 100MHz up to 180MHz, all use 6 WS, (cycle = WS + 1). */
		Chip_SYSCON_SetFLASHAccess(SYSCON_FLASH_7CYCLE);
	}
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Set FRO Clocking */
void Chip_SetupFROClocking(uint32_t iFreq)
{
	if (iFreq != SYSCON_FRO12MHZ_FREQ && iFreq != SYSCON_FRO48MHZ_FREQ &&
			iFreq != SYSCON_FRO96MHZ_FREQ) {
		return;
	}
	/* Power up the FRO and set this as the base clock */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_FRO);

	/* Use 12MHz FRO as the default base clock */
	Chip_Clock_SetMainClockSource(SYSCON_MAINCLKSRC_FRO12MHZ);
	setupFlashClocks(iFreq); /* Set Flash wait states */

	/* ASYSNC SYSCON needs to be on or all serial peripheral won't work.
	   Be careful if PLL is used or not, ASYNC_SYSCON source needs to be
	   selected carefully. */
	Chip_SYSCON_Enable_ASYNC_Syscon(true);
	Chip_Clock_SetAsyncSysconClockSource(SYSCON_ASYNC_FRO12MHZ);

	if (iFreq <= SYSCON_FRO12MHZ_FREQ) {
		return;
	}
	Chip_Clock_SetFROHFRate(iFreq);
	Chip_Clock_SetMainClockSource(SYSCON_MAINCLKSRC_FROHF);
}

/* Clock and PLL initialization based on the internal oscillator */
void Chip_SetupIrcClocking(uint32_t iFreq)
{
	PLL_CONFIG_T pllConfig;
	PLL_SETUP_T pllSetup;
	PLL_ERROR_T pllError;

	/* Power up the FRO and set this as the base clock */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_FRO);

	/* Till the PLL is Up use 12MHz FRO as the base clock */
	Chip_Clock_SetMainClockSource(SYSCON_MAINCLKSRC_FRO12MHZ);

	/* ASYSNC SYSCON needs to be on or all serial peripheral won't work.
	   Be careful if PLL is used or not, ASYNC_SYSCON source needs to be
	   selected carefully. */
	Chip_SYSCON_Enable_ASYNC_Syscon(true);
	Chip_Clock_SetAsyncSysconClockSource(SYSCON_ASYNC_FRO12MHZ);

	/* Setup FLASH access */
	setupFlashClocks(iFreq);

	/* Select the PLL input to the IRC */
	Chip_Clock_SetSystemPLLSource(SYSCON_PLLCLKSRC_FRO12MHZ);

	/* Power down PLL to change the PLL divider ratio */
	Chip_SYSCON_PowerDown(SYSCON_PDRUNCFG_PD_SYS_PLL);

	/* VD3 needs to be powered up too for use of PLL. */
	Chip_SYSCON_PowerUp(SYSCON_PDRUNCFG_PD_VD3);

#if USE_ROM_PLL_API
	/* temporary solution, try the ROM driver, integer divider on the nearest multiplier for now. 
	please note: in Chip_POWER_SetPLL(), output freq = integer Multiply by input frequency. 
	e.g. if iFreq is set to 100MHz, but input freq is 12MHz, integer multiplier results
	output clock = 12 * 8 = 96MHz. */
	Chip_POWER_SetPLL((uint32_t)(iFreq/SYSCON_FRO12MHZ_FREQ), SYSCON_FRO12MHZ_FREQ);
#else
	/* Setup PLL configuration */
	pllConfig.desiredRate = iFreq;
	pllConfig.InputRate = SYSCON_FRO12MHZ_FREQ;
	pllError = Chip_Clock_SetupPLLData(&pllConfig, &pllSetup);
	if (pllError == PLL_ERROR_SUCCESS) {
		pllSetup.flags = PLL_SETUPFLAG_WAITLOCK | PLL_SETUPFLAG_ADGVOLT;
		pllError = Chip_Clock_SetupSystemPLLPrec(&pllSetup);
	}
#endif
	
	/* Set system clock divider to 1 */
	Chip_Clock_SetSysClockDiv(1);

	/* Set main clock source to the system PLL. This will drive 24MHz
	   for the main clock and 24MHz for the system clock */
	Chip_Clock_SetMainClockSource(SYSCON_MAINCLKSRC_PLLOUT);
}

/* Clock and PLL initialization based on the external clock input */
void Chip_SetupExtInClocking(uint32_t iFreq)
{
	PLL_CONFIG_T pllConfig;
	PLL_SETUP_T pllSetup;
	PLL_ERROR_T pllError;

	/* IOCON clock left on, this is needed is CLKIN is used. */
	Chip_Clock_EnablePeriphClock(SYSCON_CLOCK_IOCON);

	/* Select external clock input pin */
	Chip_IOCON_PinMuxSet(LPC_IOCON, 0, 22, (IOCON_MODE_PULLUP |
											IOCON_FUNC1 | IOCON_DIGITAL_EN | IOCON_INPFILT_OFF));

	/* Till the PLL is Up use CLKIN as the clock source */
	Chip_Clock_SetMainClockSource(SYSCON_MAINCLKSRC_CLKIN);

	/* Select the PLL input to the EXT clock input */
	Chip_Clock_SetSystemPLLSource(SYSCON_PLLCLKSRC_CLKIN);

	/* Setup FLASH access */
	setupFlashClocks(iFreq);

	/* Power down PLL to change the PLL divider ratio */
	Chip_SYSCON_PowerDown(SYSCON_PDRUNCFG_PD_SYS_PLL);

	/* Setup PLL configuration */
	pllConfig.desiredRate = iFreq;
	pllConfig.InputRate = SYSCON_FRO12MHZ_FREQ;
	pllError = Chip_Clock_SetupPLLData(&pllConfig, &pllSetup);
	if (pllError == PLL_ERROR_SUCCESS) {
		pllSetup.flags = PLL_SETUPFLAG_WAITLOCK | PLL_SETUPFLAG_ADGVOLT;
		pllError = Chip_Clock_SetupSystemPLLPrec(&pllSetup);
	}

	/* Set system clock divider to 1 */
	Chip_Clock_SetSysClockDiv(1);

	/* Set main clock source to the system PLL. This will drive 24MHz
	   for the main clock and 24MHz for the system clock */
	Chip_Clock_SetMainClockSource(SYSCON_MAINCLKSRC_PLLOUT);

	/* ASYSNC SYSCON needs to be on or all serial peripheral won't work.
	   Be careful if PLL is used or not, ASYNC_SYSCON source needs to be
	   selected carefully. */
	Chip_SYSCON_Enable_ASYNC_Syscon(true);
	Chip_Clock_SetAsyncSysconClockSource(SYSCON_ASYNC_FRO12MHZ);
}

/* Set up and initialize hardware prior to call to main */
void Chip_SystemInit(void)
{
	/* Initial internal clocking @100MHz */
	Chip_SetupIrcClocking(100000000);
}
