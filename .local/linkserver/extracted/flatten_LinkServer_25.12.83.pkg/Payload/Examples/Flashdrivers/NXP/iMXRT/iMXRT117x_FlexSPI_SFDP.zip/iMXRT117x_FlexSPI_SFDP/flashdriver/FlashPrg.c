//*****************************************************************************
// FlashPrg.c
//
// MCUXpresso IDE flash driver - Flash Programming Functions
//
// i.MX RT1160/RT1170/RT1180 FlexSPI SFDP based drivers
//
//*****************************************************************************
//
// Copyright 2020-2025 NXP
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include <stdint.h>
// For memcmp used in Verify()
#include <string.h>
#include "bl_api.h"
#include "lpcx_flash_driver.h"
#include "FlashConfig.h"

Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;

#define MEM_WriteU32(addr, value)  (*((volatile uint32_t *)(addr)) = (value))
#define MEM_ReadU32(addr)          (*(volatile uint32_t *)(addr))

uint32_t versionMajor;

flexspi_nor_config_t flashConfig;
serial_nor_config_option_t configOption;

const uint32_t RstEn[4] = {
	FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x66, STOP, FLEXSPI_1PAD, 0x00)
};
const uint32_t Rst[4] = {
	FLEXSPI_LUT_SEQ(CMD_SDR, FLEXSPI_1PAD, 0x99, STOP, FLEXSPI_1PAD, 0x00)
};


// ************************************
// Flash driver functions
// ************************************

/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  1 - Failed
 */

uint32_t Init(void)
{
	status_t status;
	uint32_t CPUID = MEM_ReadU32(0xE000ED00);

	// Disable I- and D-cache
	if ((CPUID & 0xFFF0) == 0xD210) // M33
	{
		/* disable XCACHE Code/System Cache */
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");

		uint32_t pxcr = MEM_ReadU32(0x54400000);
		if (pxcr & 1)
		{
			// XCACHE_PC->CCR - Invalidate (GO | INV0/1)
			MEM_WriteU32(0x54400000, 0x85000000 | pxcr);
			while(MEM_ReadU32(0x54400000) & 0x80000000)
				;
			// disable cache
			MEM_WriteU32(0x54400000, 0x0);

		}
		pxcr = MEM_ReadU32(0x54400800);
		if (pxcr & 1)
		{
			// XCACHE_PS->CCR - Invalidate (GO | INV0/1)
			MEM_WriteU32(0x54400800, 0x85000000 | pxcr);
			while(MEM_ReadU32(0x54400800) & 0x80000000)
				;
			// disable cache
			MEM_WriteU32(0x54400800, 0x0);
		}
	}
	else if ((CPUID & 0xFFF0) == 0xC270) // M7
	{
		// SCB->CSSELR = 0U;
		MEM_WriteU32(0xe000ed84, 0);
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");
		//SCB->CCR &= ~(uint32_t)SCB_CCR_DC/IC_Msk;  /* disable D/I-Cache */
		MEM_WriteU32(0xe000ed14, MEM_ReadU32(0xe000ed14) & 0xFFFE7FFF);
		// SCB->ICIALLU = 0UL;                       /* invalidate I-Cache */
		MEM_WriteU32(0xe000ef50, 0);
	}
	else // M4
	{
		/* disable LMEM Code/System Cache */
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");

		uint32_t pxcr = MEM_ReadU32(0xe0082000);
		if (pxcr & 1)
		{
			// LMEM->PCCCR - clean (push & invalidate) (GO | INV0/1 | PUSH0/1)
			MEM_WriteU32(0xe0082000, 0x8F000000 | pxcr);
			while(MEM_ReadU32(0xe0082000) & 0x80000000)
				;
			// disable cache, write buffer, no alloc, WT
			MEM_WriteU32(0xe0082000, 0x0000000C);

		}
		pxcr = *((volatile uint32_t *)0xe0082800);
		if (pxcr & 1)
		{
			// LMEM->PSCCR - clean (push & invalidate) (GO | INV0/1 | PUSH0/1)
			MEM_WriteU32(0xe0082800, 0x8F000000 | pxcr);
			while(MEM_ReadU32(0xe0082800) & 0x80000000)
				;
			// disable cache, write buffer, no alloc, WT
			MEM_WriteU32(0xe0082800, 0x0000000C);
		}
	}
	__asm volatile ("dsb 0xF":::"memory");
	__asm volatile ("isb 0xF":::"memory");

#if defined (MIMXRT1170_SFDP_MXIC_OPI) || defined (MIMXRT1160_SFDP_MXIC_OPI) || defined (MIMXRT1170_SFDP_MICRON_OPI)
	// ****************
	// Reset external flash via GPIO

	// The problem with the external flash reset is that the actual pin
	// that is being used is board-specific: RT1170-EVK boards use GPIO_AD_03,
	// but custom boards can use anything!
	// Please update this section accordingly

	// GPIO_AD_03 -> routed to GPIO port 9, pin 2
	#define PIN_MASK (1 << 2)

	// Enable clock to IOMUX (LPCG49)
	uint32_t lpcg = MEM_ReadU32(0x40cc6620);
	if (!(lpcg & 1))
	{
		// CCM->LPCG49 = EN (IOMUX)
		MEM_WriteU32(0x40cc6620, (lpcg | 1));
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");
	}

	// Enable clock to GPIO_9 (LPCG51)
	lpcg = MEM_ReadU32(0x40cc6660);
	if (!(lpcg & 1))
	{
		// CCM->LPCG51 = EN (GPIO_9)
		MEM_WriteU32(0x40cc6660, (lpcg | 1));
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");
	}

	// Disable interrupt GPIO9->IMR &= ~(1 << pin)
	uint32_t imr = MEM_ReadU32(0x40c64014);
	MEM_WriteU32(0x40c64014, imr & ~PIN_MASK);
	// Set DIR (output) GPIO9->GDIR |= (1 << pin);
	uint32_t dir = MEM_ReadU32(0x40c64004);
	MEM_WriteU32(0x40c64004, dir | PIN_MASK);
	// Drive high GPIO9->DR_SET = (1 << pin);
	MEM_WriteU32(0x40c64084, PIN_MASK);

	// Route to GPIO IOMUX->SW_MUX_CTL_PAD_GPIO_AD_03 = 0xA (ALT10 - GPIO9_IO02)
	MEM_WriteU32(0x400e8118, 0xa);

#if defined MIMXRT1170_SFDP_MXIC_OPI
	// Note for RT1170-EVK boards (populated with MXIC octal flash):
	// GPIO_AD_03 is 3.3V and Octal flash is 1.8V,
	// but RT1170-EVK lacks a voltage shift buffer
	// As a workaround, set the pin to OD mode
	// GPIO IOMUX->SW_PAD_CTL_PAD_GPIO_AD_03 = 0x12 (ODE|DSE)
	MEM_WriteU32(0x400e835c, 0x12);
	// EVKB boards (populated with MICRON octal flash) do not have the problem mentioned above
#endif

	// Toggle GPIO9->DR_TOGGLE = (1 << pin);
	MEM_WriteU32(0x40c6408c, PIN_MASK);
	// Delay some time to reset external flash
	for (uint32_t i = 0; i < 60000; i++)
		__asm volatile ("nop");
	// Toggle GPIO9->DR_TOGGLE = (1 << pin);
	MEM_WriteU32(0x40c6408c, PIN_MASK);
	// ****************
#endif

#if defined (MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI) || defined (MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI) || \
	defined (MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S) || defined (MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI_S) || \
	defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI) || defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI) || \
	defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S) || defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S) || \
	defined (MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI) || defined (MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI) || \
	defined (MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S) || defined (MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI_S) || \
	defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI) || defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI) || \
	defined (MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S) || defined (MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S)
	// ****************
	// Reset external flash via GPIO

	// The problem with the external flash reset is that the actual pin
	// that is being used is board-specific: RT1180(-144) EVK boards use GPIO_AD_15,
	// but custom boards can use anything!
	// Please update this section accordingly

	// GPIO_AD_15 -> routed to GPIO port 4, pin 15
	#define PIN (15)
	#define PIN_MASK (1 << PIN)

	// Enable clock to IOMUX1/2 (LPCG43/44)
	uint32_t lpcg = MEM_ReadU32(0x44458AC0);
	if (!(lpcg & 1))
	{
		// CCM->LPCG43 = EN (IOMUX)
		MEM_WriteU32(0x44458AC0, (lpcg | 1));
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");
	}
	lpcg = MEM_ReadU32(0x44458B00);
	if (!(lpcg & 1))
	{
		// CCM->LPCG44 = EN (IOMUX)
		MEM_WriteU32(0x44458B00, (lpcg | 1));
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");
	}

	// Enable clock to GPIO4 (LPCG48)
	lpcg = MEM_ReadU32(0x44458C00);
	if (!(lpcg & 1))
	{
		// CCM->LPCG48 = EN (GPIO4)
		MEM_WriteU32(0x44458C00, (lpcg | 1));
		__asm volatile ("dsb 0xF":::"memory");
		__asm volatile ("isb 0xF":::"memory");
	}

	// Disable interrupt GPIO4->ICR15 = 0
	MEM_WriteU32(0x43830080 + (PIN * 4), 0x0);

	// Drive high GPIO4->PSOR = (1 << pin);
	MEM_WriteU32(0x43830044, PIN_MASK);

	// Set DIR (output) GPIO4->PDDR |= (1 << pin);
	uint32_t dir = MEM_ReadU32(0x43830054);
	MEM_WriteU32(0x43830054, dir | PIN_MASK);

	// Route to GPIO IOMUX->SW_MUX_CTL_PAD_GPIO_AD_15 = 0x5 (ALT5 - GPIO4_IO15)
	MEM_WriteU32(0x42a10148, 0x5);

	// Toggle GPIO4->PTOR = (1 << pin);
	MEM_WriteU32(0x4383004c, PIN_MASK);
	// Delay some time to reset external flash
	for (uint32_t i = 0; i < 60000; i++)
		__asm volatile ("nop");
	// Toggle GPIO4->PTOR = (1 << pin);
	MEM_WriteU32(0x4383004c, PIN_MASK);
	// ****************
#endif

	INIT_VERSION_MAJOR;

	configOption.option0.U = CONFIG_OPTION0;
	configOption.option1.U = CONFIG_OPTION1;

	/* Reset external flash to ensure the ROM API work fine.
	 * But do it only if the controller is enabled! */
	if ((IS_FLEXSPI_ENABLED) &&
		(configOption.option0.B.device_type < 2))
	{
		/* Update LUT 8/9 */
		flexspi_update_lut(FLEXSPI_NOR_INSTANCE, 8, RstEn, 1);
		flexspi_update_lut(FLEXSPI_NOR_INSTANCE, 9, Rst, 1);
		/* Prepare transfer context */
		flexspi_xfer_t flashXfer = {
			kFlexSpiOperation_Command, 0, 8, 1, false, NULL, 0, NULL, 0
		};
		/* Transfer command 0x66 */
		flexspi_command_xfer(FLEXSPI_NOR_INSTANCE, &flashXfer);
		flashXfer.seqId = 9;
		/* Transfer command 0x99 */
		flexspi_command_xfer(FLEXSPI_NOR_INSTANCE, &flashXfer);
	}

	memset((void*)&flashConfig, 0U, sizeof(flexspi_nor_config_t));

	status = flexspi_nor_get_config(FLEXSPI_NOR_INSTANCE, &flashConfig, &configOption);
	if (status) {
		return status;
	}

	status = flexspi_nor_flash_init(FLEXSPI_NOR_INSTANCE, &flashConfig);
	if (status) {
		return status;
	}

	// **********************************
	// Now update the FlashDevice table using the settings for the
	// detected SPIFI device. These new values will be read back by
	// the debugger upon return from Init()
	// **********************************

	// Update FlashDevice base address based on the core it executes
	// CM4 uses alias (where possible), otherwise use FlexSPI address;
	FlashDevice.DevAdr = ((CPUID & 0xFFF0) == 0xC240)
							? FLASH_BASE_ADDR_CM4
							: FLASH_BASE_ADDR;

	// Update FlashDevice device size
#if defined(PORT_B)
	FlashDevice.szDev = flashConfig.memConfig.sflashB1Size;
#else
	FlashDevice.szDev = flashConfig.memConfig.sflashA1Size;
#endif

	// Update FlashDevice sector size - currently hard wired
	// Note: SPIFI devices are assumed to only support a single size
#if defined(NO_BLOCKS)
	FlashDevice.sectors[0].szSector = flashConfig.sectorSize;
#else
	FlashDevice.sectors[0].szSector = flashConfig.blockSize;
#endif

	// Update FlashDevice page size
	// Note that this is not the true page size from the detected SPIFI device, but
	// is actually the size of a single buffer of data that the debugger will send
	// down to the flash driver. This will normally be 16KB (limited by the available
	// RAM on the device) but cannot be larger than a single sector.

	if (FlashDevice.sectors[0].szSector < 16 * 1024)
		FlashDevice.szPage = FlashDevice.sectors[0].szSector;
	else
		FlashDevice.szPage = 16 * 1024; // use 16KB pseudo pages for now

	// Now use the flash driver mailbox to transfer info on the
	// updated device back to the host debugger.

#ifdef NDEBUG
	// Address of flash driver mailbox created by linker script
	// Note that this is skipped for debug builds of the driver
	extern unsigned int _b_mailbox;
	unsigned int *MAILBOX_PTR = &_b_mailbox;
	// Use mailbox 'status' word to pass address of message block
	*(MAILBOX_PTR + 4) = (uint32_t)&Mailbox_Init_DynInfo;
#endif
	// Address of FlashDevice structure within driver
	Mailbox_Init_DynInfo.dyn_dev = &FlashDevice;

	// Pointer to string containing name of identified device

	// Ideally this should be the JEDEC ID, but no obvious way to get this
	Mailbox_Init_DynInfo.devname = FlashDevice.DevName;

	// Unused - partID information
	Mailbox_Init_DynInfo.partid_bytes = 0;
	Mailbox_Init_DynInfo.partid = 0;


	return 0; // Finished without Errors
}

uint32_t UnInit(void)
{
#if defined(MIMXRT1180_SFDP_FlexSPI1_A_QSPI) || defined(MIMXRT1180_SFDP_FlexSPI1_B_QSPI) || \
    defined(MIMXRT1180_SFDP_FlexSPI1_A_QSPI_S) || defined(MIMXRT1180_SFDP_FlexSPI1_B_QSPI_S) || \
	defined(MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI) || \
	defined(MIMXRT1180_SFDP_FlexSPI1_A_MXIC_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MXIC_OPI_S) || \
	defined(MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI) || \
	defined(MIMXRT1180_SFDP_FlexSPI1_A_MICRON_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI1_B_MICRON_OPI_S) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI) || defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_A_QSPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_B_QSPI_S) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_A_QSPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_B_QSPI_S) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MXIC_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MXIC_OPI_S) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI) || \
	defined(MIMXRT1180_SFDP_FlexSPI2_PriGr_AB_MICRON_OPI_S) || defined(MIMXRT1180_SFDP_FlexSPI2_SecGr_AB_MICRON_OPI_S)
	// Force TCM ECC preloading
	// MEM_WriteU32(0x54460078, 0x46464646);
#else
	// Clear SRC->GPR[9]
	// Without this setting, when programming an erased flash, the bootrom fails
	// to boot the newly programmed image via post-flash SYSRESETREQ.
	MEM_WriteU32(0x40C04038, 0x0);
#endif

	return 0;                                  // Finished without Errors
}

#if !defined(DONT_PROVIDE_ERASECHIP)
/*  Erase complete Flash Memory
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseChip(void)
{
	status_t status = 0;

	status = flexspi_nor_flash_erase_all(FLEXSPI_NOR_INSTANCE, &flashConfig);

	return status;
}

#endif

/*  Erase Sectors in Flash Memory
 *    Parameter:      adr:  Sector Start Address
 *                    numsecs: number of sectors to erase
 *    Return Value:   0 - OK,  1 - Failed
 */
uint32_t EraseSectors(uint32_t adr, uint32_t numsecs)
{
	status_t status = 0;

	adr = adr - FlashDevice.DevAdr;			// get offset to base of flash

#if defined (ERASE_IN_ONE)
	// Make single call to erase all of the required sectors (blocks).
	// Simpler, but actually appears to be slower than erasing by block
	status =  flexspi_nor_flash_erase(FLEXSPI_NOR_INSTANCE, &flashConfig, adr, (numsecs * FlashDevice.sectors[0].szSector));
#else
	while (numsecs) {
#if defined (NO_BLOCKS)
		status = flexspi_nor_flash_erase_sector(FLEXSPI_NOR_INSTANCE, &flashConfig, adr);
#else
		status = flexspi_nor_flash_erase_block(FLEXSPI_NOR_INSTANCE, &flashConfig, adr);
#endif
		if (status) {
			break;
		}

		numsecs--;
		adr += FlashDevice.sectors[0].szSector;
	}
#endif

	return status;
}

/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  1 - Failed
 */

uint32_t ProgramPage(uint32_t adr, uint32_t sz, uint8_t *buf)
{
	status_t status = 0;
	uint32_t page = 0;

	adr = adr - FlashDevice.DevAdr;		// get offset to base of flash

	while (sz) {
		status =  flexspi_nor_flash_page_program(FLEXSPI_NOR_INSTANCE, &flashConfig, adr, (void *)(buf + (page * flashConfig.pageSize)));
		if (status) {
			break;
		}

		sz = sz - flashConfig.pageSize;		// Decrease remaining size by page
		adr = adr + flashConfig.pageSize;	// Update adr base by page
		page++;								// Next page
	}

	return status;
}

#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t adr, uint32_t sz, uint8_t *buf)
{
	uint32_t status = 0;

	status = memcmp((void*) adr, buf, sz);

	return status;
}
#if defined (USE_SMALL_MEMCMP)
int memcmp(const void *a, const void *b, size_t n)
{
	const unsigned char *ac = (const unsigned char *)a,
	*bc = (const unsigned char *)b;
	while (n-- > 0) {
		unsigned char c1,c2; /* unsigned cmp seems more intuitive */
		if ((c1 = *ac++) != (c2 = *bc++))
			return c1 - c2;
	}
	return 0;
}
#endif // USE_SMALL_MEMCMP
#endif // DONT_PROVIDE_VERIFY
