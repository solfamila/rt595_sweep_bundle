//*****************************************************************************
// FlashDev.c
// MCUXpresso Flash driver - Flash Device settings
//*****************************************************************************
//
// Copyright 2022-2023 NXP
//
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include "board.h"
#include "fsl_nor_flash.h"
#include "fsl_flexspi.h"
#include "fsl_flexspi_nor_flash.h"
#include "pin_mux.h"

#include "FlashConfig.h"
#include "lpcx_flash_driver.h"


uint8_t membuf[256];

extern nor_config_t norConfig;
nor_handle_t norHandle = {NULL};

flexspi_mem_config_t mem_Config = {
        .deviceConfig =
        {
                .flexspiRootClk       = 133333333U,
                .flashSize            = FLASH_SIZE,
                .CSIntervalUnit       = kFLEXSPI_CsIntervalUnit1SckCycle,
                .CSInterval           = 2,
                .CSHoldTime           = 3,
                .CSSetupTime          = 3,
                .dataValidTime        = 2,
                .columnspace          = 0,
                .enableWordAddress    = 0,
                .AWRSeqIndex          = NOR_CMD_LUT_SEQ_IDX_PAGEPROGRAM,
                .AWRSeqNumber         = 1,
                .ARDSeqIndex          = NOR_CMD_LUT_SEQ_IDX_READ,
                .ARDSeqNumber         = 1,
                .AHBWriteWaitUnit     = kFLEXSPI_AhbWriteWaitUnit2AhbCycle,
                .AHBWriteWaitInterval = 0,
        },
        .devicePort      = kFLEXSPI_PortA1,
        .deviceType      = kSerialNorCfgOption_DeviceType_ReadSFDP_SDR,
        .quadMode        = kSerialNorQuadMode_NotConfig,
        .enhanceMode     = kSerialNorEnhanceMode_Disabled,
        .commandPads     = kFLEXSPI_1PAD,
        .queryPads       = kFLEXSPI_1PAD,
        .statusOverride  = 0,
        .busyOffset      = 0,
        .busyBitPolarity = 0,
};

nor_config_t norConfig = {
        .memControlConfig = &mem_Config,
        .driverBaseAddr   = EXAMPLE_FLEXSPI,
};

Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;

// ************************************
// Flash driver functions
// ************************************
static inline void FLEXSPI_ClockInit(void)
{
    // MCUXIDE-6798, MCUX-57240 Reset flash to clear modified dummy cycle before init flash component
    flexspi_transfer_t flashXfer;
    status_t status1, status2;
    uint32_t lookupTable[8] = {0U};

    if ((FLEXSPI->MCR0 & FLEXSPI_MCR0_MDIS_MASK) != FLEXSPI_MCR0_MDIS_MASK)
    {
        /* Flash already configured, need to reset it. */
        /* Set reset enable and reset commands for LUT. */
        lookupTable[0] = FLEXSPI_LUT_SEQ(kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x66, kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0x00);
        lookupTable[4] = FLEXSPI_LUT_SEQ(kFLEXSPI_Command_SDR, kFLEXSPI_1PAD, 0x99, kFLEXSPI_Command_STOP, kFLEXSPI_1PAD, 0x00);
        /* Update LUT table. */
        FLEXSPI_UpdateLUT(FLEXSPI, 56U, lookupTable, 8);

        flashXfer.deviceAddress = 0U;
        flashXfer.port          = kFLEXSPI_PortA1;
        flashXfer.cmdType       = kFLEXSPI_Command;
        flashXfer.SeqNumber     = 1;
        flashXfer.seqIndex      = 14;
        status1 = FLEXSPI_TransferBlocking(FLEXSPI, &flashXfer);
        flashXfer.seqIndex      = 15;
        status2 = FLEXSPI_TransferBlocking(FLEXSPI, &flashXfer);
        if ((status1 != kStatus_Success) || (status2 != kStatus_Success))
        {
            assert(false);
        }
    }
    // *****************

    /* Use tddr_mci_flexspi_clk / 3 */
    BOARD_SetFlexspiClock(FLEXSPI, 5U, 3U);
}

status_t Nor_Flash_Initialization(nor_config_t *config, nor_handle_t *handle)
{
    FLEXSPI_Type *base = (FLEXSPI_Type *)config->driverBaseAddr;

    /* Waiting for bus idle only when FLEXSPI enabled. */
    if ((base->MCR0 & FLEXSPI_MCR0_MDIS_MASK) != FLEXSPI_MCR0_MDIS_MASK)
    {
        /* Make sure flexspi bus idle before change its clock setting. */
        while (!FLEXSPI_GetBusIdleStatus(base))
        {
        }
    }

    /* Set flexspi clock. */
    FLEXSPI_ClockInit();

    return Nor_Flash_Init(config, handle);
}
/*
 *  Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t Init (void)
{
    status_t status;

    BOARD_InitBootPins();
    BOARD_BootClockRUN();

    CLOCK_EnableClock(kCLOCK_Flexspi);
    RESET_ClearPeripheralReset(kFLEXSPI_RST_SHIFT_RSTn);

#ifdef NDEBUG
    // Address of flash driver mailbox created by linker script
    // Note that this is skipped for debug builds of the driver
    extern unsigned int _b_mailbox;
    unsigned int *MAILBOX_PTR = &_b_mailbox;
    // Use mailbox 'status' word to pass address of message block
    *(MAILBOX_PTR+4) = (uint32_t)&Mailbox_Init_DynInfo;
#endif
    // Address of FlashDevice structure within driver
    Mailbox_Init_DynInfo.dyn_dev = &FlashDevice;
    Mailbox_Init_DynInfo.devname = FlashDevice.DevName;

    status = Nor_Flash_Initialization(&norConfig, &norHandle);
    if (status) return status;

    FlashDevice.szDev = norHandle.bytesInMemorySize;
    FlashDevice.sectors[0].szSector = norHandle.bytesInSectorSize;
    FlashDevice.szPage = norHandle.bytesInPageSize;

    // Unused - partID information
    Mailbox_Init_DynInfo.partid_bytes = 0;
    Mailbox_Init_DynInfo.partid = 0;

    return 0;
}

/*
 * De-Initialize Flash Programming Functions
 *    Return Value:   0 - OK,  other - failure code
 */

uint32_t UnInit(void)
{
    return 0;
}

/*
 *  Erase complete Flash Memory
 *    Return Value:   0 - OK,  other - failure code
 */
#if !defined(DONT_PROVIDE_ERASECHIP)
uint32_t EraseChip(void)
{
    return Nor_Flash_Erase_Chip(&norHandle);
}
#endif // DONT_PROVIDE_ERASECHIP

/*
 *  Erase Sector in Flash Memory
 *    Parameter:      adr:  Sector Address
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t EraseSectors(uint32_t addr, uint32_t numsecs)
{
    addr = addr - FlashDevice.DevAdr;
    for (uint32_t i = 0; i < numsecs; i++) {
        status_t status = Nor_Flash_Erase_Sector(&norHandle, addr + i * FlashDevice.sectors[0].szSector);
        if (status) return status;
    }

    return 0;
}

/*  Program Page in Flash Memory
 *    Parameter:      adr:  Page Start Address
 *                    sz:   Page Size
 *                    buf:  Page Data
 *    Return Value:   0 - OK,  other - failure code
 */
uint32_t ProgramPage(uint32_t addr, uint32_t sz, uint8_t *buf)
{
    // This should not happen at least when invoked by IDE, but it could happen when used from cmtool
    if (addr + sz > FlashDevice.DevAdr + FlashDevice.szDev)
    {
        sz = FlashDevice.szDev + FlashDevice.DevAdr - addr;
    }

    addr = addr - FlashDevice.DevAdr;
    for (uint32_t offset = 0; offset < sz; offset += FlashDevice.szPage) {
        status_t status = Nor_Flash_Page_Program(&norHandle, addr + offset, buf + offset);
        if (status) return status;
    }

    return 0;
}

/*
 *  Verify Flash Contents
 *    Parameter:      adr:  Start Address
 *                    sz:   Size (in bytes)
 *                    buf:  Data
 *    Return Value:   0 - OK, Failed - Address
 */
#if !defined(DONT_PROVIDE_VERIFY)
uint32_t Verify(uint32_t addr, uint32_t sz, uint8_t *buf_expected)
{
    for (uint32_t offset = 0; offset < sz; offset += sizeof(membuf)) {
        uint32_t nread = sz - offset >= sizeof(membuf) ? sizeof(membuf) : sz - offset;
        status_t status = Nor_Flash_Read(&norHandle, addr - FlashDevice.DevAdr + offset, membuf, nread);

        if (status) return status;

        if (memcmp(membuf, buf_expected + offset, nread)) {
            return -1;
        }
    }
    return 0;
}
#endif // DONT_PROVIDE_VERIFY

/*
 *  Checksum Sector Contents in Flash Memory
 *    Parameter:      adr:  Sector Address
 *                    numsecs: Number of sectors
 *                    data:  checksum data
 *    Return Value:   0 - OK,  1 - Failed
 *
 * 32 bit Fowler/Noll/Vo FNV-1a hash code
    http://en.wikipedia.org/wiki/Fowler_Noll_Vo_hash
 */
#define FNV1_32_INIT    0x811c9dc5
#define FNV1_32_PRIME   0x01000193
uint32_t ChecksumSectors(uint32_t adr, uint32_t numsecs, ChecksumData_t *data)
{
    uint32_t *results = (uint32_t *)&data->results;
    data->algID = FCHECKSUM_FNV1A_32;

    for (uint32_t i = 0; i < numsecs; i++)
    {
        uint32_t hash = FNV1_32_INIT;
        uint32_t size = FlashDevice.sectors[0].szSector;
        uint32_t read_adr = adr - FlashDevice.DevAdr + i * size;
        uint8_t *p = membuf;

        while (size > 0)
        {
            if ((uint32_t)(p - membuf) % sizeof(membuf) == 0)
            {
                // buffer exhausted - read a new one
                if (Nor_Flash_Read(&norHandle, read_adr, membuf, sizeof(membuf)))
                {
                    return 1;
                }
                p = (uint8_t *)membuf;
                read_adr += sizeof(membuf);
            }

            hash ^= (uint32_t)*p++;
            hash *= FNV1_32_PRIME;
            size--;
        }
        results[i] = hash;
    }

    return 0;
}
