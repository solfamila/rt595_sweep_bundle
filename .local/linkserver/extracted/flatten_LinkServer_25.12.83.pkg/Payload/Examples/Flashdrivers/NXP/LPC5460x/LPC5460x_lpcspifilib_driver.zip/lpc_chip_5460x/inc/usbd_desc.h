/***********************************************************************
 * $Id:: mw_usbd_desc.h 2219 2015-12-08 22:18:38Z usb00423                     $
 *
 * Project: USB device ROM Stack
 *
 * Description:
 *     USB Descriptors Definitions.
 *
 ***********************************************************************
 *   Copyright 2011, 2016, 2018, 2020, 2021 NXP
 *   All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause **********************************************************************/

#ifndef __USBDESC_H__
#define __USBDESC_H__

#include "usbd.h"

#define WBVAL(x) ((x) & 0xFF), (((x) >> 8) & 0xFF)
#define B3VAL(x) ((x) & 0xFF), (((x) >> 8) & 0xFF), (((x) >> 16) & 0xFF)

#define USB_DEVICE_DESC_SIZE        (sizeof(USB_DEVICE_DESCRIPTOR))
#define USB_CONFIGURATION_DESC_SIZE (sizeof(USB_CONFIGURATION_DESCRIPTOR))
#define USB_INTERFACE_DESC_SIZE     (sizeof(USB_INTERFACE_DESCRIPTOR))
#define USB_ENDPOINT_DESC_SIZE      (sizeof(USB_ENDPOINT_DESCRIPTOR))
#define USB_DEVICE_QUALI_SIZE       (sizeof(USB_DEVICE_QUALIFIER_DESCRIPTOR))
#define USB_OTHER_SPEED_CONF_SIZE   (sizeof(USB_OTHER_SPEED_CONFIGURATION))
#define USB_BOS_DESC_SIZE	          (sizeof(USB_BOS_DESCRIPTOR))
#define USB_SS_DEVICE_CAPABILITY_SIZE	(sizeof(USB_SS_DEVICE_CAPABILITY_DESCRIPTOR))
#define USB_DEVICE_CAPABILITY_SIZE		(sizeof(USB_DEVICE_CAPABILITY_DESCRIPTOR))

#define HID_DESC_SIZE               (sizeof(HID_DESCRIPTOR))
#define HID_REPORT_DESC_SIZE        (sizeof(HID_ReportDescriptor))

extern const uint8_t  HID_ReportDescriptor[];
extern const uint16_t HID_ReportDescSize;
extern const uint16_t HID_DescOffset;

#endif  /* __USBDESC_H__ */
