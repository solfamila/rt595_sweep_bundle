/*
 * @brief LPC18xx/43xx State Configurable Timer driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Initialize SCT */
void Chip_SCT_Init(LPC_SCT_T *pSCT)
{
	Chip_Clock_EnableOpts(CLK_MX_SCT, true, true, 1);
}

/* Shutdown SCT */
void Chip_SCT_DeInit(LPC_SCT_T *pSCT)
{
	Chip_Clock_Disable(CLK_MX_SCT);
}

/* Set/Clear SCT control register */
void Chip_SCT_SetClrControl(LPC_SCT_T *pSCT, uint32_t value, FunctionalState ena)
{
	uint32_t tem;

	tem = pSCT->CTRL_U;
	if (ena == ENABLE) {
		tem |= value;
	}
	else {
		tem &= (~value);
	}
	pSCT->CTRL_U = tem;
}

/* Set Conflict resolution */
void Chip_SCT_SetConflictResolution(LPC_SCT_T *pSCT, uint8_t outnum, uint8_t value)
{
	uint32_t tem;

	tem = pSCT->RES;
	tem &= ~(0x03 << (2 * outnum));
	tem |= (value << (2 * outnum));
	pSCT->RES = tem;
}

