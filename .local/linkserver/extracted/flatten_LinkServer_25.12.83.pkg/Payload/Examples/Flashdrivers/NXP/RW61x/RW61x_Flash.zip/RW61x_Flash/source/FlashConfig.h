/*
 * Copyright 2022-2023 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef _FLASHCONFIG_H_
#define _FLASHCONFIG_H_

/*******************************************************************************
 * Definitions
 ******************************************************************************/
#define EXAMPLE_FLEXSPI           FLEXSPI
#define FLASH_SIZE                0x7FFFFFF
#define EXAMPLE_FLEXSPI_AMBA_BASE FlexSPI_AMBA_PC_CACHE_BASE

#ifdef RW61X_FlexSPI_A_SFDP_QSPI_S
#define USE_SECURE_FLASHADDR
#define FLASH_BASE_ADDR 0x18000000
#else
#define FLASH_BASE_ADDR 0x08000000
#endif

#define CACHE_MAINTAIN 0x00U

#if defined(CACHE_MAINTAIN) && CACHE_MAINTAIN
#include "fsl_cache.h"
#endif

#endif /* _APP_H_ */
