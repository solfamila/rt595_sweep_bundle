/*
 * Copyright 2020-2022 NXP
 * All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "fsl_power.h"

/*******************************************************************************
 * Definitions
 ******************************************************************************/
/* Component ID definition, used by tools. */
#ifndef FSL_COMPONENT_ID
#define FSL_COMPONENT_ID "platform.drivers.power"
#endif

/* Wait some PMU cycles */
#define POWER_WAIT_PMU()              \
    do                                \
    {                                 \
        volatile uint32_t dummy;      \
        dummy = PMU->PWR_MODE_STATUS; \
        dummy = PMU->PWR_MODE_STATUS; \
        dummy = PMU->PWR_MODE_STATUS; \
        dummy = PMU->PWR_MODE_STATUS; \
        dummy = PMU->PWR_MODE_STATUS; \
        (void)dummy;                  \
    } while (false)

typedef struct _power_nvic_context
{
    uint32_t PriorityGroup;
    uint32_t ISER[5];
    uint8_t IPR[160];
    uint8_t SHPR[12];
    uint32_t ICSR;
    uint32_t VTOR;
    uint32_t AIRCR;
    uint32_t SCR;
    uint32_t CCR;
    uint32_t SHCSR;
    uint32_t MMFAR;
    uint32_t BFAR;
    uint32_t CPACR;
    uint32_t NSACR;
} power_nvic_context_t;

typedef struct _power_systick_context
{
    uint32_t CTRL;
    uint32_t LOAD;
} power_systick_context_t;

typedef struct _power_clock_context
{
    uint32_t SOURCE_CLK_GATE;
} power_clock_context_t;

/*******************************************************************************
 * Variables
 ******************************************************************************/
static power_nvic_context_t s_nvicContext;
static power_systick_context_t s_systickContext;
static power_clock_context_t s_clockContext;

/*******************************************************************************
 * Prototypes
 ******************************************************************************/

/*******************************************************************************
 * Code
 ******************************************************************************/
static void POWER_Delay(uint32_t loop)
{
    if (loop > 0U)
    {
        __ASM volatile("MOV    R0, %0" : : "r"(loop));
        __ASM volatile(
            "1:                             \n"
            "    SUBS   R0, R0, #1          \n"
            "    CMP    R0, #0              \n"
            "    BNE    1b                  \n");
    }
}

static void POWER_DelayUs(uint32_t us)
{
    uint32_t instNum;

    instNum = ((SystemCoreClock + 999999UL) / 1000000UL) * us;
    POWER_Delay((instNum + 2U) / 3U);
}

static void POWER_SaveNvicState(void)
{
    uint32_t i;
    uint32_t irqRegs;
    uint32_t irqNum;

    irqRegs = (SCnSCB->ICTR & SCnSCB_ICTR_INTLINESNUM_Msk) + 1;
    irqNum  = irqRegs * 32;

    assert(irqRegs <= ARRAY_SIZE(s_nvicContext.ISER));
    assert(irqNum <= ARRAY_SIZE(s_nvicContext.IPR));

    s_nvicContext.PriorityGroup = NVIC_GetPriorityGrouping();

    for (i = 0; i < irqRegs; i++)
    {
        s_nvicContext.ISER[i] = NVIC->ISER[i];
    }

    for (i = 0; i < irqNum; i++)
    {
        s_nvicContext.IPR[i] = NVIC->IPR[i];
    }

    /* Save SCB configuration */
    s_nvicContext.ICSR  = SCB->ICSR;
    s_nvicContext.VTOR  = SCB->VTOR;
    s_nvicContext.AIRCR = SCB->AIRCR;
    s_nvicContext.SCR   = SCB->SCR;
    s_nvicContext.CCR   = SCB->CCR;

    s_nvicContext.SHCSR = SCB->SHCSR;
    s_nvicContext.MMFAR = SCB->MMFAR;
    s_nvicContext.BFAR  = SCB->BFAR;
    s_nvicContext.CPACR = SCB->CPACR;
    s_nvicContext.NSACR = SCB->NSACR;

    for (i = 0U; i < ARRAY_SIZE(s_nvicContext.SHPR); i++)
    {
        s_nvicContext.SHPR[i] = SCB->SHPR[i];
    }
}

static void POWER_RestoreNvicState(void)
{
    uint32_t i;
    uint32_t irqRegs;
    uint32_t irqNum;

    irqRegs = (SCnSCB->ICTR & SCnSCB_ICTR_INTLINESNUM_Msk) + 1;
    irqNum  = irqRegs * 32;

    NVIC_SetPriorityGrouping(s_nvicContext.PriorityGroup);

    for (i = 0; i < irqRegs; i++)
    {
        NVIC->ISER[i] = s_nvicContext.ISER[i];
    }

    for (i = 0; i < irqNum; i++)
    {
        NVIC->IPR[i] = s_nvicContext.IPR[i];
    }

    /* Restore SCB configuration */
    SCB->ICSR  = s_nvicContext.ICSR;
    SCB->VTOR  = s_nvicContext.VTOR;
    SCB->AIRCR = s_nvicContext.AIRCR;
    SCB->SCR   = s_nvicContext.SCR;
    SCB->CCR   = s_nvicContext.CCR;

    SCB->SHCSR = s_nvicContext.SHCSR;
    SCB->MMFAR = s_nvicContext.MMFAR;
    SCB->BFAR  = s_nvicContext.BFAR;
    SCB->CPACR = s_nvicContext.CPACR;
    SCB->NSACR = s_nvicContext.NSACR;

    for (i = 0U; i < ARRAY_SIZE(s_nvicContext.SHPR); i++)
    {
        SCB->SHPR[i] = s_nvicContext.SHPR[i];
    }
}

/**
 * @brief   Check if IRQ is the wakeup source
 * @param   irq   : IRQ number
 * @return  true if IRQ is the wakeup source, false otherwise.
 */
bool POWER_GetWakeupStatus(IRQn_Type irq)
{
    uint32_t status;
    uint32_t irqNum = (uint32_t)irq;

    assert(irq >= 0);

    if (irq <= HWVAD0_IRQn)
    {
        status = PMU->WAKEUP_PM2_STATUS0 & (1UL << irqNum);
    }
    else if (irq <= POWERQUAD_IRQn)
    {
        status = PMU->WAKEUP_PM2_STATUS1 & (1UL << (irqNum - 32U));
    }
    else if ((irq <= ITRC_IRQn) && (irq >= GAU_GPDAC_INT_FUNC11_IRQn))
    {
        status = PMU->WAKEUP_PM2_STATUS3 & (1UL << (irqNum - 96U));
    }
    else
    {
        status = 0U;
    }

    switch (irq)
    {
        case PIN0_INT_IRQn:
            status = PMU->WAKEUP_STATUS & PMU_WAKEUP_STATUS_PIN0_MASK;
            break;
        case PIN1_INT_IRQn:
            status = PMU->WAKEUP_STATUS & PMU_WAKEUP_STATUS_PIN1_MASK;
            break;
        case RTC_IRQn:
            /* PM2 wakeup status is at WAKEUP_PM2_STATUS1, PM3/PM4 wakeup status is at WAKEUP_STATUS */
            status |= PMU->WAKEUP_STATUS & PMU_WAKEUP_STATUS_RTC_MASK;
            break;
        case CAPT_PULSE_IRQn:
            status = PMU->WAKEUP_STATUS & PMU_WAKEUP_STATUS_CAPT_MASK;
            break;
        case WL_MCI_WAKEUP0_IRQn:
            status = PMU->WAKEUP_STATUS & (1UL << PMU_WAKEUP_STATUS_WL_SHIFT);
            break;
        case WL_MCI_WAKEUP1_IRQn:
            status = PMU->WAKEUP_STATUS & (2UL << PMU_WAKEUP_STATUS_WL_SHIFT);
            break;
        case BLE_MCI_WAKEUP0_IRQn:
            status = PMU->WAKEUP_STATUS & (1UL << PMU_WAKEUP_STATUS_BLE_SHIFT);
            break;
        case BLE_MCI_WAKEUP1_IRQn:
            status = PMU->WAKEUP_STATUS & (2UL << PMU_WAKEUP_STATUS_BLE_SHIFT);
            break;
        default:
            break;
    }

    return (status != 0U);
}

/**
 * @brief   Clear wakeup status
 * @param   irq   : IRQ number
 */
void POWER_ClearWakeupStatus(IRQn_Type irq)
{
    uint32_t irqNum = (uint32_t)irq;

    assert(irq >= 0);

    if (irq <= HWVAD0_IRQn)
    {
        PMU->WAKEUP_PM2_SRC_CLR0 = (1UL << irqNum);
    }
    else if (irq <= POWERQUAD_IRQn)
    {
        PMU->WAKEUP_PM2_SRC_CLR1 = (1UL << (irqNum - 32U));
    }
    else if ((irq <= ITRC_IRQn) && (irq >= GAU_GPDAC_INT_FUNC11_IRQn))
    {
        PMU->WAKEUP_PM2_SRC_CLR3 = (1UL << (irqNum - 96U));
    }
    else
    {
        /* Do nothing */
    }

    switch (irq)
    {
        case PIN0_INT_IRQn:
            PMU->WAKE_SRC_CLR = PMU_WAKE_SRC_CLR_PIN0_CLR_MASK;
            break;
        case PIN1_INT_IRQn:
            PMU->WAKE_SRC_CLR = PMU_WAKE_SRC_CLR_PIN1_CLR_MASK;
            break;
        case RTC_IRQn:
            PMU->WAKE_SRC_CLR = PMU_WAKE_SRC_CLR_RTC_CLR_MASK;
            break;
        case CAPT_PULSE_IRQn:
            PMU->WAKE_SRC_CLR = PMU_WAKE_SRC_CLR_CAPT_CLR_MASK;
            break;
        case WL_MCI_WAKEUP0_IRQn:
            PMU->WAKE_SRC_CLR = (1UL << PMU_WAKE_SRC_CLR_WL_CLR_SHIFT);
            break;
        case WL_MCI_WAKEUP1_IRQn:
            PMU->WAKE_SRC_CLR = (2UL << PMU_WAKE_SRC_CLR_WL_CLR_SHIFT);
            break;
        case BLE_MCI_WAKEUP0_IRQn:
            PMU->WAKE_SRC_CLR = (1UL << PMU_WAKE_SRC_CLR_BLE_CLR_SHIFT);
            break;
        case BLE_MCI_WAKEUP1_IRQn:
            PMU->WAKE_SRC_CLR = (2UL << PMU_WAKE_SRC_CLR_BLE_CLR_SHIFT);
            break;
        default:
            break;
    }
}

/**
 * @brief   Enable the Wakeup interrupt.
 * @param   irq   : IRQ number
 */
void POWER_EnableWakeup(IRQn_Type irq)
{
    uint32_t irqNum = (uint32_t)irq;

    assert(irq >= 0);

    if (irq <= HWVAD0_IRQn)
    {
        PMU->WAKEUP_PM2_MASK0 |= (1UL << irqNum);
    }
    else if (irq <= POWERQUAD_IRQn)
    {
        PMU->WAKEUP_PM2_MASK1 |= (1UL << (irqNum - 32U));
    }
    else if ((irq <= ITRC_IRQn) && (irq >= GAU_GPDAC_INT_FUNC11_IRQn))
    {
        PMU->WAKEUP_PM2_MASK3 |= (1UL << (irqNum - 96U));
    }
    else
    {
        /* Do nothing */
    }

    switch (irq)
    {
        case PIN0_INT_IRQn:
            PMU->WAKEUP_MASK |= PMU_WAKEUP_MASK_PIN0_MASK_MASK;
            break;
        case PIN1_INT_IRQn:
            PMU->WAKEUP_MASK |= PMU_WAKEUP_MASK_PIN1_MASK_MASK;
            break;
        case RTC_IRQn:
            PMU->WAKEUP_MASK |= PMU_WAKEUP_MASK_RTC_MASK_MASK;
            break;
        case CAPT_PULSE_IRQn:
            PMU->WAKEUP_MASK |= PMU_WAKEUP_MASK_CAPT_MASK_MASK;
            break;
        case WL_MCI_WAKEUP0_IRQn:
            PMU->WAKEUP_MASK |= (1UL << PMU_WAKEUP_MASK_WL_MASK_SHIFT);
            break;
        case WL_MCI_WAKEUP1_IRQn:
            PMU->WAKEUP_MASK |= (2UL << PMU_WAKEUP_MASK_WL_MASK_SHIFT);
            break;
        case BLE_MCI_WAKEUP0_IRQn:
            PMU->WAKEUP_MASK |= (1UL << PMU_WAKEUP_MASK_BLE_MASK_SHIFT);
            break;
        case BLE_MCI_WAKEUP1_IRQn:
            PMU->WAKEUP_MASK |= (2UL << PMU_WAKEUP_MASK_BLE_MASK_SHIFT);
            break;
        default:
            break;
    }
}

/**
 * @brief   Disable the Wakeup interrupts.
 * @param   irq   : IRQ number
 */
void POWER_DisableWakeup(IRQn_Type irq)
{
    uint32_t irqNum = (uint32_t)irq;

    assert(irq >= 0);

    if (irq <= HWVAD0_IRQn)
    {
        PMU->WAKEUP_PM2_MASK0 &= ~(1UL << irqNum);
    }
    else if (irq <= POWERQUAD_IRQn)
    {
        PMU->WAKEUP_PM2_MASK1 &= ~(1UL << (irqNum - 32U));
    }
    else if ((irq <= ITRC_IRQn) && (irq >= GAU_GPDAC_INT_FUNC11_IRQn))
    {
        PMU->WAKEUP_PM2_MASK3 &= ~(1UL << (irqNum - 96U));
    }
    else
    {
        /* Do nothing */
    }

    switch (irq)
    {
        case PIN0_INT_IRQn:
            PMU->WAKEUP_MASK &= ~PMU_WAKEUP_MASK_PIN0_MASK_MASK;
            break;
        case PIN1_INT_IRQn:
            PMU->WAKEUP_MASK &= ~PMU_WAKEUP_MASK_PIN1_MASK_MASK;
            break;
        case RTC_IRQn:
            PMU->WAKEUP_MASK &= ~PMU_WAKEUP_MASK_RTC_MASK_MASK;
            break;
        case CAPT_PULSE_IRQn:
            PMU->WAKEUP_MASK &= ~PMU_WAKEUP_MASK_CAPT_MASK_MASK;
            break;
        case WL_MCI_WAKEUP0_IRQn:
            PMU->WAKEUP_MASK &= ~(1UL << PMU_WAKEUP_MASK_WL_MASK_SHIFT);
            break;
        case WL_MCI_WAKEUP1_IRQn:
            PMU->WAKEUP_MASK &= ~(2UL << PMU_WAKEUP_MASK_WL_MASK_SHIFT);
            break;
        case BLE_MCI_WAKEUP0_IRQn:
            PMU->WAKEUP_MASK &= ~(1UL << PMU_WAKEUP_MASK_BLE_MASK_SHIFT);
            break;
        case BLE_MCI_WAKEUP1_IRQn:
            PMU->WAKEUP_MASK &= ~(2UL << PMU_WAKEUP_MASK_BLE_MASK_SHIFT);
            break;
        default:
            break;
    }
}

/**
 * @brief   Set sleep mode on idle.
 * @param   mode : 0 ~ 4 stands for PM0 ~ PM4.
 */
void POWER_SetSleepMode(uint32_t mode)
{
    assert(mode <= 4U);

    if (mode == 0U)
    {
        mode = 1U; /* PM0/PM1 is same */
    }
    /* set PMU basic mode */
    PMU->PWR_MODE = PMU_PWR_MODE_PWR_MODE(mode - 1U);

    /* select deepsleep or not */
    if (mode == 1U)
    {
        SCB->SCR &= ~SCB_SCR_SLEEPDEEP_Msk;
    }
    else
    {
        SCB->SCR |= SCB_SCR_SLEEPDEEP_Msk;
    }
}

static void Power_ConfigClkGate(const power_sleep_config_t *config)
{
    uint32_t pm2AnaPdCfg = (config->pm2AnaPuCfg ^ (uint32_t)kPOWER_Pm2AnaPuAll) & (uint32_t)kPOWER_Pm2AnaPuAll;
    uint32_t clkGate     = config->clkGate & (uint32_t)kPOWER_ClkGateAll;

    /* If ENET clock is enabled, TDDR power must be on. */
    if ((clkGate & SYSCTL2_SOURCE_CLK_GATE_TDDR_MCI_ENET_CLK_CG_MASK) == 0U)
    {
        pm2AnaPdCfg &= ~SYSCTL2_ANA_PDWN_PM2_TDDR_TOP_ANA_PDWN_PM2_MASK;
    }

    SYSCTL2->SOURCE_CLK_GATE = (SYSCTL2->SOURCE_CLK_GATE & (~((uint32_t)kPOWER_ClkGateAll))) | clkGate;
    SYSCTL2->ANA_PDWN_PM2    = pm2AnaPdCfg;
}

/* Prepare to go to low power
 *  Change clock source to RC32M
 *   Switch off PLLs, XTAL
 *  Set Deep sleep bit in SRC register
 *  Initiate state change
 */
static void POWER_PrePowerMode(uint32_t mode, const power_sleep_config_t *config)
{
    assert((mode >= 1U) && (mode <= 4U));
    /* Turn off Systick to avoid interrupt
     *  when entering low power state
     */
    s_systickContext.CTRL = SysTick->CTRL;
    s_systickContext.LOAD = SysTick->LOAD;
    SysTick->CTRL         = 0;
    SysTick->LOAD         = 0;

    POWER_SetSleepMode(mode);

    s_clockContext.SOURCE_CLK_GATE = SYSCTL2->SOURCE_CLK_GATE;

    if (mode == 2U)
    {
        /* Keep all modules power on in SW controlled CFG */
        SYSCTL2->MEM_PD_CFG = 0U;
        /* Enable SW control for modules need be powered on, the others are powered down by HW */
        SYSCTL2->MEM_PD_CTRL = config->pm2MemPuCfg & (uint32_t)kPOWER_Pm2MemPuAll;
        Power_ConfigClkGate(config);
    }
    else if (mode == 3U)
    {
        PMU->MEM_CFG = (PMU->MEM_CFG & ~PMU_MEM_CFG_MEM_RET_MASK) | (config->memPdCfg & PMU_MEM_CFG_MEM_RET_MASK);
        PMU->PMIP_BUCK_CTRL =
            (PMU->PMIP_BUCK_CTRL & ~((uint32_t)kPOWER_Pm3BuckAll)) | (config->pm3BuckCfg & (uint32_t)kPOWER_Pm3BuckAll);
        PMU->PMIP_LDO_LVL  = 0x0U;
        PMU->PMIP_BUCK_LVL = (PMU->PMIP_BUCK_LVL &
                              ~(PMU_PMIP_BUCK_LVL_SLEEP_BUCK18_SEL_MASK | PMU_PMIP_BUCK_LVL_SLEEP_BUCK11_SEL_MASK)) |
                             PMU_PMIP_BUCK_LVL_SLEEP_BUCK18_SEL(config->pm3Buck18SlpLvl) |
                             PMU_PMIP_BUCK_LVL_SLEEP_BUCK11_SEL(config->pm3Buck11SlpLvl);
        POWER_SaveNvicState();
        /* Clear reset status */
        PMU->SYS_RST_CLR = 0x7FU;
    }
    else if (mode == 4U)
    {
        PMU->TIME_OUT_CTRL = PMU_TIME_OUT_CTRL_V11_RDY_NO_TMT_MASK | PMU_TIME_OUT_CTRL_V18_RDY_NO_TMT_MASK |
                             PMU_TIME_OUT_CTRL_PSW_MCI_RDY_NO_TMT_MASK;
        PMU->MEM_CFG =
            (PMU->MEM_CFG & ~PMU_MEM_CFG_AON_MEM_RET_MASK) | (config->memPdCfg & PMU_MEM_CFG_AON_MEM_RET_MASK);
        PMU->PMIP_LDO_LVL =
            PMU_PMIP_LDO_LVL_LDO18_SEL(config->pm4Ldo18Lvl) | PMU_PMIP_LDO_LVL_LDO11_SEL(config->pm4Ldo11Lvl);
        /* Clear reset status */
        PMU->SYS_RST_CLR = 0x7FU;
    }
}

static void POWER_PostPowerMode(uint32_t mode)
{
    assert((mode >= 1U) && (mode <= 3U));
    assert((mode == 1U) || (PMU->PWR_MODE_STATUS == (mode - 1U))); /* PM1 doesn't update PWR_MODE_STATUS */
    assert(PMU->PWR_MODE == 0U);

    POWER_SetSleepMode(1U);

    SYSCTL2->SOURCE_CLK_GATE = s_clockContext.SOURCE_CLK_GATE;

    if (mode == 3U)
    {
        POWER_RestoreNvicState();
    }

    SysTick->CTRL = s_systickContext.CTRL;
    SysTick->LOAD = s_systickContext.LOAD;
}

void POWER_GetCurrentSleepConfig(power_sleep_config_t *config)
{
    assert(config != NULL);

    config->pm2MemPuCfg = (~SYSCTL2->MEM_PD_CFG) & (SYSCTL2->MEM_PD_CTRL);
    config->pm2AnaPuCfg = (~SYSCTL2->ANA_PDWN_PM2) & (uint32_t)kPOWER_Pm2AnaPuAll;
    config->clkGate     = SYSCTL2->SOURCE_CLK_GATE;
    config->memPdCfg    = PMU->MEM_CFG;
    config->pm3BuckCfg  = PMU->PMIP_BUCK_CTRL;
}

void POWER_EnterPowerMode(uint32_t mode, const power_sleep_config_t *config)
{
    uint32_t primask;

    assert(mode <= 4U);

    if (mode >= 1U)
    {
        primask = DisableGlobalIRQ();
        POWER_PrePowerMode(mode, config);
        __WFI();
        POWER_PostPowerMode(mode);
        EnableGlobalIRQ(primask);
    }
}

void POWER_PowerOnWlan(void)
{
    if ((PMU->WLAN_CTRL & PMU_WLAN_CTRL_WL_SLEEP_MASK) == PMU_WLAN_CTRL_WL_SLEEP_MASK)
    {
        /* Enable SW control */
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_WL_EN_MASK;
        /* WLan request buck on, then need wait 5 fast clk_pmu cycles, do psw on, then iso release */
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_WL_BUCK_ON_REQ_MASK;
        /* Wait buck on */
        POWER_WAIT_PMU();

        PMU->SW_CTRL_WL &= ~PMU_SW_CTRL_WL_PSW_WL_PD_MASK;
        /* Wait PSW ready */
        SystemCoreClockUpdate();
        POWER_DelayUs(50U);
        /* Disable ISO */
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_MCI_ISO_WL_N_MASK;
        /* Wait about 125us */
        POWER_DelayUs(125U);
        /* Release WLan */
        PMU->SW_CTRL_WL &= ~PMU_SW_CTRL_WL_MCI_WL_PU_RST_MASK;
    }
}

void POWER_PowerOffWlan(void)
{
    if ((PMU->WLAN_CTRL & PMU_WLAN_CTRL_WL_SLEEP_MASK) != PMU_WLAN_CTRL_WL_SLEEP_MASK)
    {
        /* Enable SW control */
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_WL_EN_MASK;
        /* Enable ISO before PSW off */
        PMU->SW_CTRL_WL &= ~PMU_SW_CTRL_WL_MCI_ISO_WL_N_MASK;
        POWER_WAIT_PMU();
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_PSW_WL_PD_MASK;
        /* Wait PSW off */
        while ((SOCCTRL->PSW_VD2_RDY0 & (1UL << 1)) == 0U)
        {
        }
        /* Reset WLan */
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_MCI_WL_PU_RST_MASK;
        /* Request buck off */
        PMU->SW_CTRL_WL |= PMU_SW_CTRL_WL_WL_BUCK_OFF_REQ_MASK;
    }
}

void POWER_PowerOnBle(void)
{
    if ((PMU->BLE_CTRL & PMU_BLE_CTRL_BLE_SLEEP_MASK) == PMU_BLE_CTRL_BLE_SLEEP_MASK)
    {
        /* Enable SW control */
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_BLE_EN_MASK;
        /* BLE request buck on, then need wait 5 fast clk_pmu cycles(about 96ns),do psw on, then iso release */
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_BLE_BUCK_ON_REQ_MASK;
        /* Wait buck on */
        POWER_WAIT_PMU();
        PMU->SW_CTRL_BLE &= ~PMU_SW_CTRL_BLE_PSW_BLE_PD_MASK;
        /* Wait PSW ready */
        SystemCoreClockUpdate();
        POWER_DelayUs(50U);
        /* Disable ISO */
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_MCI_ISO_BLE_N_MASK;
        /* Wait about 125us */
        POWER_DelayUs(125U);
        /* Release BLE */
        PMU->SW_CTRL_BLE &= ~PMU_SW_CTRL_BLE_MCI_BLE_PU_RST_MASK;
    }
}

void POWER_PowerOffBle(void)
{
    if ((PMU->BLE_CTRL & PMU_BLE_CTRL_BLE_SLEEP_MASK) != PMU_BLE_CTRL_BLE_SLEEP_MASK)
    {
        /* Enable SW control */
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_BLE_EN_MASK;
        /* Enable ISO before PSW off */
        PMU->SW_CTRL_BLE &= ~PMU_SW_CTRL_BLE_MCI_ISO_BLE_N_MASK;
        POWER_WAIT_PMU();
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_PSW_BLE_PD_MASK;
        /* Wait PSW off */
        while ((SOCCTRL->PSW_VD2_RDY0 & (1UL << 9)) == 0U)
        {
        }
        /* Reset BLE */
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_MCI_BLE_PU_RST_MASK;
        /* Request buck off */
        PMU->SW_CTRL_BLE |= PMU_SW_CTRL_BLE_BLE_BUCK_OFF_REQ_MASK;
    }
}

void POWER_PowerOnGau(void)
{
    GAU_BG->CTRL &= ~BG_CTRL_PD_MASK;
    while ((GAU_BG->STATUS & BG_STATUS_RDY_MASK) == 0U)
    {
    }
}

void POWER_PowerOffGau(void)
{
    GAU_BG->CTRL |= BG_CTRL_PD_MASK;
}
