//*****************************************************************************
// flashprogtest.c
// LPCXpresso Flash driver - simple test of flash functions
//*****************************************************************************
//
// Copyright 2014-2015, 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "lpcx_flash_driver.h"

//#include "../src/FlashConfig.h"

#include <cr_section_macros.h>
__BSS(RAM2) unsigned char buf[16 * 1024]  __attribute__ ((aligned (4)));

extern Mailbox_Init_DynInfo_t Mailbox_Init_DynInfo;

 char itoa_buf[32];
int main(void)
{
	unsigned int addr;
	unsigned int sector_addr = 0xFFFFFFFF;
	unsigned int sector_size = 0xFFFFFFFF;
	unsigned int allocated = 0;
	int idx;
	int no_blocks = 0;
	int no_sectors = 0;
	int status = 0;
	volatile int pattern = 0;

	//	__disable_irq();
	__asm volatile ("cpsid i");

    puts("Flash Driver test program starting\n") ;

	status = Init();

	printf("SPIFI driver : %s\n",FlashDevice.DevName);
	printf("Detected properties\n");
	printf("- SPIFI size : %d KB, %.2f MB\n",FlashDevice.szDev/1024,(double)(FlashDevice.szDev)/1048576.0);
	printf("- SPIFI ProgramPage size : %d bytes\n",FlashDevice.szPage);
	printf("- SPIFI sector size : %d KB\n",FlashDevice.sectors[0].szSector/1024);

	printf("- Detected device : %s\n",Mailbox_Init_DynInfo.devname);
	// no_blocks is the number of entries in FlashDevice.sectors
	for (idx = 0; ; idx++)
	{
	  if ((FlashDevice.sectors[idx].szSector   == 0xFFFFFFFF)
	  &&  (FlashDevice.sectors[idx].AddrSector == 0xFFFFFFFF))
		break;
	  no_blocks++;
	} // end for

	// Rules check for loadable flash driver
	for (idx = 0; idx < no_blocks; idx++)
	{
	  if ((FlashDevice.sectors[idx].AddrSector == 0xFFFFFFFF)
	  &&  (FlashDevice.szDev - allocated))
	  {
		no_sectors += (FlashDevice.szDev - allocated) / FlashDevice.sectors[idx - 1].szSector;
		break;
	  }
	  else if (sector_addr == -1)
	  {
		sector_addr = FlashDevice.sectors[idx].AddrSector;
		sector_size = FlashDevice.sectors[idx].szSector;
		if (!allocated)
		{
		  no_sectors += (FlashDevice.szDev / sector_size);
		  allocated = FlashDevice.szDev;
		}
	  }
	  else
	  {
		allocated = FlashDevice.sectors[idx].AddrSector - FlashDevice.sectors[idx - 1].AddrSector;
		no_sectors += allocated / FlashDevice.sectors[idx].szSector;
	  }
	}
	// populate buffer with pattern
	for (idx = 0; idx < FlashDevice.szPage; idx++)
	{
		if (pattern)
			buf[idx] = pattern;
		else
			buf[idx] = idx % 256;
	}



	// address of flash device
	addr = sector_addr = FlashDevice.DevAdr;
	for (idx = 0; idx < no_sectors; idx++)
	{
#if 1
		if (sector_addr == addr)
		{
			status = EraseSectors(addr,1);			// erase sector
			sector_addr = addr + sector_size;	// next sector address
			if (status)
			{
				printf("Erase sector %d (0x%x) failed.\n", idx, addr);
				puts("Erase sector failed\n");
				break;
			} else {
				// null
			}
		}
#endif

#if 1
		do {
			// program sector by page
			status = ProgramPage(addr, FlashDevice.szPage, buf);
			// verify page
			if (!status)
				status = memcmp((void *)addr, buf, FlashDevice.szPage);
			if (status)
			{
				printf("Program sector %d failed at 0x%x.\n", idx, addr);
				puts("Program sector failed\n");
				break;
			} else {
				// null
			}
			addr += FlashDevice.szPage;
		} while (addr != sector_addr);
#endif
		if (status)  break;
	}

#if 1
	if (EraseChip) {
		status = EraseChip();
	if (status)
	{
		printf("Erase chip failed\n");
	}
	}
#endif

	UnInit();

    puts("Finished\n") ;

	return(0);
}
