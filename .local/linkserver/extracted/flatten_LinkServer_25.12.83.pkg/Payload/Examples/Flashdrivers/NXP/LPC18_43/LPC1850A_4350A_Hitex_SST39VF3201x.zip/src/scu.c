// Copyright 2012 Code Red Technologies Limited
// Copyright 2020, 2021 NXP
/***********************************************************************
 * $Id: scu.c 8313 2011-10-14 22:30:17Z nxp21346 $
 *
 * Project: LPC18xx Common
 *
 * Description:
 *     This file contains code to configure the PINMUX
 *
 ***********************************************************************
 * SPDX-License-Identifier: BSD-3-Clause
 **********************************************************************/

#if defined CORE_M3 || defined CORE_M4
#include "LPC18xx.h"                    /* LPC18xx definitions                */
#endif
#ifdef CORE_M0s
#include "LPC18xx_m0s.h"                /* LPC18xx definitions                */
#endif
#ifdef CORE_M0a
#include "LPC18xx_m0a.h"                /* LPC18xx definitions                */
#endif

#include "type.h"
#include "scu.h"

void scu_pinmux(unsigned port, unsigned pin, unsigned mode, unsigned func)
{
  volatile unsigned int * const scu_base=(unsigned int*)(LPC_SCU_BASE);
  scu_base[(PORT_OFFSET*port+PIN_OFFSET*pin)/4]=mode+func;
} /* scu_pinmux */
