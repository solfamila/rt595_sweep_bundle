/*
 * @brief LPC5460x basic chip inclusion file
 *
 * @note
 * Copyright 2014, 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __CHIP_H_
#define __CHIP_H_

#include "lpc_types.h"
#include "cmsis.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifndef CORE_M4
#ifndef CORE_M0PLUS
#error "CORE_M4 or CORE_M0PLUS is not defined for the LPC5460x architecture"
#error "CORE_M4 or CORE_M0PLUS should be defined as part of your compiler define list"
#endif
#endif

/* LPCXpresso macro LPCOpen macro defines */
#if defined(__LPC5460X__)
#define CHIP_LPC5460X
#endif

#ifndef CHIP_LPC5460X
#error "The LPC5460X Chip include path is used for this build, but"
#error "CHIP_LPC5460X is not defined!"
#endif

#ifndef __DOXYGEN__
/* Macros to append params */
#define __APPEND30(x,y,z) x##y##z
#define __APPEND3(x,y,z) __APPEND30(x,y,z)
#endif

/** @defgroup PERIPH_5460X_BASE CHIP: LPC5460X Peripheral addresses and register set declarations
 * @ingroup CHIP_5460X_DRIVERS
 * @{
 */

/* Main memory addresses */
#define LPC_FLASHMEM_BASE          0x00000000UL
#define LPC_SRAMX_BASE             0x04000000UL
#define LPC_SRAM0_BASE             0x20000000UL
#define LPC_SRAM1_BASE             0x20010000UL
#define LPC_SRAM2_BASE             0x20018000UL
#define LPC_USB_SRAM_BASE          0x40100000UL
#define LPC_USB_SRAM_SIZE          0x00002000UL
#define LPC_ROM_BASE               0x03000000UL

/* APB0 peripheral group addresses */
#define LPC_SYSCON_BASE            0x40000000UL
#define LPC_IOCON_BASE             0x40001000UL
#define LPC_GPIO_GROUPINT0_BASE    0x40002000UL
#define LPC_GPIO_GROUPINT1_BASE    0x40003000UL
#define LPC_PIN_INT_BASE           0x40004000UL
#define LPC_INMUX_BASE             0x40005000UL
#define LPC_TIMER0_BASE            0x40008000UL
#define LPC_TIMER1_BASE            0x40009000UL
#define LPC_WWDT_BASE              0x4000C000UL
#define LPC_MRT_BASE               0x4000D000UL
#define LPC_UTICK_BASE             0x4000E000UL
#define LPC_EEPROM_BASE            0x40014000UL
#define LPC_OTP_BASE               0x40015000UL

/* APB1 peripheral group address */
#define LPC_PMU_BASE               0x40020000UL
#define LPC_TIMER2_BASE            0x40028000UL
#define LPC_RTC_BASE               0x4002C000UL
#define LPC_RITIMER_BASE           0x4002D000UL
#define LPC_FMC_BASE               0x40034000UL

/* Asynchronous APB peripheral group addresses */
#define LPC_ASYNC_SYSCON_BASE      0x40040000UL
#define LPC_TIMER3_BASE            0x40048000UL
#define LPC_TIMER4_BASE            0x40049000UL

/* AHB Peripherals base address */
#define LPC_SPIFI_BASE             0x40080000UL
#define LPC_EMC_BASE               0x40081000UL
#define LPC_DMA_BASE               0x40082000UL
#define LPC_LCD_BASE               0x40083000UL
#define LPC_USB0_BASE              0x40084000UL
#define LPC_LCD_BASE               0x40083000UL
#define LPC_SCT_BASE               0x40085000UL
#define LPC_FLEXCOMM0_BASE         0x40086000UL
#define LPC_FLEXCOMM1_BASE         0x40087000UL
#define LPC_FLEXCOMM2_BASE         0x40088000UL
#define LPC_FLEXCOMM3_BASE         0x40089000UL
#define LPC_FLEXCOMM4_BASE         0x4008A000UL
#define LPC_GPIO_PORT_BASE         0x4008C000UL
#define LPC_DMIC_BASE              0x40090000UL
#define LPC_ETHERNET_BASE          0x40092000UL
#define LPC_USB1_BASE              0x40094000UL
#define LPC_CRC_BASE               0x40095000UL
#define LPC_FLEXCOMM5_BASE         0x40096000UL
#define LPC_FLEXCOMM6_BASE         0x40097000UL
#define LPC_FLEXCOMM7_BASE         0x40098000UL
#define LPC_FLEXCOMM8_BASE         0x40099000UL
#define LPC_FLEXCOMM9_BASE         0x4009A000UL
#define LPC_SDIO_BASE              0x4009B000UL
#define LPC_ISPAP_BASE             0x4009C000UL
#define LPC_CAN0_BASE              0x4009D000UL
#define LPC_CAN1_BASE              0x4009E000UL
#define LPC_ADC_BASE               0x400A0000UL
#define LPC_AES_BASE               0x400A1000UL
#define LPC_USB0_HOST_BASE         0x400A2000UL
#define LPC_USB1_HOST_BASE         0x400A3000UL
#define LPC_HASH_BASE              0x400A4000UL

/* Main memory register access */
#define LPC_GPIO           ((LPC_GPIO_T            *) LPC_GPIO_PORT_BASE)
#define LPC_DMA            ((LPC_DMA_T             *) LPC_DMA_BASE)
#define LPC_EMC            ((LPC_EMC_T             *) LPC_EMC_BASE)
#define LPC_LCD            ((LPC_LCD_T             *) LPC_LCD_BASE)
#define LPC_CRC            ((LPC_CRC_T             *) LPC_CRC_BASE)
#define LPC_SDIO           ((LPC_SDMMC_T           *) LPC_SDIO_BASE)
#define LPC_SCT            ((LPC_SCT_T             *) LPC_SCT_BASE)
#define LPC_ADC            ((LPC_ADC_T             *) LPC_ADC_BASE)
#define LPC_PMU            ((LPC_PMU_T             *) LPC_PMU_BASE)
#define LPC_DMIC           ((LPC_DMIC_T            *) LPC_DMIC_BASE)
#define LPC_USB0           ((LPC_USB_T             *) LPC_USB0_BASE)
#define LPC_USB1           ((LPC_USB_T             *) LPC_USB1_BASE)
#define LPC_USBH0          ((LPC_USBH0_T           *) LPC_USB0_HOST_BASE)
#define LPC_USBH1          ((LPC_USBH1_T           *) LPC_USB1_HOST_BASE)
#define LPC_ETHERNET		((LPC_ENET_T			*) LPC_ETHERNET_BASE)
#define LPC_EEPROM			((LPC_EEPROM_T 			*) LPC_EEPROM_BASE)

/* APB0 peripheral group register access */
#define LPC_SYSCON         ((LPC_SYSCON_T          *) LPC_SYSCON_BASE)
#define LPC_TIMER2         ((LPC_TIMER_T           *) LPC_TIMER2_BASE)
#define LPC_TIMER3         ((LPC_TIMER_T           *) LPC_TIMER3_BASE)
#define LPC_TIMER4         ((LPC_TIMER_T           *) LPC_TIMER4_BASE)
#define LPC_GINT           ((LPC_GPIOGROUPINT_T    *) LPC_GPIO_GROUPINT0_BASE)
#define LPC_PININT         ((LPC_PIN_INT_T         *) LPC_PIN_INT_BASE)
#define LPC_IOCON          ((LPC_IOCON_T           *) LPC_IOCON_BASE)
#define LPC_UTICK          ((LPC_UTICK_T           *) LPC_UTICK_BASE)
#define LPC_WWDT           ((LPC_WWDT_T            *) LPC_WWDT_BASE)
#define LPC_RTC            ((LPC_RTC_T             *) LPC_RTC_BASE)
#define LPC_OTP			   ((LPC_OTP_T			   *) LPC_OTP_BASE)
#define LPC_SDMMC          LPC_SDIO

/* APB1 peripheral group register access */
#define LPC_ASYNC_SYSCON   ((LPC_ASYNC_SYSCON_T    *) LPC_ASYNC_SYSCON_BASE)
#define LPC_TIMER0         ((LPC_TIMER_T           *) LPC_TIMER0_BASE)
#define LPC_TIMER1         ((LPC_TIMER_T           *) LPC_TIMER1_BASE)
#define LPC_INMUX          ((LPC_INMUX_T           *) LPC_INMUX_BASE)
#define LPC_MRT            ((LPC_MRT_T             *) LPC_MRT_BASE)
#define LPC_RITIMER        ((LPC_RITIMER_T         *) LPC_RITIMER_BASE)

/**
 * @}
 */

/** @ingroup CHIP_5460X_DRIVER_OPTIONS
 * @{
 */

/**
 * @brief	Clock rate on the CLKIN pin
 * This value is defined externally to the chip layer and contains
 * the value in Hz for the CLKIN pin for the board. If this pin isn't used,
 * this rate can be 0.
 */
extern const uint32_t ExtClockIn;

/**
 * @}
 */

/* Include order is important! */
#include "lpc_assert.h"
#include "romapi_5460x.h"
#include "syscon_5460x.h"
#include "cpuctrl_5460x.h"
#include "clock_5460x.h"
#include "pmu_5460x.h"
#include "iocon_5460x.h"
#include "pinint_5460x.h"
#include "inmux_5460x.h"
#include "crc_5460x.h"
#include "gpio_5460x.h"
#include "mrt_5460x.h"
#include "wwdt_5460x.h"
#include "sct_5460x.h"
#include "sct_pwm_5460x.h"
#include "rtc_5460x.h"
#include "timer_5460x.h"
#include "utick_5460x.h"
#include "gpiogroup_5460x.h"
#include "fpu_init.h"
#include "power_lib_5460x.h"
#include "flexcomm_5460x.h"
#include "usbd_5460x.h"
#include "usbh_5460x.h"

#include "adc_5460x.h"
#include "emc_5460x.h"
#include "lcd_5460x.h"
#include "dma_5460x.h"
#include "dma_service_5460x.h"
#include "dmic_5460x.h"
#include "uart_5460x.h"
#include "spi_common_5460x.h"
#include "spim_5460x.h"
#include "spis_5460x.h"
#include "i2c_common_5460x.h"
#include "i2cm_5460x.h"
#include "i2cs_5460x.h"
#include "i2s_5460x.h"
#include "sdif_5460x.h"
#include "sdio_5460x.h"
#include "sdmmc_5460x.h"
#include "enet_5460x.h"
#include "eeprom_5460x.h"
#include "ritimer_5460x.h"
#include "otp_5460x.h"

/** @defgroup SUPPORT_5460X_FUNC CHIP: LPC5460X support functions
 * @ingroup CHIP_5460X_DRIVERS
 * @{
 */

/**
 * @brief	Current system clock rate, mainly used for peripherals in SYSCON
 */
extern uint32_t SystemCoreClock;

/**
 * @brief	Update system core and ASYNC syscon clock rate, should be called if the
 *			system has a clock rate change
 * @return	None
 */
void SystemCoreClockUpdate(void);

/**
 * @brief	Set up and initialize hardware prior to call to main()
 * @return	None
 * @note	Chip_SystemInit() is called prior to the application and sets up
 * system clocking prior to the application starting.
 */
void Chip_SystemInit(void);

/**
 * @brief	Clock and PLL initialization based on the internal oscillator
 * @param	iFreq	: Rate (in Hz) to set the main system clock to
 * @return	None
 */
void Chip_SetupIrcClocking(uint32_t iFreq);

/**
 * @brief	Clock and PLL initialization based on the external clock input
 * @param	iFreq	: Rate (in Hz) to set the main system clock to
 * @return	None
 */
void Chip_SetupExtInClocking(uint32_t iFreq);

/**
 * @brief	Initialize the Core clock to given frequency (12, 48 or 96 MHz)
 * @param	iFreq	: Desired frequency (must be one of #SYSCON_FRO12MHZ_FREQ or #SYSCON_FRO48MHZ_FREQ or #SYSCON_FRO96MHZ_FREQ)
 * @return	Nothing
 */
void Chip_SetupFROClocking(uint32_t iFreq);

/**
 * @brief	Initialize the USB0(FS) bus
 * @return 	Nothing
 * @note	Uses FRO HF and initialize the pin-IO and the clocks.
 */
void Chip_USB0_Init(void);

/**
 * @brief	Initialize the USB1(HS) bus
 * @return 	Nothing
 * @note	Use USB PLL for USB HS and initialize the pin-IO and the clocks.
 */
void Chip_USB1_Init(void);

/**
 * @brief	Turn of FRO clock trimming based on USB SOF
 * @param	enable	: 0 - Disable trim based on USB SOF; Non-Zero to enable it
 * @return	Nothing
 */
__STATIC_INLINE void Chip_USB_TrimOff(int enable)
{
	if (enable) {
		/* Turn ON FRO HF and let it adjust TRIM value based on USB SOF */
		LPC_SYSCON->FROCTRL = (LPC_SYSCON->FROCTRL & ~SYSCON_FROCTRL_MASK) | SYSCON_FROCTRL_USBCLKADJ;
	} else {
		/* Turn ON FRO HF and let it adjust TRIM value based on USB SOF */
		LPC_SYSCON->FROCTRL = LPC_SYSCON->FROCTRL & ~(SYSCON_FROCTRL_MASK | SYSCON_FROCTRL_USBCLKADJ);
	}
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __CHIP_H_ */
