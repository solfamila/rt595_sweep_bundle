LPC40xx SPIFI Generic Flash driver source project
==================================================

MCUXpresso IDE LPC40xx SPIFI flash driver structured such
that a single generic driver is generated which will 
autodetect the SPIFI part fitted in the target system and
configure itself appropriately.

This means that it is no longer necessary to generate 
individual drivers for specific SPIFI flash devices or 
particular sizes of SPIFI flash devices, making it much easier 
to add support for new SPIFI devices.

Note that the generated driver is compatible with
MCUXpresso IDE versions 10.0.0 and later

For more information on the use of flash drivers for external
flash, please see the MCUXpresso IDE User Guide chapter on the
"Memory Editor and User Loadable Flash Driver mechanism".
  
Note that this project builds a flash driver with the name
 => LPC40xx_SPIFI_GENERIC.cfx

[
 07 Mar 2017
 Initial Version for MCUXpresso IDE
]

Supported SPIFI devices
-----------------------
As this flash driver project sits on top of the LPCSPIFI Library,
LPCXpresso flash drivers created using this project  will only be
able to program SPIFI devices supported by the LPCSPIFI Library.

A list of the currently supported SPIFI devices is included below
(with known clone parts listed within {} brackets):

 * 64MB (256KB sector) devices
   ~ S25FL512S

 * 64MB (64KB sector) devices
   ~ MT25QL512A

 * 32MB (256KB sector) devices
   ~ S25FL256S 256k sector

 * 32MB (64KB sector) devices
   ~ S25FL256S 64k sector
   ~ MT25QL256A
   ~ N25Q256

 * 16MB (256KB sector) devices
   ~ S25FL129P 256k Sector {S25FL128S}

 * 16MB (64KB sector) devices
   ~ S25FL129P 64k Sector
   ~ W25Q128FV
   ~ N25Q128
   ~ MX25L12835E
   ~ MT25QL128AB

 * 8MB (64KB sector) devices
   ~ S25FL164K
   ~ S25FL064P  
   ~ MX25L6435E
   ~ W25Q64FV
         
 * 4MB (64KB sector) devices
   ~ S25FL032P
   ~ MX25L3235E
   ~ W25Q32FV
   ~ PM25LQ032C  
   ~ GD25Q32C
   
 * 2MB (64KB sector) devices
   ~ S25FL016K {W25Q16DV}
   ~ MX25L1635E
   ~ MX25L1606E  
   
 * 1MB (64KB sector) devices
   ~ W25Q80BV
   ~ MX25L8035E
   ~ MX25V8035F
   
 * 512KB (64KB sector) devices
   ~ W25Q40CV
   
When this flash driver is used, an error will be reported if no 
recognised SPIFI device is found on the target system 

Adding support for other SPIFI devices
--------------------------------------
Support for new parts can be added to the flash driver by updating
the files in the lpcspifilib subdirectory. Please see the LPCSPIFILIB
documentation for more details of how to do this.
 
 
Requirements for building
-------------------------
The use of MCUpresso IDE v10.0.0 or later is recommended for 
rebuilding this project.

To build these drivers, you will need to import the 'LPCXFlashDriverLib'
and 'lpc_chip_40xx' library projects provided in the same zip file.

At the time of writing, the 'lpc_chip_40xx' project provided is taken 
from v2.10 release of the LPC40xx version of LPCOpen
- http://www.nxp.com/pages/:LPC-OPEN-LIBRARIES

The project also includes a subdirectory containing the sources and 
headers for the LPCOpen LPCSPIFI Library, which is used to provide 
the actual SPIFI access code. The LPCSPIFI library supplied is 
currently based on the v1.0.3 release. 
- http://www.nxp.com/pages/:LPC-OPEN-LIBRARIES
   
Debug / test configuration
--------------------------
In addition to providing the SPIFI_GENERIC build configuration to 
create an actual flash driver, the 'Debug' build configuration can
be used to generate a test version of the flash driver that can be run 
within the LPCXpreso debug environment. This configuration builds
the flash driver wrapped by an interface that mimics the interface
used byLPCXpresso when programming a project executable into flash.

This can be very useful when adding support for a new flash device,
to ensure that basic operation works, before trying out the full 
flash driver.       
        
Note - Due to the LPC4088 requirement to boot from its internal flash, 
projects created to utilise SPI flash will span multiple flash devices. 
See the FAQ 'Configuring projects to span multiple flash devices' for 
details of how this should be done.
