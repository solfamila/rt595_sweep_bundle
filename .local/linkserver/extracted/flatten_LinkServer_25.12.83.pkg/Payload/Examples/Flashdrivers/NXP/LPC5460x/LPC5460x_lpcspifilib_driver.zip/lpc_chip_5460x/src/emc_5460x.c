/*
 * @brief LPC5460x EMC driver
 *
 * @note
 * Copyright 2016, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/* DIV function with result rounded up */
#define EMC_DIV_ROUND_UP(x, y)  ((x + y - 1) / y)

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

#ifndef EMC_SUPPORT_ONLY_PL172
/* Get ARM External Memory Controller Version */
STATIC uint32_t getARMPeripheralID(void)
{
	uint32_t *RegAdd;
	RegAdd = (uint32_t *) ((uint32_t) LPC_EMC + 0xFE0);
	return (RegAdd[0] & 0xFF) | ((RegAdd[1] & 0xFF) << 8) |
		   ((RegAdd[2] & 0xFF) << 16) | (RegAdd[3] << 24);
}

#endif

/* Calculate Clock Count from Timing Unit(nanoseconds) */
STATIC uint32_t convertTimmingParam(uint32_t EMC_Clock, int32_t input_ns, uint32_t adjust)
{
	uint32_t temp;
	if (input_ns < 0) {
		return (-input_ns) >> 8;
	}
	temp = EMC_Clock / 1000000;		/* MHz calculation */
	temp = temp * input_ns / 1000;

	/* round up */
	temp += 0xFF;

	/* convert to simple integer number format */
	temp >>= 8;
	if (temp > adjust) {
		return temp - adjust;
	}

	return 0;
}

/* Get Dynamic Memory Device Colum len */
STATIC uint32_t getColsLen(uint32_t DynConfig)
{
	uint32_t DevBusWidth;
	DevBusWidth = (DynConfig >> EMC_DYN_CONFIG_DEV_BUS_BIT) & 0x03;
	if (DevBusWidth == 2) {
		return 8;
	}
	else if (DevBusWidth == 1) {
		return ((DynConfig >> (EMC_DYN_CONFIG_DEV_SIZE_BIT + 1)) & 0x03) + 8;
	}
	else if (DevBusWidth == 0) {
		return ((DynConfig >> (EMC_DYN_CONFIG_DEV_SIZE_BIT + 1)) & 0x03) + 9;
	}

	return 0;
}

/* Initializes the Dynamic Controller according to the specified parameters
   in the IP_EMC_DYN_CONFIG_T */
void Chip_EMC_Dynamic_Init(LPC_EMC_T *pEMC, const EMC_DYN_CONFIG_T *Dynamic_Config, uint32_t EMC_Clock)
{
	uint32_t ChipSelect, tmpclk;
	volatile int i;

	for (ChipSelect = 0; ChipSelect < 4; ChipSelect++) {
		LPC_EMC_T *EMC_Reg_add = (LPC_EMC_T *) ((uint32_t) pEMC + (ChipSelect << 5));

		EMC_Reg_add->DYNAMICRASCAS0    = Dynamic_Config->DevConfig[ChipSelect].RAS |
										 ((Dynamic_Config->DevConfig[ChipSelect].ModeRegister <<
										   (8 - EMC_DYN_MODE_CAS_BIT)) & 0xF00);
		EMC_Reg_add->DYNAMICCONFIG0    = Dynamic_Config->DevConfig[ChipSelect].DynConfig;
	}
	pEMC->DYNAMICREADCONFIG = Dynamic_Config->ReadConfig;	/* Read strategy */

	pEMC->DYNAMICRP         = convertTimmingParam(EMC_Clock, Dynamic_Config->tRP, 1);
	pEMC->DYNAMICRAS        = convertTimmingParam(EMC_Clock, Dynamic_Config->tRAS, 1);
	pEMC->DYNAMICSREX       = convertTimmingParam(EMC_Clock, Dynamic_Config->tSREX, 1);
	pEMC->DYNAMICAPR        = convertTimmingParam(EMC_Clock, Dynamic_Config->tAPR, 1);
	pEMC->DYNAMICDAL        = convertTimmingParam(EMC_Clock, Dynamic_Config->tDAL, 0);
	pEMC->DYNAMICWR         = convertTimmingParam(EMC_Clock, Dynamic_Config->tWR, 1);
	pEMC->DYNAMICRC         = convertTimmingParam(EMC_Clock, Dynamic_Config->tRC, 1);
	pEMC->DYNAMICRFC        = convertTimmingParam(EMC_Clock, Dynamic_Config->tRFC, 1);
	pEMC->DYNAMICXSR        = convertTimmingParam(EMC_Clock, Dynamic_Config->tXSR, 1);
	pEMC->DYNAMICRRD        = convertTimmingParam(EMC_Clock, Dynamic_Config->tRRD, 1);
	pEMC->DYNAMICMRD        = convertTimmingParam(EMC_Clock, Dynamic_Config->tMRD, 1);

	for (i = 0; i < 1000; i++) {	/* wait 100us */
	}
	pEMC->DYNAMICCONTROL    = 0x00000183;	/* Issue NOP command */

	for (i = 0; i < 1000; i++) {}
	pEMC->DYNAMICCONTROL    = 0x00000103;	/* Issue PALL command */

	pEMC->DYNAMICREFRESH = 2;	/* ( 2 * 16 ) -> 32 clock cycles */

	for (i = 0; i < 80; i++) {}

	tmpclk = EMC_DIV_ROUND_UP(convertTimmingParam(EMC_Clock, Dynamic_Config->RefreshPeriod, 0), 16);
	pEMC->DYNAMICREFRESH    = tmpclk;

	pEMC->DYNAMICCONTROL    = 0x00000083;	/* Issue MODE command */

	for (ChipSelect = 0; ChipSelect < 4; ChipSelect++) {
		/*uint32_t burst_length;*/
		uint32_t DynAddr;
		uint8_t Col_len;

		Col_len = getColsLen(Dynamic_Config->DevConfig[ChipSelect].DynConfig);
		/* get bus wide: if 32bit, len is 4 else if 16bit len is 2 */
		/* burst_length = 1 << ((((Dynamic_Config->DynConfig[ChipSelect] >> 14) & 1)^1) +1); */
		if (Dynamic_Config->DevConfig[ChipSelect].DynConfig & (1 << EMC_DYN_CONFIG_DATA_BUS_WIDTH_BIT)) {
			/*32bit bus */
			/*burst_length = 2;*/
			Col_len += 2;
		}
		else {
			/*burst_length = 4;*/
			Col_len += 1;
		}

		/* Check for RBC mode */
		if (!(Dynamic_Config->DevConfig[ChipSelect].DynConfig & EMC_DYN_CONFIG_LPSDRAM)) {
			if (!(Dynamic_Config->DevConfig[ChipSelect].DynConfig & (0x7 << EMC_DYN_CONFIG_DEV_SIZE_BIT))) {
				/* 2 banks => 1 bank select bit */
				Col_len += 1;
			}
			else {
				/* 4 banks => 2 bank select bits */
				Col_len += 2;
			}
		}

		DynAddr = Dynamic_Config->DevConfig[ChipSelect].BaseAddr;


		if (DynAddr != 0) {
			uint32_t temp;
			uint32_t ModeRegister;
			ModeRegister = Dynamic_Config->DevConfig[ChipSelect].ModeRegister;
			temp = *((volatile uint32_t *) (DynAddr | (ModeRegister << Col_len)));
			temp = temp;
		}
	}
	pEMC->DYNAMICCONTROL    = 0x00000000;	/* Issue NORMAL command */

	/* enable buffers */
	pEMC->DYNAMICCONFIG0    |= 1 << 19;
	pEMC->DYNAMICCONFIG1    |= 1 << 19;
	pEMC->DYNAMICCONFIG2    |= 1 << 19;
	pEMC->DYNAMICCONFIG3    |= 1 << 19;
}

/* Initializes the Static Controller according to the specified parameters
 * in the IP_EMC_STATIC_CONFIG_T
 */
void Chip_EMC_Static_Init(LPC_EMC_T *pEMC, EMC_STATIC_CONFIG_T *Static_Config, uint32_t EMC_Clock)
{
	LPC_EMC_T *EMC_Reg_add = (LPC_EMC_T *) ((uint32_t) pEMC + ((Static_Config->ChipSelect) << 5));
	EMC_Reg_add->STATICCONFIG0      = Static_Config->Config;
	EMC_Reg_add->STATICWAITWEN0     = convertTimmingParam(EMC_Clock, Static_Config->WaitWen, 1);
	EMC_Reg_add->STATICWAITOEN0     = convertTimmingParam(EMC_Clock, Static_Config->WaitOen, 0);
	EMC_Reg_add->STATICWAITRD0      = convertTimmingParam(EMC_Clock, Static_Config->WaitRd, 1);
	EMC_Reg_add->STATICWAITPAG0     = convertTimmingParam(EMC_Clock, Static_Config->WaitPage, 1);
	EMC_Reg_add->STATICWAITWR0      = convertTimmingParam(EMC_Clock, Static_Config->WaitWr, 2);
	EMC_Reg_add->STATICWAITTURN0    = convertTimmingParam(EMC_Clock, Static_Config->WaitTurn, 1);
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/



