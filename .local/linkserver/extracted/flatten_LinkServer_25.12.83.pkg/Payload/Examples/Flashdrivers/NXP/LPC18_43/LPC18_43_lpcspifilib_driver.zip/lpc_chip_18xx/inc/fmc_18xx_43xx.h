/*
 * @brief LPC18xx/43xx FLASH Memory Controller (FMC) driver
 *
 * @note
 * Copyright 2013-2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __FMC_18XX_43XX_H_
#define __FMC_18XX_43XX_H_

#ifdef __cplusplus
extern "C" {
#endif

/** @defgroup FMC_18XX_43XX CHIP: LPC18xx/43xx FLASH Memory Controller driver
 * @ingroup CHIP_18XX_43XX_Drivers
 * @{
 */

/**
 * @brief FLASH Memory Controller Unit register block structure
 */
typedef struct {		/*!< FMC Structure */
	__I  uint32_t  RESERVED1[8];
	__IO uint32_t  FMSSTART;
	__IO uint32_t  FMSSTOP;
	__I  uint32_t  RESERVED2;
	__I  uint32_t  FMSW[4];
	__I  uint32_t  RESERVED3[1001];
	__I  uint32_t  FMSTAT;
	__I  uint32_t  RESERVED5;
	__O  uint32_t  FMSTATCLR;
	__I  uint32_t  RESERVED4[5];
} LPC_FMC_T;

/* Flash signature start and busy status bit */
#define FMC_FLASHSIG_BUSY       (1UL << 17)

/* Flash signature clear status bit */
#define FMC_FLASHSIG_STAT       (1 << 2)

/**
 * @brief	Start computation of a signature for a FLASH memory range
 * @param	bank	: FLASH bank, A = 0, B = 1
 * @param	start	: Starting FLASH address for computation, must be aligned on 16 byte boundary
 * @param	stop	: Ending FLASH address for computation, must be aligned on 16 byte boundary
 * @return	Nothing
 * @note	Only bits 20..4 are used for the FLASH signature computation.
 *			Use the Chip_FMC_IsSignatureBusy() function to determine when the
 *			signature computation operation is complete and use the
 *			Chip_FMC_GetSignature() function to get the computed signature.
 */
STATIC INLINE void Chip_FMC_ComputeSignature(uint8_t bank, uint32_t start, uint32_t stop)
{
	LPC_FMC[bank]->FMSSTART = (start >> 4);
	LPC_FMC[bank]->FMSTATCLR = FMC_FLASHSIG_STAT;
	LPC_FMC[bank]->FMSSTOP = (stop >> 4) | FMC_FLASHSIG_BUSY;
}

/**
 * @brief	Start computation of a signature for a FLASH memory address and block count
 * @param	bank	: FLASH bank, A = 0, B = 1
 * @param	start	: Starting FLASH address for computation, must be aligned on 16 byte boundary
 * @param	blocks	: Number of 16 byte blocks used for computation
 * @return	Nothing
 * @note	Only bits 20..4 are used for the FLASH signature computation.
 *			Use the Chip_FMC_IsSignatureBusy() function to determine when the
 *			signature computation operation is complete and the
 *			Chip_FMC_GetSignature() function to get the computed signature.
 */
STATIC INLINE void Chip_FMC_ComputeSignatureBlocks(uint8_t bank, uint32_t start, uint32_t blocks)
{
	Chip_FMC_ComputeSignature(bank, start, (start + (blocks * 16)));
}

/**
 * @brief	Clear signature generation completion flag
 * @param	bank	: FLASH bank, A = 0, B = 1
 * @return	Nothing
 */
STATIC INLINE void Chip_FMC_ClearSignatureBusy(uint8_t bank)
{
	LPC_FMC[bank]->FMSTATCLR = FMC_FLASHSIG_STAT;
}

/**
 * @brief	Check for signature generation completion
 * @param	bank	: FLASH bank, A = 0, B = 1
 * @return	true if the signature computation is running, false if finished
 */
STATIC INLINE bool Chip_FMC_IsSignatureBusy(uint8_t bank)
{
	return (bool) ((LPC_FMC[bank]->FMSTAT & FMC_FLASHSIG_STAT) == 0);
}

/**
 * @brief	Returns the generated FLASH signature value
 * @param	bank	: FLASH bank, A = 0, B = 1
 * @param	index	: Signature index to get - use 0 to FMSW0, 1 to FMSW1, etc.
 * @return	the generated FLASH signature value
 */
STATIC INLINE uint32_t Chip_FMC_GetSignature(uint8_t bank, int index)
{
	return LPC_FMC[bank]->FMSW[index];
}

/**
 * @}
 */

#ifdef __cplusplus
}
#endif

#endif /* __FMC_18XX_43XX_H_ */
