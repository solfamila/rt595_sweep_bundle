//*****************************************************************************
// LPC5410x image-header, header file
//
//*****************************************************************************
//
// Copyright 2014-2016, 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

// AWB
#include <stdint.h>

#define IMAGE_HDR_MARKER			0xFEEDA5A5									// image header marker
#define IMAGE_LEGACY_SIG			0x00000000									// legacy image signature
#define IMAGE_SINGLE_ENH_SIG		0xEDDC9494									// single enhanced image signature
#define IMAGE_DUAL_ENH_SIG			0x0FFEB6B6									// dual enhanced image signature

//------------------------------------------------------------------------------
//	Configure the selected image signature:
//	This value is set in the "Symbols" settings in the project properties
//------------------------------------------------------------------------------

#if defined (__ECRP_SIMPLE)
#define IMAGE_SIG		IMAGE_LEGACY_SIG
#else
#if !defined (__ECRP_DUAL_IMAGE)
#define IMAGE_SIG		IMAGE_SINGLE_ENH_SIG
#else
#define IMAGE_SIG		IMAGE_DUAL_ENH_SIG
#endif
#endif

typedef enum {
	IMG_NORMAL = 0,																// Normal image with CRC.
	IMG_NO_CRC																	// No CRC check required. Used during development.
} SL_IMAGE_T;

//------------------------------------------------------------------------------
//	Image header structure:
//	- All application images should define this structure at of offset 0x100.
//	- Adding it to the start-up file is recommended.
//------------------------------------------------------------------------------
typedef struct _IMG_HEADER_T {
	uint32_t	header_marker;													// Image header marker should always be set to 0xFEEDA5A5
	SL_IMAGE_T	img_type;														// Image check type, with or without optional CRC
	uint32_t	reserved;														// Reserved value (compatibility with Niobe)
	uint32_t	img_len;														// Image length or the length of image CRC check should be done.
	uint32_t	crc_value;														// CRC value
	uint32_t	version;														// Image version for multi-image support
} IMG_HEADER_T;

