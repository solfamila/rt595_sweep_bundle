//*****************************************************************************
// LPC5460x Microcontroller Startup code for use with LPCXpresso IDE
//
// Version : 150728
//*****************************************************************************
//
// Copyright 2015-2016, 2018, 2020, 2021 NXP
// All rights reserved.
//
// SPDX-License-Identifier: BSD-3-Clause
//*****************************************************************************

#if defined (__cplusplus)
#ifdef __REDLIB__
#error Redlib does not support C++
#else
//*****************************************************************************
//
// The entry point for the C++ library startup
//
//*****************************************************************************
extern "C" {
    extern void __libc_init_array(void);
}
#endif
#endif

#define WEAK __attribute__ ((weak))
#define ALIAS(f) __attribute__ ((weak, alias (#f)))

//*****************************************************************************
#if defined (__cplusplus)
extern "C" {
#endif

//*****************************************************************************
#include "img_hdr.h"
#include "ecrp.h"

//*****************************************************************************
#if defined (__USE_CMSIS) || defined (__USE_LPCOPEN)
// Declaration of external SystemInit function
extern void SystemInit(void);
#endif

//*****************************************************************************
#if !defined (DONT_ENABLE_SWVTRACECLK)
// Allow confirmation that SWV trace has been enabled
unsigned int __SWVtrace_Enabled;
#endif

//*****************************************************************************
//
// Forward declaration of the default handlers. These are aliased.
// When the application defines a handler (with the same name), this will
// automatically take precedence over these weak definitions
//
//*****************************************************************************
void ResetISR(void);
WEAK void NMI_Handler(void);
WEAK void HardFault_Handler(void);
WEAK void MemManage_Handler(void);
WEAK void BusFault_Handler(void);
WEAK void UsageFault_Handler(void);
WEAK void SVC_Handler(void);
WEAK void DebugMon_Handler(void);
WEAK void PendSV_Handler(void);
WEAK void SysTick_Handler(void);
WEAK void IntDefaultHandler(void);

//*****************************************************************************
//
// Forward declaration of the specific IRQ handlers. These are aliased
// to the IntDefaultHandler, which is a 'forever' loop. When the application
// defines a handler (with the same name), this will automatically take
// precedence over these weak definitions
//
//*****************************************************************************
// External Interrupts
void WDT_BOD_IRQHandler(void) ALIAS(IntDefaultHandler);
void DMA_IRQHandler(void) ALIAS(IntDefaultHandler);
void GINT0_IRQHandler(void) ALIAS(IntDefaultHandler);
void GINT1_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT0_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT1_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT2_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT3_IRQHandler(void) ALIAS(IntDefaultHandler);
void UTICK_IRQHandler(void) ALIAS(IntDefaultHandler);
void MRT_IRQHandler(void) ALIAS(IntDefaultHandler);
void CT32B0_IRQHandler(void) ALIAS(IntDefaultHandler);
void CT32B1_IRQHandler(void) ALIAS(IntDefaultHandler);
void SCT0_IRQHandler(void) ALIAS(IntDefaultHandler);
void CT32B3_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM0_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM1_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM2_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM3_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM4_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM5_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM6_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM7_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM8_IRQHandler(void) ALIAS(IntDefaultHandler);
void FLEXCOMM9_IRQHandler(void) ALIAS(IntDefaultHandler);
void ADC_SEQA_IRQHandler(void) ALIAS(IntDefaultHandler);
void ADC_SEQB_IRQHandler(void) ALIAS(IntDefaultHandler);
void ADC_THCMP_IRQHandler(void) ALIAS(IntDefaultHandler);
void DMIC_IRQHandler(void) ALIAS(IntDefaultHandler);
void HWVAD_IRQHandler(void) ALIAS(IntDefaultHandler);
void USB0_NEEDCLK_IRQHandler(void) ALIAS(IntDefaultHandler);
void USB0_IRQHandler(void) ALIAS(IntDefaultHandler);
void USB1_NEEDCLK_IRQHandler(void) ALIAS(IntDefaultHandler);
void USB1_IRQHandler(void) ALIAS(IntDefaultHandler);
void RTC_IRQHandler(void) ALIAS(IntDefaultHandler);
void Reserved30_IRQHandler(void) ALIAS(IntDefaultHandler);
void MAILBOX_WAKEUP_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT4_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT5_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT6_IRQHandler(void) ALIAS(IntDefaultHandler);
void PIN_INT7_IRQHandler(void) ALIAS(IntDefaultHandler);
void CT32B2_IRQHandler(void) ALIAS(IntDefaultHandler);
void CT32B4_IRQHandler(void) ALIAS(IntDefaultHandler);
void Reserved38_IRQHandler(void) ALIAS(IntDefaultHandler);
void SPIFI_IRQHandler(void) ALIAS(IntDefaultHandler);

void SCT_IRQHandler(void) ALIAS(IntDefaultHandler);
void IOH_IRQHandler(void) ALIAS(IntDefaultHandler);
void RITIMER_IRQHandler(void) ALIAS(IntDefaultHandler);
void SDIO_IRQHandler(void) ALIAS(IntDefaultHandler);
void CAN0_0_IRQHandler(void) ALIAS(IntDefaultHandler);
void CAN0_1_IRQHandler(void) ALIAS(IntDefaultHandler);
void CAN1_0_IRQHandler(void) ALIAS(IntDefaultHandler);
void CAN1_1_IRQHandler(void) ALIAS(IntDefaultHandler);
void ETHERNET_IRQHandler(void) ALIAS(IntDefaultHandler);
void ETHERNET_PMT_IRQHandler(void) ALIAS(IntDefaultHandler);
void ETHERNET_MACLP_IRQHandler(void) ALIAS(IntDefaultHandler);
void EEPROM_IRQHandler(void) ALIAS(IntDefaultHandler);
void LCD_IRQHandler(void) ALIAS(IntDefaultHandler);
void SHA_IRQHandler(void) ALIAS(IntDefaultHandler);

void SMARTCARD0_IRQHandler(void) ALIAS(IntDefaultHandler);
void SMARTCARD1_IRQHandler(void) ALIAS(IntDefaultHandler);
void PVT0_A_IRQHandler(void) ALIAS(IntDefaultHandler);
void PVT0_R_IRQHandler(void) ALIAS(IntDefaultHandler);
void PVT1_A_IRQHandler(void) ALIAS(IntDefaultHandler);
void PVT1_R_IRQHandler(void) ALIAS(IntDefaultHandler);
//*****************************************************************************
//
// The entry point for the application.
// __main() is the entry point for Redlib based applications
// main() is the entry point for Newlib based applications
//
//*****************************************************************************
#if defined (__REDLIB__)
extern void __main(void);
#endif
extern int main(void);
//*****************************************************************************
//
// External declaration for the pointer to the stack top from the Linker Script
//
//*****************************************************************************
extern void _vStackTop(void);

//*****************************************************************************
//
// External declaration for LPC MCU vector table checksum from  Linker Script
//
//*****************************************************************************
WEAK extern void __valid_user_code_checksum();

//*****************************************************************************
#if defined (__cplusplus)
} // extern "C"
#endif
//*****************************************************************************
//
// The vector table.
// This relies on the linker script to place at correct location in memory.
//
//*****************************************************************************
extern void (* const g_pfnVectors[])(void);

WEAK extern const IMG_HEADER_T	IMG_hdr;
typedef void (*EVT_ENTRY)(void);

__attribute__ ((used,section(".isr_vector")))
const EVT_ENTRY g_pfnVectors[] = {
		// Core Level - CM4
		&_vStackTop,            // The initial stack pointer
		ResetISR,               // The reset handler
		NMI_Handler,            // The NMI handler
		HardFault_Handler,      // The hard fault handler
		MemManage_Handler,      // The MPU fault handler
		BusFault_Handler,       // The bus fault handler
		UsageFault_Handler,     // The usage fault handler
		__valid_user_code_checksum, // LPC MCU Checksum
		(EVT_ENTRY)ECRP_VAL,    // eCRP value
		(EVT_ENTRY)IMAGE_SIG,   // image signature
		(EVT_ENTRY)&IMG_hdr,    // Image Header pointer
		SVC_Handler,            // SVCall handler
		DebugMon_Handler,       // Debug monitor handler
		0,                      // Reserved
		PendSV_Handler,         // The PendSV handler
		SysTick_Handler,        // The SysTick handler

        // External Interrupts
		WDT_BOD_IRQHandler,              // 0, Watchdog, BOD, and FLASH are grouped now.
		DMA_IRQHandler,              // 1, DMA Controller
		GINT0_IRQHandler,            // 2, GPIO Group0 Interrupt
		GINT1_IRQHandler,            // 3, GPIO Group1 Interrupt
		PIN_INT0_IRQHandler,         // 4, PIO INT0
		PIN_INT1_IRQHandler,         // 5, PIO INT1
		PIN_INT2_IRQHandler,         // 6, PIO INT2
		PIN_INT3_IRQHandler,         // 7, PIO INT3
		UTICK_IRQHandler,            // 8, UTICK timer
		MRT_IRQHandler,              // 9, Multi-Rate Timer
		CT32B0_IRQHandler,           // 10, TIMER0
		CT32B1_IRQHandler,           // 11, TIMER1
		SCT0_IRQHandler,              // 12, Smart Counter Timer
		CT32B3_IRQHandler,           // 13, TIMER3
		FLEXCOMM0_IRQHandler,        // 14, FLEX Comm0
		FLEXCOMM1_IRQHandler,        // 15, FLEX Comm1
		FLEXCOMM2_IRQHandler,        // 16, FLEX Comm2
		FLEXCOMM3_IRQHandler,        // 17, FLEX Comm3
		FLEXCOMM4_IRQHandler,        // 18, FLEX Comm4
		FLEXCOMM5_IRQHandler,        // 19, FLEX Comm5
		FLEXCOMM6_IRQHandler,        // 20, FLEX Comm6
		FLEXCOMM7_IRQHandler,        // 21, FLEX Comm7
		ADC_SEQA_IRQHandler,         // 22, ADC0 A sequence (A/D Converter) interrupt
		ADC_SEQB_IRQHandler,         // 23, ADC0 B sequence (A/D Converter) interrupt
		ADC_THCMP_IRQHandler,        // 24, ADC THCMP and OVERRUN ORed
		DMIC_IRQHandler,             // 25, Audio DMIC
		HWVAD_IRQHandler,            // 26, Audio HWVAD
		USB0_NEEDCLK_IRQHandler,     // 27, USB0 NeedClk or Wakeup
		USB0_IRQHandler,             // 28, USB0
		RTC_IRQHandler,              // 29, RTC Timer
		IOH_IRQHandler,              // 30, IOH
		MAILBOX_WAKEUP_IRQHandler,   // 31, Mailbox and GPIO wakeup are grouped

		PIN_INT4_IRQHandler,         // 32, PIO INT4
		PIN_INT5_IRQHandler,         // 33, PIO INT5
		PIN_INT6_IRQHandler,         // 34, PIO INT6
		PIN_INT7_IRQHandler,         // 35, PIO INT7
		CT32B2_IRQHandler,           // 36, TIMER2
		CT32B4_IRQHandler,           // 37, TIMER4
		RITIMER_IRQHandler,          // 38, OS Timer
		SPIFI_IRQHandler,            // 39, SPIFI             ;
		FLEXCOMM8_IRQHandler,        // 40, FLEX Comm8
		FLEXCOMM9_IRQHandler,        // 41, FLEX Comm9
		SDIO_IRQHandler,             // 42, SDIO
		CAN0_0_IRQHandler,           // 43, CAN0 INT0
		CAN0_1_IRQHandler,           // 44, CAN0 INT1
		CAN1_0_IRQHandler,           // 45, CAN1 INT0
		CAN1_1_IRQHandler,           // 46, CAN1 INT1
		USB1_IRQHandler,             // 47, USB1
		USB1_NEEDCLK_IRQHandler,     // 48, USB1NeedClk
		ETHERNET_IRQHandler,         // 49, Ethernet
		ETHERNET_PMT_IRQHandler,     // 50, Ethernet PMT
		ETHERNET_MACLP_IRQHandler,   // 51, Ethernet MACLP
		EEPROM_IRQHandler,           // 52, EEPROM
		LCD_IRQHandler,              // 53, LCD
		SHA_IRQHandler,              // 54, SHA

		SMARTCARD0_IRQHandler,       // 55, Smartcard 0
		SMARTCARD1_IRQHandler,       // 56, Smartcard 1
}; /* End of g_pfnVectors */

//*****************************************************************************
// Functions to carry out the initialization of RW and BSS data sections. These
// are written as separate functions rather than being inlined within the
// ResetISR() function in order to cope with MCUs with multiple banks of
// memory.
//*****************************************************************************
__attribute__ ((section(".after_vectors")))
void data_init(unsigned int romstart, unsigned int start, unsigned int len) {
    unsigned int *pulDest = (unsigned int*) start;
    unsigned int *pulSrc = (unsigned int*) romstart;
    unsigned int loop;
    for (loop = 0; loop < len; loop = loop + 4)
        *pulDest++ = *pulSrc++;
}

__attribute__ ((section(".after_vectors")))
void bss_init(unsigned int start, unsigned int len) {
    unsigned int *pulDest = (unsigned int*) start;
    unsigned int loop;
    for (loop = 0; loop < len; loop = loop + 4)
        *pulDest++ = 0;
}

//*****************************************************************************
// The following symbols are constructs generated by the linker, indicating
// the location of various points in the "Global Section Table". This table is
// created by the linker via the Code Red managed linker script mechanism. It
// contains the load address, execution address and length of each RW data
// section and the execution and length of each BSS (zero initialized) section.
//*****************************************************************************
extern unsigned int __data_section_table;
extern unsigned int __data_section_table_end;
extern unsigned int __bss_section_table;
extern unsigned int __bss_section_table_end;

//*****************************************************************************
// Reset entry point for your code.
// Sets up a simple runtime environment and initializes the C/C++
// library.
//*****************************************************************************

__attribute__ ((naked, noreturn, section(".after_vectors.reset")))
void ResetISR(void) {
    //
    // Copy the data sections from flash to SRAM.
    //
    unsigned int LoadAddr, ExeAddr, SectionLen;
    unsigned int *SectionTableAddr;

    // Optionally enable RAM banks that may be off by default at reset
#if !defined (DONT_ENABLE_DISABLED_RAMBANKS)
    volatile unsigned int *SYSCON_AHBCLKCTRLSET0 = (unsigned int *) 0x40000220;
    // Ensure that SRAM2(4) and SRAMX(5) bits in SYSAHBCLKCTRL0 are set
    *SYSCON_AHBCLKCTRLSET0 = (1 << 4) | (1 << 5);
#endif

    // Load base address of Global Section Table
    SectionTableAddr = &__data_section_table;

    // Copy the data sections from flash to SRAM.
    while (SectionTableAddr < &__data_section_table_end) {
        LoadAddr = *SectionTableAddr++;
        ExeAddr = *SectionTableAddr++;
        SectionLen = *SectionTableAddr++;
        data_init(LoadAddr, ExeAddr, SectionLen);
    }
    // At this point, SectionTableAddr = &__bss_section_table;
    // Zero fill the bss segment
    while (SectionTableAddr < &__bss_section_table_end) {
        ExeAddr = *SectionTableAddr++;
        SectionLen = *SectionTableAddr++;
        bss_init(ExeAddr, SectionLen);
    }

	// Optionally enable Cortex-M4 SWV trace (off by default at reset)
    // Note - your board support must also set up pinmuxing such that
    // SWO is output on GPIO PIO0-15 (FUNC2) or PIO1_1 (FUNC2).
#if !defined (DONT_ENABLE_SWVTRACECLK)
    if (1) {
		volatile unsigned int *TRACECLKDIV = (unsigned int *) 0x40000304;
		volatile unsigned int *SYSAHBCLKCTRLSET = (unsigned int *) 0x40000220;
		volatile unsigned int *SYSAHBCLKCTRL = (unsigned int *) 0x40000200;
		// Write 0x00000001 to TRACECLKDIV – Trace divider
		*TRACECLKDIV = 1;
		// Enable IOCON peripheral clock (for SWO on PIO0-15 or PIO1_1)
		// by setting bit13 via SYSAHBCLKCTRLSET[0]
		*SYSAHBCLKCTRLSET = 1 << 13; // 0x2000
		// Read  SYSAHBCLKCTRL[0] and check bit 13
		__SWVtrace_Enabled = ((*SYSAHBCLKCTRL & 1 << 13) == 1 << 13);
    }
#endif


#if !defined (__USE_LPCOPEN)
// LPCOpen init code deals with FP and VTOR initialisation
#if defined (__VFP_FP__) && !defined (__SOFTFP__)
    /*
     * Code to enable the Cortex-M4 FPU only included
     * if appropriate build options have been selected.
     * Code taken from Section 7.1, Cortex-M4 TRM (DDI0439C)
     */
    // CPACR is located at address 0xE000ED88
    asm("LDR.W R0, =0xE000ED88");
    // Read CPACR
    asm("LDR R1, [R0]");
    // Set bits 20-23 to enable CP10 and CP11 coprocessors
    asm(" ORR R1, R1, #(0xF << 20)");
    // Write back the modified value to the CPACR
    asm("STR R1, [R0]");
#endif // (__VFP_FP__) && !(__SOFTFP__)
    // ******************************
    // Check to see if we are running the code from a non-zero
    // address (eg RAM, external flash), in which case we need
    // to modify the VTOR register to tell the CPU that the
    // vector table is located at a non-0x0 address.

    // Note that we do not use the CMSIS register access mechanism,
    // as there is no guarantee that the project has been configured
    // to use CMSIS.
    unsigned int * pSCB_VTOR = (unsigned int *) 0xE000ED08;
    if ((unsigned int *) g_pfnVectors != (unsigned int *) 0x00000000) {
        // CMSIS : SCB->VTOR = <address of vector table>
        *pSCB_VTOR = (unsigned int) g_pfnVectors;
    }
#endif
#if defined (__USE_CMSIS) || defined (__USE_LPCOPEN)
    SystemInit();
#endif

#if defined (__cplusplus)
    //
    // Call C++ library initialisation
    //
    __libc_init_array();
#endif

#if defined (__REDLIB__)
    // Call the Redlib library, which in turn calls main()
    __main();
#else
    main();
#endif

    //
    // main() shouldn't return, but if it does, we'll just enter an infinite loop
    //
    while (1) {
        ;
    }
}

//*****************************************************************************
// Default exception handlers. Override the ones here by defining your own
// handler routines in your application code.
//*****************************************************************************
__attribute__ ((section(".after_vectors")))
void NMI_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void HardFault_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void MemManage_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void BusFault_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void UsageFault_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void SVC_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void DebugMon_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void PendSV_Handler(void)
{ while(1) {}
}

__attribute__ ((section(".after_vectors")))
void SysTick_Handler(void)
{ while(1) {}
}

//*****************************************************************************
//
// Processor ends up here if an unexpected interrupt occurs or a specific
// handler is not present in the application code.
//
//*****************************************************************************
__attribute__ ((section(".after_vectors")))
void IntDefaultHandler(void) {
    while (1) {
    }
}

