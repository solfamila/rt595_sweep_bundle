/*
 * @brief LPC18xx/43xx Ethernet driver
 *
 * @note
 * Copyright 2012, 2014, 2018, 2020, 2021 NXP
 * All rights reserved.
 *
 * @par
 * SPDX-License-Identifier: BSD-3-Clause
 */

#include "chip.h"

/*****************************************************************************
 * Private types/enumerations/variables
 ****************************************************************************/

/* Saved address for PHY and clock divider */
STATIC uint32_t phyCfg;

/*****************************************************************************
 * Public types/enumerations/variables
 ****************************************************************************/

/*****************************************************************************
 * Private functions
 ****************************************************************************/

STATIC INLINE void reset(LPC_ENET_T *pENET)
{
    Chip_RGU_TriggerReset(RGU_ETHERNET_RST);
	while (Chip_RGU_InReset(RGU_ETHERNET_RST)) 
    {}

	/* Reset ethernet peripheral */
	Chip_ENET_Reset(pENET);
}

/*****************************************************************************
 * Public functions
 ****************************************************************************/

/* Basic Ethernet interface initialization */
void Chip_ENET_Init(LPC_ENET_T *pENET)
{
	Chip_Clock_EnableOpts(CLK_MX_ETHERNET, true, true, 1);

	reset(pENET);

	/* Setup MII link divider to /102 and PHY address 1 */
	Chip_ENET_SetupMII(pENET, 4, 1);

	/* Enhanced descriptors, burst length = 1 */
	pENET->DMA_BUS_MODE = DMA_BM_ATDS | DMA_BM_PBL(1) | DMA_BM_RPBL(1);

	/* Initial MAC configuration for checksum offload, full duplex,
	   100Mbps, disable receive own in half duplex, inter-frame gap
	   of 64-bits */
	pENET->MAC_CONFIG = MAC_CFG_BL(0) | MAC_CFG_IPC | MAC_CFG_DM |
						MAC_CFG_DO | MAC_CFG_FES | MAC_CFG_PS | MAC_CFG_IFG(3);

	/* Setup default filter */
	pENET->MAC_FRAME_FILTER = MAC_FF_PR | MAC_FF_RA;

	/* Flush transmit FIFO */
	pENET->DMA_OP_MODE = DMA_OM_FTF;

	/* Setup DMA to flush receive FIFOs at 32 bytes, service TX FIFOs at
	   64 bytes */
	pENET->DMA_OP_MODE |= DMA_OM_RTC(1) | DMA_OM_TTC(0);

	/* Clear all MAC interrupts */
	pENET->DMA_STAT = DMA_ST_ALL;

	/* Enable MAC interrupts */
	pENET->DMA_INT_EN = 0;
}

/* Ethernet interface shutdown */
void Chip_ENET_DeInit(LPC_ENET_T *pENET)
{
	/* Disable packet reception */
	pENET->MAC_CONFIG = 0;

	/* Flush transmit FIFO */
	pENET->DMA_OP_MODE = DMA_OM_FTF;

	/* Disable receive and transmit DMA processes */
	pENET->DMA_OP_MODE = 0;

	Chip_Clock_Disable(CLK_MX_ETHERNET);
}

/* Sets up the PHY link clock divider and PHY address */
void Chip_ENET_SetupMII(LPC_ENET_T *pENET, uint32_t div, uint8_t addr)
{
	/* Save clock divider and PHY address in MII address register */
	phyCfg = MAC_MIIA_PA(addr) | MAC_MIIA_CR(div);
}

/* Starts a PHY write via the MII */
void Chip_ENET_StartMIIWrite(LPC_ENET_T *pENET, uint8_t reg, uint16_t data)
{
	/* Write value at PHY address and register */
	pENET->MAC_MII_ADDR = phyCfg | MAC_MIIA_GR(reg) | MAC_MIIA_W;
	pENET->MAC_MII_DATA = (uint32_t) data;
	pENET->MAC_MII_ADDR |= MAC_MIIA_GB;
}

/*Starts a PHY read via the MII */
void Chip_ENET_StartMIIRead(LPC_ENET_T *pENET, uint8_t reg)
{
	/* Read value at PHY address and register */
	pENET->MAC_MII_ADDR = phyCfg | MAC_MIIA_GR(reg);
	pENET->MAC_MII_ADDR |= MAC_MIIA_GB;
}

/* Sets full or half duplex for the interface */
void Chip_ENET_SetDuplex(LPC_ENET_T *pENET, bool full)
{
	if (full) {
		pENET->MAC_CONFIG |= MAC_CFG_DM;
	}
	else {
		pENET->MAC_CONFIG &= ~MAC_CFG_DM;
	}
}

/* Sets speed for the interface */
void Chip_ENET_SetSpeed(LPC_ENET_T *pENET, bool speed100)
{
	if (speed100) {
		pENET->MAC_CONFIG |= MAC_CFG_FES;
	}
	else {
		pENET->MAC_CONFIG &= ~MAC_CFG_FES;
	}
}

