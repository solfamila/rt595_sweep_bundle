/*
 * Copyright 2024 NXP
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#ifndef FLASH_CONFIG_H_
#define FLASH_CONFIG_H_


#include "fsl_power.h"

#if defined (DEBUG)
#define MIMXRT700_XSPI0_Octal
#endif

#if defined (MIMXRT700_XSPI0_Octal) || defined (MIMXRT700_XSPI0_Octal_S)
#define FLASH_XSPI XSPI0
#define FLASH_BASE_ADDR XSPI0_AMBA_BASE
#elif defined (MIMXRT700_XSPI1_Octal) || defined (MIMXRT700_XSPI1_Octal_S)
#define FLASH_XSPI XSPI1
#define FLASH_BASE_ADDR XSPI1_AMBA_BASE
#endif

#define FLASH_SIZE 0x4000000 /* 512Mb */
#define FLASH_PAGE_SIZE 256
#define FLASH_SECTOR_SIZE 0x1000 /* 4K */

#endif /* FLASH_CONFIG_H_*/
